"use client";

import { useCallback, useEffect, useState } from "react";
import soundManager from "./soundManager";

/**
 * Hook for using sound effects in components
 */
export const useSound = () => {
  const [enabled, setEnabled] = useState(soundManager?.isEnabled() ?? true);
  const [volume, setVolumeState] = useState(soundManager?.getVolume() ?? 0.7);

  useEffect(() => {
    if (soundManager) {
      setEnabled(soundManager.isEnabled());
      setVolumeState(soundManager.getVolume());
    }
  }, []);

  /**
   * Play a sound effect
   * @param name The name of the sound to play
   * @param volume Optional volume (0.0 to 1.0)
   */
  const play = useCallback((name: string, volume?: number) => {
    soundManager?.play(name, volume);
  }, []);

  /**
   * Toggle sound on/off
   */
  const toggle = useCallback(() => {
    if (soundManager) {
      const newState = soundManager.toggle();
      setEnabled(newState);
      return newState;
    }
    return enabled;
  }, [enabled]);

  /**
   * Set sound enabled state
   */
  const setSound = useCallback((state: boolean) => {
    if (soundManager) {
      soundManager.setEnabled(state);
      setEnabled(state);
    }
  }, []);

  /**
   * Set master volume
   */
  const setVolume = useCallback((newVolume: number) => {
    if (soundManager) {
      soundManager.setVolume(newVolume);
      setVolumeState(newVolume);
    }
  }, []);

  return {
    play,
    toggle,
    enabled,
    setSound,
    volume,
    setVolume,
  };
};
