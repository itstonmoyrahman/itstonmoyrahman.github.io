"use client";

/**
 * Sound Manager for handling game sound effects
 */
class SoundManager {
  private sounds: Map<string, HTMLAudioElement>;
  private enabled: boolean;
  private volume: number;

  constructor() {
    this.sounds = new Map();
    this.enabled = true;
    this.volume = 0.7; // Default volume at 70%

    // Initialize sounds
    this.preloadSounds();
    this.loadSettings();
  }

  /**
   * Load sound settings from localStorage if available
   */
  private loadSettings(): void {
    if (typeof window === "undefined") return;

    try {
      const soundSettings = localStorage.getItem("ludo_sound_settings");
      if (soundSettings) {
        const settings = JSON.parse(soundSettings);
        this.enabled = settings.enabled ?? true;
        this.volume = settings.volume ?? 0.7;
      }
    } catch (err) {
      console.warn("Failed to load sound settings", err);
    }
  }

  /**
   * Save sound settings to localStorage
   */
  private saveSettings(): void {
    if (typeof window === "undefined") return;

    try {
      localStorage.setItem(
        "ludo_sound_settings",
        JSON.stringify({
          enabled: this.enabled,
          volume: this.volume,
        })
      );
    } catch (err) {
      console.warn("Failed to save sound settings", err);
    }
  }

  /**
   * Preload all sound effects for better performance
   */
  private preloadSounds(): void {
    if (typeof window === "undefined") return;

    const soundFiles = {
      dice: "/sounds/diceRollingSound.mp3",
      move: "/sounds/jump-sound.mp3",
      cut: "/sounds/cut-sound.wav",
      pass: "/sounds/pass-sound.mp3",
      win: "/sounds/win-sound.mp3",
      open: "/sounds/open-sound.wav",
    };

    // Create and store audio elements
    Object.entries(soundFiles).forEach(([key, path]) => {
      const audio = new Audio(path);
      audio.preload = "auto";
      this.sounds.set(key, audio);
    });

    console.log("Sound effects preloaded");
  }
  /**
   * Play a sound effect by name
   * @param name The name of the sound to play
   * @param volume Optional volume (0.0 to 1.0)
   */
  play(name: string, volume: number = 1.0): void {
    if (!this.enabled || typeof window === "undefined") return;

    const sound = this.sounds.get(name);
    if (sound) {
      // Clone the audio to allow overlapping sounds
      const clone = sound.cloneNode() as HTMLAudioElement;
      // Apply both the master volume and the individual sound volume
      clone.volume = this.volume * volume;

      // Play the sound
      clone.play().catch((err) => {
        console.warn(`Failed to play sound '${name}':`, err.message);
      });
    } else {
      console.warn(`Sound '${name}' not found`);
    }
  }

  /**
   * Toggle sound on/off
   * @returns The new enabled state
   */
  toggle(): boolean {
    this.enabled = !this.enabled;
    this.saveSettings();
    return this.enabled;
  }

  /**
   * Get current enabled state
   */
  isEnabled(): boolean {
    return this.enabled;
  }

  /**
   * Set enabled state
   */
  setEnabled(enabled: boolean): void {
    this.enabled = enabled;
    this.saveSettings();
  }

  /**
   * Set master volume
   * @param volume New volume (0.0 to 1.0)
   */
  setVolume(volume: number): void {
    // Ensure volume is between 0 and 1
    this.volume = Math.max(0, Math.min(1, volume));
    this.saveSettings();
  }

  /**
   * Get current master volume
   */
  getVolume(): number {
    return this.volume;
  }
}

// Create a singleton instance
const soundManager = typeof window !== "undefined" ? new SoundManager() : null;

export default soundManager;
