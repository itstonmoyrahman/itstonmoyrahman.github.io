import { Server as NetServer } from "http";
import { NextApiRequest, NextApiResponse } from "next";
import { Server as ServerIO } from "socket.io";
import {
  Room,
  Player,
  RoomData,
  GameState,
  Token,
  Position,
  TokenPosition,
} from "@/lib/game/types";

export const config = {
  api: {
    bodyParser: false,
  },
};

// In-memory storage
const rooms = new Map<string, Room>();

const randomRoomCode = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

const playerColors: Array<"red" | "green" | "blue" | "yellow"> = [
  "red",
  "green",
  "blue",
  "yellow",
];

type NextApiResponseWithSocket = NextApiResponse & {
  socket: {
    server: NetServer & {
      io?: ServerIO;
    };
  };
};

export const initializeSocket = (
  req: NextApiRequest,
  res: NextApiResponseWithSocket
): ServerIO => {
  // Check if socket is already initialized
  if (res.socket.server.io) {
    console.log("Socket is already initialized");
    return res.socket.server.io;
  }

  console.log("Initializing socket server");
  const io = new ServerIO(res.socket.server, {
    path: "/api/socket",
    addTrailingSlash: false,
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
    },
  });

  // Store the io instance on the server
  res.socket.server.io = io;

  io.on("connection", (socket) => {
    console.log("New client connected", socket.id);

    // Create room
    socket.on(
      "create-room",
      (playerName: string, callback: (roomCode: string) => void) => {
        let roomCode = randomRoomCode();
        while (rooms.has(roomCode)) {
          roomCode = randomRoomCode();
        }

        const player: Player = {
          id: socket.id,
          name: playerName,
          color: playerColors[0],
          isHost: true,
          isReady: false,
          tokens: [
            { id: 0, position: "home" as TokenPosition, steps: 0 },
            { id: 1, position: "home" as TokenPosition, steps: 0 },
            { id: 2, position: "home" as TokenPosition, steps: 0 },
            { id: 3, position: "home" as TokenPosition, steps: 0 },
          ],
        };

        console.log(
          `Host ${playerName} creating room ${roomCode} with initial ready state: ${player.isReady}`
        );

        const room: Room = {
          code: roomCode,
          players: [player],
          gameState: "waiting",
          currentTurn: 0,
          messages: [],
          dice: 0,
        };

        rooms.set(roomCode, room);
        socket.join(roomCode);
        callback(roomCode);

        // Emit a player-joined event to the host too so they can see their own player
        console.log(`Emitting player-joined event for host: ${player.name}`);
        io.to(roomCode).emit("player-joined", player);

        console.log(`Room created: ${roomCode}`);
      }
    );

    // Join room
    socket.on(
      "join-room",
      (
        roomCode: string,
        playerName: string,
        callback: (
          success: boolean,
          message: string,
          roomData?: RoomData
        ) => void
      ) => {
        const room = rooms.get(roomCode);

        if (!room) {
          return callback(false, "Room not found");
        }

        if (room.players.length >= 4) {
          return callback(false, "Room is full");
        }

        if (room.gameState !== "waiting") {
          return callback(false, "Game already started");
        }

        const colorIndex = room.players.length;
        const player: Player = {
          id: socket.id,
          name: playerName,
          color: playerColors[colorIndex],
          isHost: false,
          isReady: false, // Always initialize as not ready
          tokens: [
            { id: 0, position: "home" as TokenPosition, steps: 0 },
            { id: 1, position: "home" as TokenPosition, steps: 0 },
            { id: 2, position: "home" as TokenPosition, steps: 0 },
            { id: 3, position: "home" as TokenPosition, steps: 0 },
          ],
        };

        console.log(
          `Player ${playerName} joining room ${roomCode} with initial ready state: ${player.isReady}`
        );
        room.players.push(player);
        socket.join(roomCode);

        const roomData: RoomData = {
          code: room.code,
          players: room.players,
          gameState: room.gameState,
          currentTurn: room.currentTurn,
          messages: room.messages,
          dice: room.dice,
        };

        callback(true, "Successfully joined room", roomData);

        // Notify other players with more detailed logging
        console.log(
          `Emitting player-joined event for player: ${player.name} with ID: ${socket.id}`
        );

        // Test if the event is being received by logging clients in the room
        console.log(
          `Clients in room ${roomCode}: ${Array.from(
            io.sockets.adapter.rooms.get(roomCode) || []
          ).join(", ")}`
        );

        // Use io.to() instead of socket.to() to broadcast to all clients including the sender
        io.to(roomCode).emit("player-joined", player);

        console.log(`Player ${playerName} joined room ${roomCode}`);
      }
    ); // Toggle player ready state
    socket.on("toggle-ready", (roomCode: string) => {
      const room = rooms.get(roomCode);
      if (!room || room.gameState !== "waiting") return;

      const playerIndex = room.players.findIndex(
        (p: Player) => p.id === socket.id
      );
      if (playerIndex === -1) return;

      const player = room.players[playerIndex];
      player.isReady = !player.isReady;

      console.log(
        `Player ${player.name} toggled ready state to: ${player.isReady}`
      );

      // Notify all players about the change
      io.to(roomCode).emit("player-ready-changed", {
        playerId: socket.id,
        isReady: player.isReady,
      });

      // Update room data for all players
      const roomData = {
        code: room.code,
        players: room.players,
        gameState: room.gameState,
        currentTurn: room.currentTurn,
        messages: room.messages,
        dice: room.dice,
      };

      console.log(
        `Emitting room-update after ready change. Players:`,
        room.players.map((p: Player) => `${p.name} (ready: ${p.isReady})`)
      );

      io.to(roomCode).emit("room-update", roomData);
    });

    // Start the game (host only)
    socket.on("start-game", (roomCode: string) => {
      const room = rooms.get(roomCode);
      if (!room || room.gameState !== "waiting") {
        console.log(
          `Cannot start game: Room not found or not in waiting state`
        );
        return;
      }

      const player = room.players.find((p: Player) => p.id === socket.id);
      if (!player || !player.isHost) {
        console.log(`Cannot start game: Player not found or not host`);
        return;
      }

      // Check if we have at least 2 players and all players are ready
      const allPlayersReady = room.players.every((p: Player) => p.isReady);

      console.log(`Start game requested by host ${player.name}`);
      console.log(
        `Players in room: ${room.players.length}, All ready: ${allPlayersReady}`
      );
      console.log(
        `Players: ${room.players.map(
          (p: Player) => `${p.name} (ready: ${p.isReady})`
        )}`
      );

      if (room.players.length >= 2 && allPlayersReady) {
        console.log(`Starting game in room ${roomCode}`);
        room.gameState = "playing";
        room.currentTurn = 0;

        const roomData = {
          code: room.code,
          players: room.players,
          gameState: room.gameState,
          currentTurn: room.currentTurn,
          messages: room.messages,
          dice: room.dice,
        };

        io.to(roomCode).emit("game-started", roomData);
      } else {
        console.log(
          `Cannot start game: Not enough players or not all players ready`
        );
      }
    });

    // Roll dice
    socket.on("roll-dice", (roomCode: string) => {
      const room = rooms.get(roomCode);
      if (!room || room.gameState !== "playing") return;

      const playerIndex = room.players.findIndex(
        (p: Player) => p.id === socket.id
      );
      if (playerIndex !== room.currentTurn) return;

      const diceValue = Math.floor(Math.random() * 6) + 1;
      room.dice = diceValue;

      io.to(roomCode).emit("dice-rolled", {
        playerId: socket.id,
        diceValue,
      });
    });

    // Move token
    socket.on("move-token", (roomCode: string, tokenId: number) => {
      const room = rooms.get(roomCode);
      if (!room || room.gameState !== "playing") return;

      const playerIndex = room.players.findIndex(
        (p: Player) => p.id === socket.id
      );
      if (playerIndex !== room.currentTurn) return;

      const player = room.players[playerIndex];
      const token = player.tokens[tokenId];

      if (!token) return;

      // If token is at home and dice is 6, move to start
      if (token.position === "home" && room.dice === 6) {
        token.position = "board" as TokenPosition;
        token.steps = 0;

        // Check for captures
        checkForCaptures(room, player, token.steps);
      }
      // If token is on the board, move it forward
      else if (token.position === "board") {
        token.steps += room.dice;

        // Check for captures
        checkForCaptures(room, player, token.steps);

        // If token completed the journey (56 steps in Ludo)
        if (token.steps >= 56) {
          token.position = "finished" as TokenPosition;
          token.steps = 56;

          // Check if player has won
          if (player.tokens.every((t: Token) => t.position === "finished")) {
            room.gameState = "finished";
            io.to(roomCode).emit("game-over", {
              winnerId: player.id,
              winner: player,
            });
            return;
          }
        }
      }
      // We can't move this token
      else {
        return;
      }

      // Emit the move
      // Send complete information to ensure UI is properly updated on all clients
      io.to(roomCode).emit("token-moved", {
        playerId: socket.id,
        tokenId,
        newPosition: token.position,
        steps: token.steps,
      });

      // Also update the room data to ensure all clients have the latest state
      const roomData = {
        code: room.code,
        players: room.players,
        gameState: room.gameState,
        currentTurn: room.currentTurn,
        messages: room.messages,
        dice: room.dice,
      };
      io.to(roomCode).emit("room-update", roomData);

      // Move to next turn if dice is not 6, otherwise same player goes again
      if (room.dice !== 6) {
        room.currentTurn = (room.currentTurn + 1) % room.players.length;
        io.to(roomCode).emit("next-turn", { currentTurn: room.currentTurn });
      }
    });

    // Check for token captures
    const checkForCaptures = (
      room: Room,
      currentPlayer: Player,
      steps: number
    ) => {
      room.players.forEach((player: Player) => {
        if (player.id !== currentPlayer.id) {
          player.tokens.forEach((token: Token) => {
            if (token.position === "board" && token.steps === steps) {
              // Send token back home
              token.position = "home" as TokenPosition;
              token.steps = 0;

              // Emit token moved event for captured token
              io.to(room.code).emit("token-moved", {
                playerId: player.id,
                tokenId: token.id,
                newPosition: "home",
                steps: 0,
              });
            }
          });
        }
      });
    };

    // Send message
    socket.on("send-message", (roomCode: string, emoji: string) => {
      const room = rooms.get(roomCode);
      if (!room) return;

      const player = room.players.find((p: Player) => p.id === socket.id);
      if (!player) return;

      const message = {
        id: Date.now().toString(),
        playerId: socket.id,
        playerName: player.name,
        playerColor: player.color,
        content: emoji,
        timestamp: new Date().toISOString(),
      };

      room.messages.push(message);
      io.to(roomCode).emit("new-message", message);
    });

    // Disconnect
    socket.on("disconnect", () => {
      console.log("Client disconnected", socket.id);

      // Find all rooms the player is in
      for (const [roomCode, room] of Array.from(rooms.entries())) {
        const playerIndex = room.players.findIndex(
          (p: Player) => p.id === socket.id
        );

        if (playerIndex !== -1) {
          const player = room.players[playerIndex];

          // Remove the player
          room.players.splice(playerIndex, 1);

          // If no players left, delete the room
          if (room.players.length === 0) {
            rooms.delete(roomCode);
            continue;
          }

          // Make someone else the host if the host left
          if (player.isHost && room.players.length > 0) {
            room.players[0].isHost = true;
          }

          // Adjust the current turn if necessary
          if (playerIndex < room.currentTurn) {
            room.currentTurn--;
          } else if (playerIndex === room.currentTurn) {
            room.currentTurn = room.currentTurn % room.players.length;
          }

          // Notify other players
          io.to(roomCode).emit("player-disconnected", {
            playerId: socket.id,
            playerName: player.name,
          });
        }
      }
    });

    // Request room state - for token synchronization
    socket.on("request-room-state", (roomCode: string) => {
      const room = rooms.get(roomCode);
      if (!room) return;

      // Make sure all players have valid token data
      room.players.forEach((player: Player) => {
        if (!player.tokens || player.tokens.length !== 4) {
          console.log(`Server fixing tokens for player ${player.name}`);
          player.tokens = [
            { id: 0, position: "home" as TokenPosition, steps: 0 },
            { id: 1, position: "home" as TokenPosition, steps: 0 },
            { id: 2, position: "home" as TokenPosition, steps: 0 },
            { id: 3, position: "home" as TokenPosition, steps: 0 },
          ];
        }

        // Ensure isReady property exists
        if (player.isReady === undefined) {
          player.isReady = false;
        }
      });

      // Send the full room state
      const roomData = {
        code: room.code,
        players: room.players,
        gameState: room.gameState,
        currentTurn: room.currentTurn,
        messages: room.messages,
        dice: room.dice,
      };

      // Send back to the requesting client only
      socket.emit("room-state", roomData);
    });
  });

  return io;
};
