"use client";

import { io, Socket } from "socket.io-client";
import { useEffect, useState, useCallback } from "react";
import { Player, RoomData, Message, GameState } from "@/lib/game/types";
import soundManager from "@/lib/sound/soundManager";

// Create a persistent socket instance outside of component lifecycle
let socket: Socket | null = null;
let isInitialized = false;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;

// Initialize socket connection outside of React component
const initializeSocket = () => {
  if (!isInitialized && typeof window !== "undefined") {
    // Get the base URL from environment or default to location origin
    const socketUrl =
      process.env.NEXT_PUBLIC_SOCKET_URL || window.location.origin;
    console.log(`Initializing socket connection to: ${socketUrl}`);
    try {
      // Connect to the standalone Socket.IO server
      const socketUrl =
        process.env.NEXT_PUBLIC_SOCKET_URL || "http://localhost:3001";
      console.log(`Initializing socket connection to: ${socketUrl}`);
      socket = io(socketUrl, {
        reconnectionAttempts: MAX_RECONNECT_ATTEMPTS,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        timeout: 20000,
        transports: ["websocket", "polling"], // Try WebSocket first, fall back to polling
      });

      // Connection events with detailed logging
      socket.on("connect", () => {
        console.log(`Socket connected with ID: ${socket?.id}`);
        console.log(
          "Socket ready state:",
          socket?.connected ? "Connected" : "Disconnected"
        );
        // Reset reconnect attempts on successful connection
        reconnectAttempts = 0;

        // Check if we need to automatically rejoin a game after reconnection
        if (typeof window !== "undefined") {
          try {
            const sessionStorage = window.localStorage;
            const sessionItem = sessionStorage.getItem("ludo_game_session");

            if (sessionItem) {
              const session = JSON.parse(sessionItem);
              console.log("Found saved game session after reconnect:", session);

              // Update the session with the new socket ID but preserve original ID
              if (socket) {
                // If this is a reconnection, the originalId should already exist
                // If not, use the previous ID as the original ID
                const previousId = session.playerId;
                const originalId = session.originalId || previousId;

                // Update the session with new values
                session.playerId = socket.id;
                session.originalId = originalId;

                console.log(`Updating session after reconnect:
                  - New Socket ID: ${socket.id}
                  - Original ID: ${originalId}
                  - Previous ID: ${previousId}
                  - Player: ${session.playerName}
                  - Color: ${session.playerColor}
                `);

                // Save the updated session
                sessionStorage.setItem(
                  "ludo_game_session",
                  JSON.stringify(session)
                );

                // Try to automatically rejoin if in an active game
                if (session.roomCode) {
                  console.log(
                    `Attempting to automatically rejoin room ${session.roomCode} after reconnection`
                  );

                  // Let the socket finish connecting first
                  setTimeout(() => {
                    if (socket && socket.connected) {
                      // Emit rejoin-room with player data including originalId
                      socket.emit(
                        "rejoin-room",
                        {
                          roomCode: session.roomCode,
                          playerData: {
                            name: session.playerName,
                            color: session.playerColor,
                            originalId: session.originalId,
                          },
                        },
                        (success: boolean, roomData: any) => {
                          if (success) {
                            console.log(
                              `Auto-rejoined room ${session.roomCode} successfully`
                            );
                            if (roomData) {
                              console.log("Room data received:", roomData);
                            }
                          } else {
                            console.error(
                              `Failed to auto-rejoin room ${session.roomCode}`
                            );
                          }
                        }
                      );
                    }
                  }, 500);
                }
              }
            }
          } catch (err) {
            console.error("Error checking for session after reconnect:", err);
          }
        }
      });

      socket.on("disconnect", (reason) => {
        console.log(`Socket disconnected. Reason: ${reason}`);
      });

      socket.on("connect_error", (error) => {
        console.error("Socket connection error:", error.message);
        console.log("Will attempt to reconnect automatically");

        reconnectAttempts++;
        if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
          console.log(
            "Max reconnection attempts reached. Attempting transport fallback."
          );

          // Try to reconnect with a different transport as last resort
          if (socket) {
            socket.io.opts.transports = ["polling", "websocket"];
          }
        }
      });

      socket.on("reconnect_attempt", (attemptNumber) => {
        console.log(`Socket reconnection attempt #${attemptNumber}`);
      });

      socket.on("reconnect", (attemptNumber) => {
        console.log(`Socket reconnected after ${attemptNumber} attempts`);
      });

      socket.on("error", (error) => {
        console.error("Socket error:", error);
      });

      isInitialized = true;
    } catch (err) {
      console.error("Failed to initialize socket:", err);
    }
  } else {
    console.log("Socket already initialized");
  }

  return socket;
};

// Initialize the socket right away
initializeSocket();

export const useSocket = () => {
  const [connected, setConnected] = useState(socket?.connected || false);

  useEffect(() => {
    // Make sure socket is initialized
    if (!socket) {
      initializeSocket();
    }

    // Set initial connected state
    setConnected(socket?.connected || false);

    // Setup event listeners for connection status changes
    const onConnect = () => {
      console.log("Socket connected in component");
      setConnected(true);
    };

    const onDisconnect = () => {
      console.log("Socket disconnected in component");
      setConnected(false);
    };

    if (socket) {
      socket.on("connect", onConnect);
      socket.on("disconnect", onDisconnect);
    }

    // Clean up listeners when component unmounts
    return () => {
      if (socket) {
        socket.off("connect", onConnect);
        socket.off("disconnect", onDisconnect);
      }
    };
  }, []);

  // Create room handler
  const createRoom = useCallback((playerName: string) => {
    return new Promise<string>((resolve, reject) => {
      if (!socket) {
        reject(new Error("Socket not connected"));
        return;
      }

      console.log(`Attempting to create room for player: ${playerName}`);
      socket.emit("create-room", playerName, (roomCode: string) => {
        console.log("Room created successfully with code:", roomCode);
        // Play sound when room is created
        soundManager?.play("open", 0.7);
        resolve(roomCode);
      });
    });
  }, []); // Join room handler
  const joinRoom = useCallback((roomCode: string, playerName: string) => {
    return new Promise<RoomData>((resolve, reject) => {
      if (!socket) {
        reject(new Error("Socket not connected"));
        return;
      }

      console.log(
        `Attempting to join room ${roomCode} for player: ${playerName}`
      );
      socket.emit(
        "join-room",
        roomCode,
        playerName,
        (success: boolean, message: string, roomData?: RoomData) => {
          if (success && roomData) {
            // Play sound on successful join
            soundManager?.play("open", 0.7);
            console.log("Successfully joined room with data:", roomData);
            console.log(
              "Players in room:",
              roomData.players.map((p) => `${p.name} (${p.id})`)
            );

            // Listen once for room-update to make sure we have the most current data
            if (socket) {
              socket.once("room-update", (updatedRoomData) => {
                console.log(
                  "Received room-update after joining:",
                  updatedRoomData
                );
                resolve(updatedRoomData);
              });
            }

            // Also resolve with the current data in case room-update doesn't come
            setTimeout(() => {
              resolve(roomData);
            }, 500);
          } else {
            console.error(`Failed to join room: ${message}`);
            reject(new Error(message));
          }
        }
      );
    });
  }, []); // Rejoin room handler for reconnecting to an existing game
  const rejoinRoom = useCallback(
    (
      roomCode: string,
      playerData?: { name?: string; color?: string; originalId?: string }
    ) => {
      return new Promise<boolean>((resolve, reject) => {
        if (!socket) {
          reject(new Error("Socket not connected"));
          return;
        }
        console.log(
          `Attempting to rejoin room ${roomCode}${
            playerData ? ` with player data: ${JSON.stringify(playerData)}` : ""
          }`
        );

        // Include the current socket ID in the log
        if (socket && socket.id) {
          console.log(`Current socket ID for rejoin: ${socket.id}`);
        }

        socket.emit(
          "rejoin-room",
          { roomCode, playerData },
          (success: boolean, roomData?: any) => {
            if (success) {
              console.log(`Successfully rejoined room ${roomCode}`);
              if (roomData) {
                console.log("Received room data:", roomData);
                // Log the player IDs in the room for debugging
                if (roomData.players) {
                  console.log(
                    "Players in rejoined room:",
                    roomData.players.map(
                      (p: any) =>
                        `${p.name} (ID: ${p.id}, Original ID: ${
                          p.originalId || "none"
                        }, Disconnected: ${p.isDisconnected || false})`
                    )
                  );
                }
              }
              resolve(true);
            } else {
              console.error(`Failed to rejoin room ${roomCode}`);
              resolve(false); // Resolve with false instead of reject to indicate room not available
            }
          }
        );
      });
    },
    []
  );
  // Roll dice handler
  const rollDice = useCallback((roomCode: string, clientDiceValue?: number) => {
    if (!socket) {
      console.error("Cannot roll dice: Socket not connected");
      return;
    }

    // Play dice rolling sound
    soundManager?.play("dice", 0.8);

    // Log socket connection status for debugging
    console.log(`Socket connected: ${socket.connected}, ID: ${socket.id}`);

    // Add a confirmation listener for debugging purposes
    const confirmHandler = (data: any) => {
      console.log("Received dice-rolled confirmation:", data);
    };

    socket.once("dice-rolled", confirmHandler);

    // Set a timeout to remove the listener if no response
    setTimeout(() => {
      if (socket) {
        socket.off("dice-rolled", confirmHandler);
      }
    }, 3000); // Emit the roll dice event
    // Always provide a client dice value
    const valueToSend =
      clientDiceValue !== undefined
        ? clientDiceValue
        : Math.floor(Math.random() * 6) + 1;

    console.log(
      `Rolling dice in room ${roomCode} with client value: ${valueToSend}`
    );
    socket.emit("roll-dice", roomCode, valueToSend);
  }, []);
  // Move token handler
  const moveToken = useCallback((roomCode: string, tokenId: number) => {
    if (!socket) {
      console.error("Cannot move token: Socket not connected");
      return;
    }

    // Sound effects are now handled by the animation steps

    console.log(`Moving token ${tokenId} in room ${roomCode}`);
    socket.emit("move-token", roomCode, tokenId);
  }, []);

  // Send message handler
  const sendMessage = useCallback((roomCode: string, emoji: string) => {
    if (!socket) {
      console.error("Cannot send message: Socket not connected");
      return;
    }

    console.log(`Sending emoji message in room ${roomCode}`);
    socket.emit("send-message", roomCode, emoji);
  }, []);
  // Request room state for token synchronization
  const requestRoomState = useCallback((roomCode: string) => {
    if (!socket) {
      console.error("Cannot request room state: Socket not connected");
      return;
    }

    console.log(`Requesting room state for room ${roomCode}`);
    socket.emit("request-room-state", roomCode);
  }, []);

  // Toggle player ready state
  const toggleReady = useCallback((roomCode: string) => {
    if (!socket) {
      console.error("Cannot toggle ready: Socket not connected");
      return;
    }

    console.log(`Toggling ready state in room ${roomCode}`);
    socket.emit("toggle-ready", roomCode);
  }, []);

  // Start game (host only)
  const startGame = useCallback((roomCode: string) => {
    if (!socket) {
      console.error("Cannot start game: Socket not connected");
      return;
    }

    console.log(`Host starting game in room ${roomCode}`);
    socket.emit("start-game", roomCode);
  }, []);

  // Listen for events
  const onEvent = useCallback(
    <T>(event: string, callback: (data: T) => void) => {
      if (!socket) {
        console.error(`Cannot listen for ${event}: Socket not connected`);
        return () => {}; // Return no-op cleanup function
      }

      socket.on(event, callback);
      return () => {
        if (socket) {
          socket.off(event, callback);
        }
      };
    },
    []
  );
  return {
    socket,
    connected,
    createRoom,
    joinRoom,
    rejoinRoom,
    rollDice,
    moveToken,
    sendMessage,
    requestRoomState,
    toggleReady,
    startGame,
    onEvent,
  };
};
