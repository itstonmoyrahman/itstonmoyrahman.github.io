"use client";

import { useCallback, useEffect, useState } from "react";
import { useSocket } from "./client";
import { RoomData } from "@/lib/game/types";

// Custom hook for room creation
export function useCreateRoom(onSuccess: (roomCode: string) => void) {
  const { socket, connected, createRoom: socketCreateRoom } = useSocket();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setReady(connected && !!socket);
  }, [connected, socket]);

  const createRoom = useCallback(
    async (playerName: string) => {
      try {
        if (!socketCreateRoom) return;
        const roomCode = await socketCreateRoom(playerName);
        if (onSuccess) {
          onSuccess(roomCode);
        }
      } catch (error) {
        console.error("Failed to create room:", error);
      }
    },
    [socketCreateRoom, onSuccess]
  );

  return { createRoom, ready };
}

// Custom hook for joining rooms
export function useJoinRoom(
  onSuccess: (roomData: RoomData) => void,
  onError: (message: string) => void
) {
  const { socket, connected, joinRoom: socketJoinRoom } = useSocket();
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setReady(connected && !!socket);
  }, [connected, socket]);

  const joinRoom = useCallback(
    async (roomCode: string, playerName: string) => {
      try {
        if (!socketJoinRoom) return;
        const roomData = await socketJoinRoom(roomCode, playerName);
        if (onSuccess) {
          onSuccess(roomData);
        }
      } catch (error) {
        if (onError && error instanceof Error) {
          onError(error.message);
        } else {
          onError("Failed to join room due to an unknown error");
        }
      }
    },
    [socketJoinRoom, onSuccess, onError]
  );

  return { joinRoom, ready };
}
