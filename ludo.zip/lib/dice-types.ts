// Make typescript recognize window.diceRollSafetyTimeoutId
declare global {
  interface Window {
    diceRollSafetyTimeoutId: NodeJS.Timeout | null;
  }
}

export {};
