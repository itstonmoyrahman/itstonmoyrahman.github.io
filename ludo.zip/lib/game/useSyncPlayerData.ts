"use client";

import { useEffect } from "react";
import { useSocket } from "@/lib/socket/client";
import { Player, TokenPosition } from "@/lib/game/types";

export function useSyncPlayerData(roomCode: string, players: Player[], onPlayerDataFixed: (fixedPlayers: Player[]) => void) {
  const { socket, connected } = useSocket();

  // Force a token sync when players data has issues
  useEffect(() => {
    if (!connected || !socket || !roomCode || !players.length) return;

    // Check for players with missing or invalid tokens
    const hasInvalidTokens = players.some(
      (player) => 
        !player.tokens || 
        !Array.isArray(player.tokens) || 
        player.tokens.length !== 4 ||
        player.tokens.some(t => !t.position)
    );

    if (hasInvalidTokens) {
      console.log("Found players with invalid tokens, fixing...");
      
      // Fix the players tokens
      const fixedPlayers = players.map(player => {
        if (!player.tokens || !Array.isArray(player.tokens) || player.tokens.length !== 4) {
          return {
            ...player,
            tokens: [
              { id: 0, position: "home" as TokenPosition, steps: 0 },
              { id: 1, position: "home" as TokenPosition, steps: 0 },
              { id: 2, position: "home" as TokenPosition, steps: 0 },
              { id: 3, position: "home" as TokenPosition, steps: 0 },
            ]
          };
        }
        
        // Check for individual invalid tokens
        const hasInvalidToken = player.tokens.some(t => !t.position);
        if (hasInvalidToken) {
          return {
            ...player,
            tokens: player.tokens.map(token => {
              if (!token.position) {
                return { ...token, position: "home" as TokenPosition, steps: 0 };
              }
              return token;
            })
          };
        }
        
        return player;
      });
      
      // Report the fixed players
      onPlayerDataFixed(fixedPlayers);
      
      // Force a room state update from server
      socket.emit("request-room-state", roomCode);
    }
  }, [connected, socket, roomCode, players, onPlayerDataFixed]);

  return null;
}
