"use client";

import { Player } from "@/lib/game/types";

const SESSION_KEY = "ludo_game_session";

interface GameSession {
  roomCode: string;
  playerName: string;
  playerId: string;
  originalId?: string; // Store the original socket ID for reconnection
  playerColor?: string; // Store player color for reconnection
  joinedAt: number;
  lastActive: number;
}

/**
 * Save the player's game session to localStorage
 */
export function saveGameSession(
  roomCode: string,
  playerName: string,
  playerId: string,
  playerColor?: string,
  originalId?: string
): void {
  if (typeof window === "undefined") return;

  // If there's an existing session with this room code, update it and keep the original ID
  const existingSession = getGameSession();
  const useOriginalId = originalId || existingSession?.originalId || playerId;

  const session: GameSession = {
    roomCode,
    playerName,
    playerId,
    originalId: useOriginalId, // Store original ID for reconnection
    playerColor,
    joinedAt: existingSession?.joinedAt || Date.now(),
    lastActive: Date.now(),
  };

  try {
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    console.log(
      `Game session saved for player ${playerName} (${
        playerColor || "no color"
      }) in room ${roomCode}. Original ID: ${useOriginalId}`
    );
  } catch (error) {
    console.error("Failed to save game session to localStorage:", error);
  }
}

/**
 * Get the player's active game session from localStorage
 */
export function getGameSession(): GameSession | null {
  if (typeof window === "undefined") return null;

  try {
    const sessionJson = localStorage.getItem(SESSION_KEY);
    if (!sessionJson) return null;

    const session = JSON.parse(sessionJson) as GameSession;

    // Session is considered valid if it's less than 24 hours old
    const maxSessionAge = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
    if (Date.now() - session.joinedAt > maxSessionAge) {
      clearGameSession();
      return null;
    }

    return session;
  } catch (error) {
    console.error("Failed to retrieve game session from localStorage:", error);
    return null;
  }
}

/**
 * Update the last active timestamp of the current session
 */
export function updateSessionActivity(): void {
  if (typeof window === "undefined") return;

  try {
    const sessionJson = localStorage.getItem(SESSION_KEY);
    if (!sessionJson) return;

    const session = JSON.parse(sessionJson) as GameSession;
    session.lastActive = Date.now();

    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  } catch (error) {
    console.error("Failed to update session activity:", error);
  }
}

/**
 * Clear the player's game session from localStorage
 */
export function clearGameSession(): void {
  if (typeof window === "undefined") return;

  try {
    localStorage.removeItem(SESSION_KEY);
    console.log("Game session cleared");
  } catch (error) {
    console.error("Failed to clear game session from localStorage:", error);
  }
}
