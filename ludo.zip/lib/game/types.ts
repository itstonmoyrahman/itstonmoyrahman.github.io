export type TokenPosition = "home" | "board" | "finished";

export interface Token {
  id: number;
  position: TokenPosition;
  steps: number;
}

export interface Player {
  id: string;
  name: string;
  color: "red" | "green" | "blue" | "yellow";
  isHost: boolean;
  isReady: boolean;
  isDisconnected?: boolean;
  disconnectPending?: boolean;
  disconnectTime?: number;
  disconnectTimeoutId?: NodeJS.Timeout;
  originalId?: string; // Store the original socket ID for reconnection
  tokens: Token[];
}

export type GameState = "waiting" | "playing" | "paused" | "finished";

export interface Message {
  id: string;
  playerId: string;
  playerName: string;
  playerColor: string;
  content: string;
  timestamp: string;
}

export interface Room {
  code: string;
  players: Player[];
  gameState: GameState;
  currentTurn: number;
  messages: Message[];
  dice: number;
  maxPlayers?: number;
}

export interface RoomData {
  code: string;
  players: Player[];
  gameState: GameState;
  currentTurn: number;
  messages: Message[];
  dice: number;
  maxPlayers?: number;
}

export interface Position {
  x: number;
  y: number;
}

export interface BoardPosition {
  [color: string]: {
    home: Position[];
    start: Position;
    path: Position[];
    finish: Position[];
  };
}
