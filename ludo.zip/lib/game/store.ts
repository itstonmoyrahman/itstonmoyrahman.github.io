import { create } from "zustand";
import { Player, RoomData, Message, GameState } from "./types";

interface GameStore {
  // Room data
  roomCode: string;
  players: Player[];
  gameState: GameState;
  currentTurn: number;
  currentPlayer: Player | null;
  messages: Message[];
  dice: number;
  lastRoll: number;
  isRolling: boolean;
  hasDiceBeenRolled: boolean; // Track if dice has been rolled for the current turn
  maxPlayers: number; // Maximum number of players allowed in the room

  // Player data
  playerId: string;
  playerName: string;

  // UI state
  selectedTokenId: number | null;

  // Actions
  setRoomData: (data: RoomData) => void;
  setPlayerId: (id: string) => void;
  setPlayerName: (name: string) => void;
  addPlayer: (player: Player) => void;
  removePlayer: (playerId: string) => void;
  updateGameState: (state: GameState) => void;
  setCurrentTurn: (turn: number) => void;
  setDice: (value: number) => void;
  setLastRoll: (value: number) => void;
  setIsRolling: (isRolling: boolean) => void;
  setHasDiceBeenRolled: (hasRolled: boolean) => void; // Add function to set if dice has been rolled
  addMessage: (message: Message) => void;
  setSelectedTokenId: (id: number | null) => void;
  resetGame: () => void;
  updatePlayerReady: (playerId: string, isReady: boolean) => void;
  setMaxPlayers: (count: number) => void; // Set maximum players allowed
}

export const useGameStore = create<GameStore>((set, get) => ({
  roomCode: "",
  players: [],
  gameState: "waiting",
  currentTurn: 0,
  currentPlayer: null,
  messages: [],
  dice: 0,
  lastRoll: 0,
  isRolling: false,
  hasDiceBeenRolled: false,
  maxPlayers: 4, // Default to 4 players max

  playerId: "",
  playerName: "",

  selectedTokenId: null,

  setRoomData: (data) =>
    set({
      roomCode: data.code,
      players: data.players,
      gameState: data.gameState,
      currentTurn: data.currentTurn,
      messages: data.messages,
      dice: data.dice,
      currentPlayer: data.players[data.currentTurn] || null,
      maxPlayers: data.maxPlayers || 4, // Use provided maxPlayers or default to 4
    }),

  setPlayerId: (id) => set({ playerId: id }),

  setPlayerName: (name) => set({ playerName: name }),

  addPlayer: (player) => {
    set((state) => ({
      players: [...state.players, player],
    }));
  },

  removePlayer: (playerId) => {
    set((state) => {
      const newPlayers = state.players.filter((p) => p.id !== playerId);

      // Update current player if needed
      const newCurrentPlayer = newPlayers[state.currentTurn] || null;

      return {
        players: newPlayers,
        currentPlayer: newCurrentPlayer,
      };
    });
  },

  updateGameState: (state) => set({ gameState: state }),

  setCurrentTurn: (turn) =>
    set((state) => ({
      currentTurn: turn,
      currentPlayer: state.players[turn] || null,
    })),

  setDice: (value) => set({ dice: value }),

  setLastRoll: (value) => set({ lastRoll: value }),

  setIsRolling: (isRolling) => set({ isRolling }),

  setHasDiceBeenRolled: (hasRolled) => set({ hasDiceBeenRolled: hasRolled }), // Set hasDiceBeenRolled

  addMessage: (message) =>
    set((state) => ({
      messages: [...state.messages, message],
    })),

  setSelectedTokenId: (id) => set({ selectedTokenId: id }),

  resetGame: () =>
    set({
      roomCode: "",
      players: [],
      gameState: "waiting",
      currentTurn: 0,
      currentPlayer: null,
      messages: [],
      dice: 0,
      lastRoll: 0,
      isRolling: false,
      hasDiceBeenRolled: false, // Reset hasDiceBeenRolled
      selectedTokenId: null,
    }),

  updatePlayerReady: (playerId, isReady) =>
    set((state) => {
      const updatedPlayers = state.players.map((player) => {
        if (player.id === playerId) {
          return { ...player, isReady };
        }
        return player;
      });

      // Update current player reference if the updated player is the current player
      const isCurrentPlayerUpdated =
        state.currentPlayer && state.currentPlayer.id === playerId;
      const updatedCurrentPlayer = isCurrentPlayerUpdated
        ? updatedPlayers.find((p) => p.id === playerId) || null
        : state.currentPlayer;

      return {
        players: updatedPlayers,
        currentPlayer: updatedCurrentPlayer,
      };
    }),

  setMaxPlayers: (count) => set({ maxPlayers: count }),
}));
