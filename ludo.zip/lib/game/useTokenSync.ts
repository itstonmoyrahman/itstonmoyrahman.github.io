"use client";

import { useEffect } from "react";
import { useGameStore } from "@/lib/game/store";
import { TokenPosition } from "@/lib/game/types";

// This hook ensures that player tokens are properly synchronized across all clients
export function useTokenSync() {
  const { players, setRoomData, roomCode, gameState, currentTurn, messages } =
    useGameStore();

  // Use an effect to ensure token data is present and properly formatted for all players
  useEffect(() => {
    // Only run this check if we have players
    if (players.length > 0) {
      let needsUpdate = false;

      // Check if any player has missing token data
      const updatedPlayers = players.map((player) => {
        // If player has no tokens or incomplete tokens, restore them to default
        if (!player.tokens || player.tokens.length !== 4) {
          console.log(`Fixing tokens for player ${player.name}`);
          needsUpdate = true;

          // Create default tokens (4 tokens at home)
          return {
            ...player,
            tokens: [
              { id: 0, position: "home" as TokenPosition, steps: 0 },
              { id: 1, position: "home" as TokenPosition, steps: 0 },
              { id: 2, position: "home" as TokenPosition, steps: 0 },
              { id: 3, position: "home" as TokenPosition, steps: 0 },
            ],
          };
        }

        // Check if any individual token is missing position data
        const fixedTokens = player.tokens.map((token) => {
          if (!token.position) {
            needsUpdate = true;
            return { ...token, position: "home" as TokenPosition, steps: 0 };
          }
          return token;
        });

        if (JSON.stringify(fixedTokens) !== JSON.stringify(player.tokens)) {
          needsUpdate = true;
          return { ...player, tokens: fixedTokens };
        }

        return player;
      });

      // If we found issues and fixed them, update the game store
      if (needsUpdate && roomCode) {
        console.log("Synchronizing token data for all players");
        setRoomData({
          code: roomCode,
          players: updatedPlayers,
          gameState,
          currentTurn,
          messages: messages || [], // Ensure messages is always an array
          dice: 0,
        });
      }
    }
  }, [players, setRoomData, roomCode, gameState, currentTurn, messages]);

  return null; // This hook doesn't need to return anything
}
