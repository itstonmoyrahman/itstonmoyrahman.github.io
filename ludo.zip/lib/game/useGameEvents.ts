"use client";

import { useEffect, useCallback } from "react";
import { useSocket } from "@/lib/socket/client";
import { Player, Message } from "@/lib/game/types";
import soundManager from "@/lib/sound/soundManager";

export function useGameEvents(
  handlePlayerJoined: (player: Player) => void,
  handleGameStarted: (roomData: any) => void,
  handleDiceRolled: (data: { playerId: string; diceValue: number }) => void,
  handleTokenMoved: (data: {
    playerId: string;
    tokenId: number;
    newPosition: string;
    steps: number;
    reason?: string;
  }) => void,
  handleNextTurn: (data: { currentTurn: number; reason?: string }) => void,
  handleExtraTurn: (data: {
    currentTurn: number;
    playerId: string;
    playerName: string;
  }) => void,
  handleGameOver: (data: {
    winnerId: string;
    winner: Player;
    reason?: string;
  }) => void,
  handlePlayerDisconnected: (data: {
    playerId: string;
    playerName: string;
    isDisconnected: boolean;
    gameState?: string;
  }) => void,
  handleNewMessage: (message: Message) => void,
  handlePlayerReadyChanged?: (data: {
    playerId: string;
    isReady: boolean;
  }) => void,
  handleInvalidMove?: (data: { message: string }) => void,
  handlePlayerCountUpdated?: (data: {
    maxPlayers: number;
    players: Player[];
  }) => void,
  handleGameReset?: (roomData: any) => void,
  handlePlayerReconnected?: (data: {
    playerId: string;
    playerName: string;
    gameState?: string;
  }) => void,
  handlePlayerTemporaryDisconnect?: (data: {
    playerId: string;
    playerName: string;
    gameState?: string;
  }) => void
) {
  const { socket } = useSocket();
  // Register all event listeners
  useEffect(() => {
    if (!socket) return; // Player joined
    socket.on("player-joined", (player) => {
      // Play join sound
      soundManager?.play("open", 0.6);
      handlePlayerJoined(player);
    }); // Game started
    // Game started
    socket.on("game-started", (roomData) => {
      // Play sound when game starts
      soundManager?.play("open", 0.8);
      handleGameStarted(roomData);
    });

    // Room update (sync state)
    socket.on("room-update", (roomData) => {
      console.log("Received room-update event with data:", roomData);
      handleGameStarted(roomData);
    });

    // Dice rolled
    socket.on("dice-rolled", (data) => {
      soundManager?.play("dice", 0.8);
      handleDiceRolled(data);
    });

    // Dice roll received confirmation
    socket.on("roll-dice-received", (data) => {
      console.log("Server acknowledged dice roll request:", data);
    }); // Token moved
    socket.on("token-moved", (data) => {
      // Play appropriate sound based on reason
      if (data.reason === "captured") {
        soundManager?.play("cut", 0.5);
      } else if (data.reason === "reached-finish") {
        // Special sound for reaching finish could be added here
        soundManager?.play("move", 0.2);
      }
      // Normal move sounds are handled by the animation steps
      handleTokenMoved(data);
    }); // Next turn
    socket.on("next-turn", handleNextTurn); // Extra turn (for rolling a 6)
    socket.on("extra-turn", handleExtraTurn); // Game over
    socket.on("game-over", (data) => {
      // Play win sound
      soundManager?.play("win", 1.0);
      handleGameOver(data);
    }); // Invalid move handler
    socket.on("invalid-move", (data) => {
      console.warn("Server rejected move as invalid:", data);
      if (handleInvalidMove) {
        handleInvalidMove(data);
      }
    });

    // Player disconnected
    socket.on("player-disconnected", handlePlayerDisconnected);

    // Player temporarily disconnected (will have 2 minutes to reconnect)
    if (handlePlayerTemporaryDisconnect) {
      socket.on("player-temporary-disconnect", handlePlayerTemporaryDisconnect);
    }

    // Player reconnected
    if (handlePlayerReconnected) {
      socket.on("player-reconnected", handlePlayerReconnected);
    }

    // New message
    socket.on("new-message", handleNewMessage); // Player ready changed
    if (handlePlayerReadyChanged) {
      socket.on("player-ready-changed", handlePlayerReadyChanged);
    } // Player count updated
    if (handlePlayerCountUpdated) {
      socket.on("player-count-updated", handlePlayerCountUpdated);
    }

    // Game reset
    if (handleGameReset) {
      socket.on("game-reset", handleGameReset);
    } // Clean up on unmount
    return () => {
      socket.off("player-joined");
      socket.off("game-started");
      socket.off("room-update");
      socket.off("dice-rolled");
      socket.off("roll-dice-received");
      socket.off("token-moved");
      socket.off("next-turn", handleNextTurn);
      socket.off("extra-turn", handleExtraTurn);
      socket.off("game-over");
      socket.off("invalid-move");
      socket.off("player-disconnected", handlePlayerDisconnected);

      if (handlePlayerTemporaryDisconnect) {
        socket.off(
          "player-temporary-disconnect",
          handlePlayerTemporaryDisconnect
        );
      }

      if (handlePlayerReconnected) {
        socket.off("player-reconnected", handlePlayerReconnected);
      }

      socket.off("new-message", handleNewMessage);
      if (handlePlayerReadyChanged) {
        socket.off("player-ready-changed", handlePlayerReadyChanged);
      }
      if (handlePlayerCountUpdated) {
        socket.off("player-count-updated", handlePlayerCountUpdated);
      }
      if (handleGameReset) {
        socket.off("game-reset", handleGameReset);
      }
    };
  }, [
    socket,
    handlePlayerJoined,
    handleGameStarted,
    handleDiceRolled,
    handleTokenMoved,
    handleNextTurn,
    handleExtraTurn,
    handleGameOver,
    handlePlayerDisconnected,
    handleNewMessage,
    handlePlayerReadyChanged,
    handleInvalidMove,
    handlePlayerCountUpdated,
    handleGameReset,
    handlePlayerReconnected,
    handlePlayerTemporaryDisconnect,
  ]); // Game action handlers

  const rollDice = useCallback(
    (roomCode: string, clientDiceValue?: number) => {
      if (socket) {
        console.log(
          "Emitting roll-dice event to server with roomCode:",
          roomCode,
          clientDiceValue ? `and client dice value: ${clientDiceValue}` : ""
        );

        // Add some validation before sending
        if (!roomCode || typeof roomCode !== "string") {
          console.error("Invalid roomCode for roll-dice event:", roomCode);
          return;
        }

        try {
          // Set up a confirmation handler BEFORE emitting
          const confirmationTimeout = setTimeout(() => {
            console.warn(
              "Did not receive roll-dice-received confirmation from server in time"
            );
            // No need to do anything here - the global safety timeout will handle recovery
          }, 1000);

          // Set up one-time confirmation handler
          socket.once("roll-dice-received", (data: any) => {
            console.log(
              "Received roll-dice-received confirmation from server:",
              data
            );
            clearTimeout(confirmationTimeout);
          }); // Always emit the event with a client dice value
          // Generate a random value if none is provided
          const valueToSend =
            clientDiceValue !== undefined
              ? clientDiceValue
              : Math.floor(Math.random() * 6) + 1;

          socket.emit("roll-dice", roomCode, valueToSend);
          console.log(
            `roll-dice event emitted with client value: ${valueToSend}`
          );

          // Log to make sure we're connected
          console.log("Socket connected status:", socket.connected);
        } catch (err) {
          console.error("Error emitting roll-dice event:", err);
        }
      } else {
        console.error("Socket not available for roll-dice event");
      }
    },
    [socket]
  );

  const moveToken = useCallback(
    (roomCode: string, tokenId: number) => {
      if (socket) {
        socket.emit("move-token", roomCode, tokenId);
      }
    },
    [socket]
  );
  const sendMessage = useCallback(
    (roomCode: string, emoji: string) => {
      if (socket) {
        // Play sound when sending a message
        soundManager?.play("pass", 0.6);
        socket.emit("send-message", roomCode, emoji);
      }
    },
    [socket]
  );

  const toggleReady = useCallback(
    (roomCode: string) => {
      if (socket) {
        socket.emit("toggle-ready", roomCode);
      }
    },
    [socket]
  );
  const startGame = useCallback(
    (roomCode: string) => {
      if (socket) {
        // Play sound when starting a game
        soundManager?.play("open", 0.7);
        socket.emit("start-game", roomCode);
      }
    },
    [socket]
  );

  // Set player count for the room (host only)
  const setPlayerCount = useCallback(
    (roomCode: string, playerCount: number) => {
      if (socket) {
        socket.emit("set-player-count", roomCode, playerCount);
      }
    },
    [socket]
  );
  // Reset game after it has finished
  const resetGame = useCallback(
    (roomCode: string) => {
      if (socket) {
        console.log("Emitting reset-game event for room:", roomCode);
        socket.emit("reset-game", roomCode);
      } else {
        console.error("Socket not available for reset-game event");
      }
    },
    [socket]
  );

  // Notify server that player is leaving the game
  const emitPlayerLeave = useCallback(
    (roomCode: string) => {
      if (socket) {
        console.log("Emitting player-leave event for room:", roomCode);
        socket.emit("player-leave", roomCode);
      } else {
        console.error("Socket not available for player-leave event");
      }
    },
    [socket]
  );

  return {
    rollDice,
    moveToken,
    sendMessage,
    toggleReady,
    startGame,
    setPlayerCount,
    resetGame,
    emitPlayerLeave,
  };
}
