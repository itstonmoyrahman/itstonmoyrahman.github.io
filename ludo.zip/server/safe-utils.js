/**
 * Safely stringifies objects by handling circular references
 * @param {Object} obj - The object to stringify
 * @returns {string} - JSON string representation without circular references
 */
function safeStringify(obj) {
  const cache = new Set();
  return JSON.stringify(obj, (key, value) => {
    if (typeof value === "object" && value !== null) {
      if (cache.has(value)) {
        return undefined; // Remove circular reference
      }
      cache.add(value);
    } else if (typeof value === "function") {
      return undefined; // Skip functions
    }
    return value;
  });
}

/**
 * Creates a safe object from a potentially circular-referenced object
 * @param {Object} obj - The object to make safe
 * @returns {Object} - A new object without circular references
 */
function createSafeObject(obj) {
  if (!obj || typeof obj !== "object") return obj;
  try {
    return JSON.parse(safeStringify(obj));
  } catch (error) {
    // Fallback to a minimal safe object with essential properties
    return {
      playerId: obj.playerId || obj.id || "",
      playerName: obj.playerName || obj.name || "",
      isDisconnected: obj.isDisconnected || false,
    };
  }
}

/**
 * Safely prepares player data for socket transmission
 * @param {Object} player - The player object
 * @returns {Object} - A safe player object without circular references
 */
function createSafePlayer(player) {
  if (!player) return null;

  const safePlayer = {
    id: player.id || "",
    name: player.name || "",
    color: player.color || "",
    isHost: player.isHost || false,
    isReady: player.isReady || false,
    isDisconnected: player.isDisconnected || false,
  };

  // Include tokens if they exist
  if (player.tokens && Array.isArray(player.tokens)) {
    safePlayer.tokens = player.tokens.map((token) => ({
      id: token.id,
      position: token.position,
      steps: token.steps,
    }));
  }

  return safePlayer;
}

module.exports = {
  safeStringify,
  createSafeObject,
  createSafePlayer,
};
