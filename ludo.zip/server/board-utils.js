/**
 * Special safe positions where tokens cannot be captured
 * @type {number[]}
 */
const safePositions = [
  0, 8, 13, 21, 26, 34, 39, 47, 50, 51, 52, 53, 54, 55, 56, 57,
];

/**
 * Simple function to calculate token's new position after dice roll
 *
 * @param {Token} token - The token to check
 * @param {number} diceValue - The dice roll value
 * @param {Player} player - The player who owns the token
 * @returns {number} - The new steps value
 */
function calculateNewPosition(token, diceValue, player) {
  let newSteps = token.steps + diceValue;

  // Only log if the token is on the board (not in home or finished position)
  if (token.position === "board") {
    console.log(`Token movement details for ${player.color} token:`);
    console.log(`- Starting position: ${token.steps}`);
    console.log(`- Dice roll: ${diceValue}`);
    console.log(`- Final position: ${newSteps}`);
  }

  return newSteps;
}

/**
 * Check if the token is on a safe position where it cannot be captured
 * @param {number} steps - The number of steps the token has taken
 * @returns {boolean} - Whether the position is safe
 */
function isSafePosition(steps) {
  return safePositions.includes(steps);
}

module.exports = {
  safePositions,
  calculateNewPosition,
  isSafePosition,
};
