/**
 * This file contains the standard Ludo game rules implementation
 * Centralizing game logic for better maintainability
 */

/**
 * Checks if a token can be moved
 *
 * @param {Object} token - The token to check
 * @param {number} diceValue - The dice roll value
 * @param {Object} player - The player who owns the token
 * @returns {boolean} - Whether the token can be moved
 */
function canMoveToken(token, diceValue, player) {
  // Need a 6 to move a token out of home
  if (token.position === "home") {
    return diceValue === 6;
  }

  // Can't move tokens that are already finished
  if (token.position === "finished") {
    return false;
  }

  // For tokens on the board, check if moving would exceed the finish line
  if (token.position === "board") {
    const newSteps = token.steps + diceValue;
    return newSteps <= 56; // Max steps in standard Ludo is 56
  }

  return false;
}

/**
 * Checks if a player has any valid moves with current dice roll
 *
 * @param {Object} player - The player to check
 * @param {number} diceValue - The dice roll value
 * @returns {boolean} - Whether the player has any valid moves
 */
function hasValidMoves(player, diceValue) {
  return player.tokens.some((token) => canMoveToken(token, diceValue, player));
}

/**
 * Handles token movement according to Ludo rules
 *
 * @param {Object} token - The token to move
 * @param {number} diceValue - The dice roll value
 * @param {Object} player - The player who owns the token
 * @returns {Object} - Result containing whether move is valid and updated token
 */
function moveToken(token, diceValue, player) {
  // Clone the token to avoid modifying the original
  const updatedToken = { ...token };
  let validMove = false;

  // Moving from home to board (requires a 6)
  if (token.position === "home" && diceValue === 6) {
    updatedToken.position = "board";
    updatedToken.steps = 0;
    validMove = true;
  }
  // Moving on the board
  else if (token.position === "board") {
    const newSteps = token.steps + diceValue;

    // Check if move would exceed finish line
    if (newSteps > 56) {
      validMove = false;
    } else {
      updatedToken.steps = newSteps;
      validMove = true;

      // Check if token has reached finish
      if (newSteps >= 56) {
        updatedToken.position = "finished";
        updatedToken.steps = 56;
      }
    }
  }

  return {
    validMove,
    token: updatedToken,
  };
}

/**
 * Determines if player gets an extra turn based on standard Ludo rules
 *
 * @param {number} diceValue - The dice roll value
 * @param {boolean} reachedHome - Whether a token reached home
 * @param {boolean} capturedToken - Whether a token was captured
 * @returns {boolean} - Whether player gets an extra turn
 */
function getsExtraTurn(diceValue, reachedHome = false, capturedToken = false) {
  // In standard Ludo rules, player gets an extra turn when:
  // 1. Rolling a 6
  // 2. A token reaches the finish line (home)
  return diceValue === 6 || reachedHome;
}

/**
 * Checks if a player has won the game
 *
 * @param {Object} player - The player to check
 * @returns {boolean} - Whether the player has won
 */
function hasPlayerWon(player) {
  return player.tokens.every((token) => token.position === "finished");
}

module.exports = {
  canMoveToken,
  hasValidMoves,
  moveToken,
  getsExtraTurn,
  hasPlayerWon,
};
