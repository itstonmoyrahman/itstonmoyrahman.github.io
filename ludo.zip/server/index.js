const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");
const { calculateNewPosition, safePositions } = require("./board-utils");
const { createSafeObject, createSafePlayer } = require("./safe-utils");
const {
  canMoveToken,
  hasValidMoves,
  moveToken,
  getsExtraTurn,
  hasPlayerWon,
} = require("./ludo-rules");

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin:
      process.env.NODE_ENV === "production"
        ? ["https://your-domain.com"]
        : ["http://localhost:3000"],
    methods: ["GET", "POST"],
    credentials: true,
  },
});

// In-memory storage
/**
 * @typedef {Object} Token
 * @property {number} id - The token ID (0-3)
 * @property {'home'|'board'|'finished'} position - Current position type
 * @property {number} steps - Number of steps taken on the board
 */

/**
 * @typedef {Object} Player
 * @property {string} id - Socket ID of the player
 * @property {string} name - Display name of the player
 * @property {'red'|'green'|'blue'|'yellow'} color - Player color
 * @property {boolean} isHost - Whether this player is the host
 * @property {boolean} isReady - Whether player is ready to start
 * @property {Token[]} tokens - Array of 4 tokens
 */

/**
 * @typedef {Object} Room
 * @property {string} code - Unique room code
 * @property {Player[]} players - Array of players
 * @property {'waiting'|'playing'|'finished'} gameState - Current game state
 * @property {number} currentTurn - Index of player whose turn it is
 * @property {boolean} currentPlayerHasRolled - Whether current player has rolled
 * @property {Array} messages - Chat messages
 * @property {number} dice - Current dice value (0 if not rolled)
 */

/** @type {Map<string, Room>} */
const rooms = new Map();

const randomRoomCode = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// Standard player colors in 3-4 player games
const defaultPlayerColors = ["red", "green", "blue", "yellow"];
// Special colors for 2-player games (red vs yellow)
const twoPlayerColors = ["red", "yellow"];

// Function to get the appropriate color based on player count
const getPlayerColors = (room) => {
  // For 2-player games, use red and yellow
  if (room.maxPlayers === 2) {
    return twoPlayerColors;
  }
  // Otherwise use the default order
  return defaultPlayerColors;
};

// Red path: Starts at (6,1)
const redPath = [
  // Starting point
  { row: 6, col: 1 }, // 0
  { row: 6, col: 2 }, // 1
  { row: 6, col: 3 }, // 2
  { row: 6, col: 4 }, // 3
  { row: 6, col: 5 }, // 4
  { row: 5, col: 6 }, // 5
  { row: 4, col: 6 }, // 6
  { row: 3, col: 6 },
  { row: 2, col: 6 },
  { row: 1, col: 6 },
  { row: 0, col: 6 },
  { row: 0, col: 7 },
  { row: 0, col: 8 },
  { row: 1, col: 8 },
  { row: 2, col: 8 },
  { row: 3, col: 8 },
  { row: 4, col: 8 },
  { row: 5, col: 8 },
  { row: 6, col: 9 },
  { row: 6, col: 10 },
  { row: 6, col: 11 },
  { row: 6, col: 12 },
  { row: 6, col: 13 },
  { row: 6, col: 14 },
  { row: 7, col: 14 },
  { row: 8, col: 14 },
  { row: 8, col: 13 },
  { row: 8, col: 12 },
  { row: 8, col: 11 },
  { row: 8, col: 10 },
  { row: 8, col: 9 },
  { row: 9, col: 8 },
  { row: 10, col: 8 },
  { row: 11, col: 8 },
  { row: 12, col: 8 },
  { row: 13, col: 8 },
  { row: 14, col: 8 },
  { row: 14, col: 7 },
  { row: 14, col: 6 },
  { row: 13, col: 6 },
  { row: 12, col: 6 },
  { row: 11, col: 6 },
  { row: 10, col: 6 },
  { row: 9, col: 6 },
  { row: 8, col: 5 },
  { row: 8, col: 4 },
  { row: 8, col: 3 },
  { row: 8, col: 2 },
  { row: 8, col: 1 },
  { row: 8, col: 0 },
  { row: 7, col: 0 },
  { row: 7, col: 1 },
  { row: 7, col: 2 },
  { row: 7, col: 3 },
  { row: 7, col: 4 },
  { row: 7, col: 5 },
  { row: 7, col: 6 },
];

// Green path: Starts at (1,8)
const greenPath = [
  // Starting point
  { row: 1, col: 8 },
  { row: 2, col: 8 },
  { row: 3, col: 8 },
  { row: 4, col: 8 },
  { row: 5, col: 8 },
  { row: 6, col: 9 },
  { row: 6, col: 10 },
  { row: 6, col: 11 },
  { row: 6, col: 12 },
  { row: 6, col: 13 },
  { row: 6, col: 14 },
  { row: 7, col: 14 },
  { row: 8, col: 14 },
  { row: 8, col: 13 },
  { row: 8, col: 12 },
  { row: 8, col: 11 },
  { row: 8, col: 10 },
  { row: 8, col: 9 },
  { row: 9, col: 8 },
  { row: 10, col: 8 },
  { row: 11, col: 8 },
  { row: 12, col: 8 },
  { row: 13, col: 8 },
  { row: 14, col: 8 },
  { row: 14, col: 7 },
  { row: 14, col: 6 },
  { row: 13, col: 6 },
  { row: 12, col: 6 },
  { row: 11, col: 6 },
  { row: 10, col: 6 },
  { row: 9, col: 6 },
  { row: 8, col: 5 },
  { row: 8, col: 4 },
  { row: 8, col: 3 },
  { row: 8, col: 2 },
  { row: 8, col: 1 },
  { row: 8, col: 0 },
  { row: 7, col: 0 },
  { row: 6, col: 0 },
  { row: 6, col: 1 },
  { row: 6, col: 2 },
  { row: 6, col: 3 },
  { row: 6, col: 4 },
  { row: 6, col: 5 },
  { row: 5, col: 6 },
  { row: 4, col: 6 },
  { row: 3, col: 6 },
  { row: 2, col: 6 },
  { row: 1, col: 6 },
  { row: 0, col: 6 },
  { row: 0, col: 7 },
  { row: 1, col: 7 },
  { row: 2, col: 7 },
  { row: 3, col: 7 },
  { row: 4, col: 7 },
  { row: 5, col: 7 },
  { row: 6, col: 7 },
];

const bluePath = [
  { row: 13, col: 6 },
  { row: 12, col: 6 },
  { row: 11, col: 6 },
  { row: 10, col: 6 },
  { row: 9, col: 6 },
  { row: 8, col: 5 },
  { row: 8, col: 4 },
  { row: 8, col: 3 },
  { row: 8, col: 2 },
  { row: 8, col: 1 },
  { row: 8, col: 0 },
  { row: 7, col: 0 },
  { row: 6, col: 0 },
  { row: 6, col: 1 },
  { row: 6, col: 2 },
  { row: 6, col: 3 },
  { row: 6, col: 4 },
  { row: 6, col: 5 },
  { row: 5, col: 6 },
  { row: 4, col: 6 },
  { row: 3, col: 6 },
  { row: 2, col: 6 },
  { row: 1, col: 6 },
  { row: 0, col: 6 },
  { row: 0, col: 7 },
  { row: 0, col: 8 },
  { row: 1, col: 8 },
  { row: 2, col: 8 },
  { row: 3, col: 8 },
  { row: 4, col: 8 },
  { row: 5, col: 8 },
  { row: 6, col: 9 },
  { row: 6, col: 10 },
  { row: 6, col: 11 },
  { row: 6, col: 12 },
  { row: 6, col: 13 },
  { row: 6, col: 14 },
  { row: 7, col: 14 },
  { row: 8, col: 14 },
  { row: 8, col: 13 },
  { row: 8, col: 12 },
  { row: 8, col: 11 },
  { row: 8, col: 10 },
  { row: 8, col: 9 },
  { row: 9, col: 8 },
  { row: 10, col: 8 },
  { row: 11, col: 8 },
  { row: 12, col: 8 },
  { row: 13, col: 8 },
  { row: 14, col: 8 },
  { row: 14, col: 7 },
  { row: 13, col: 7 },
  { row: 12, col: 7 },
  { row: 11, col: 7 },
  { row: 10, col: 7 },
  { row: 9, col: 7 },
  { row: 8, col: 7 },
];

const yellowPath = [
  { row: 8, col: 13 },
  { row: 8, col: 12 },
  { row: 8, col: 11 },
  { row: 8, col: 10 },
  { row: 8, col: 9 },
  { row: 9, col: 8 },
  { row: 10, col: 8 },
  { row: 11, col: 8 },
  { row: 12, col: 8 },
  { row: 13, col: 8 },
  { row: 14, col: 8 },
  { row: 14, col: 7 },
  { row: 14, col: 6 },
  { row: 13, col: 6 },
  { row: 12, col: 6 },
  { row: 11, col: 6 },
  { row: 10, col: 6 },
  { row: 9, col: 6 },
  { row: 8, col: 5 },
  { row: 8, col: 4 },
  { row: 8, col: 3 },
  { row: 8, col: 2 },
  { row: 8, col: 1 },
  { row: 8, col: 0 },
  { row: 7, col: 0 },
  { row: 6, col: 0 },
  { row: 6, col: 1 },
  { row: 6, col: 2 },
  { row: 6, col: 3 },
  { row: 6, col: 4 },
  { row: 6, col: 5 },
  { row: 5, col: 6 },
  { row: 4, col: 6 },
  { row: 3, col: 6 },
  { row: 2, col: 6 },
  { row: 1, col: 6 },
  { row: 0, col: 6 },
  { row: 0, col: 7 },
  { row: 0, col: 8 },
  { row: 1, col: 8 },
  { row: 2, col: 8 },
  { row: 3, col: 8 },
  { row: 4, col: 8 },
  { row: 5, col: 8 },
  { row: 6, col: 9 },
  { row: 6, col: 10 },
  { row: 6, col: 11 },
  { row: 6, col: 12 },
  { row: 6, col: 13 },
  { row: 6, col: 14 },
  { row: 7, col: 14 },
  { row: 7, col: 13 },
  { row: 7, col: 12 },
  { row: 7, col: 11 },
  { row: 7, col: 10 },
  { row: 7, col: 9 },
  { row: 7, col: 8 },
];

const path = (player) => {
  if (player.color == "red") return redPath;
  else if (player.color == "blue") return bluePath;
  else if (player.color == "green") return greenPath;
  else return yellowPath;
};

const checkSafePosition = (row, col) => {
  const safeCells = [
    [6, 1],
    [2, 6],
    [1, 8],
    [6, 12],
    [8, 13],
    [12, 8],
    [13, 6],
    [8, 2],
  ];
  const cellIndex = safeCells.find((cell) => {
    return cell[0] === row && cell[1] === col;
  });

  if (cellIndex) return true;
  else return false;
};

console.log(`is Safe position : ${checkSafePosition(13, 6)}`);
// Check for token captures
/**
 * Checks if a player's token captures an opponent's token
 *
 * @param {Object} room - The game room
 * @param {Object} currentPlayer - The player whose token is being checked
 * @param {number} steps - The number of steps the token has taken
 * @returns {boolean} - Whether a capture occurred
 */
const checkForCaptures = (room, currentPlayer, steps) => {
  // Get the position of the current player's token
  const currentPlayerPosition = path(currentPlayer);

  // Check if the token's steps are valid
  if (!currentPlayerPosition[steps]) {
    console.log(
      `Invalid steps value: ${steps} for player color: ${currentPlayer.color}`
    );
    return false;
  }

  const cRow = currentPlayerPosition[steps].row;
  const cCol = currentPlayerPosition[steps].col;

  // No capture can happen on safe positions
  if (checkSafePosition(cRow, cCol)) {
    return false;
  }

  let isCaptured = false;

  // Check each opponent's tokens for possible captures
  room.players.forEach((player) => {
    // Skip the current player
    if (player.id === currentPlayer.id) return;

    const playerPath = path(player);

    player.tokens.forEach((token, tokenIndex) => {
      // Only consider tokens on the board
      if (token.position !== "board") return;

      // Ensure the path index is valid
      if (!playerPath[token.steps]) {
        console.log(
          `Invalid token steps: ${token.steps} for player: ${player.color}, token: ${tokenIndex}`
        );
        return;
      }

      const pRow = playerPath[token.steps].row;
      const pCol = playerPath[token.steps].col;

      // If the positions match, a capture has occurred
      if (cCol === pCol && cRow === pRow) {
        console.log(
          `Capturing token: Player ${player.color} token ${tokenIndex} at position ${pRow}:${pCol}`
        );

        // Send token back home
        token.position = "home";
        token.steps = 0;

        isCaptured = true;

        // Emit token moved event for captured token
        io.to(room.code).emit(
          "token-moved",
          createSafeObject({
            playerId: player.id,
            tokenId: token.id,
            newPosition: "home",
            steps: 0,
            reason: "captured",
          })
        );
      }
    });
  });

  return isCaptured;
};

io.on("connection", (socket) => {
  console.log("New client connected", socket.id);

  // Create room
  socket.on("create-room", (playerName, callback) => {
    let roomCode = randomRoomCode();
    while (rooms.has(roomCode)) {
      roomCode = randomRoomCode();
    }

    const player = {
      id: socket.id,
      name: playerName,
      color: defaultPlayerColors[0], // Always red for host
      isHost: true,
      isReady: false,
      tokens: [
        { id: 0, position: "home", steps: 0 },
        { id: 1, position: "home", steps: 0 },
        { id: 2, position: "home", steps: 0 },
        { id: 3, position: "home", steps: 0 },
      ],
    };

    const room = {
      code: roomCode,
      players: [player],
      gameState: "waiting",
      currentTurn: 0,
      currentPlayerHasRolled: false,
      messages: [],
      dice: 0,
      maxPlayers: 4, // Default to 4 players max
    };

    rooms.set(roomCode, room);
    socket.join(roomCode);
    callback(roomCode);

    console.log(`Room created: ${roomCode}`);
  });

  // Join room
  socket.on("join-room", (roomCode, playerName, callback) => {
    const room = rooms.get(roomCode);

    if (!room) {
      return callback(false, "Room not found");
    }

    if (room.players.length >= room.maxPlayers) {
      return callback(false, "Room is full");
    }

    if (room.gameState !== "waiting") {
      return callback(false, "Game already started");
    }

    const colorIndex = room.players.length;
    const availableColors = getPlayerColors(room);
    const player = {
      id: socket.id,
      name: playerName,
      color: availableColors[colorIndex],
      isHost: false,
      isReady: false,
      tokens: [
        { id: 0, position: "home", steps: 0 },
        { id: 1, position: "home", steps: 0 },
        { id: 2, position: "home", steps: 0 },
        { id: 3, position: "home", steps: 0 },
      ],
    };

    room.players.push(player);
    socket.join(roomCode);

    const roomData = {
      code: room.code,
      players: room.players.map((p) => createSafePlayer(p)),
      gameState: room.gameState,
      currentTurn: room.currentTurn,
      messages: room.messages,
      dice: room.dice,
    };

    callback(true, "Successfully joined room", roomData);

    // Notify other players
    socket.to(roomCode).emit("player-joined", createSafePlayer(player));

    // Send a room-update event to the newly joined player to ensure they have the full state
    socket.emit("room-update", roomData);

    console.log(`Player ${playerName} joined room ${roomCode}`);
  });

  // Roll dice
  socket.on("roll-dice", (roomCode, clientDiceValue) => {
    console.log(
      `Player ${socket.id} is trying to roll dice in room ${roomCode}` +
        (clientDiceValue ? ` with client value: ${clientDiceValue}` : "")
    );
    const room = rooms.get(roomCode);
    if (!room || room.gameState !== "playing") {
      console.log(
        `Room ${roomCode} not found or game not in playing state. Room:`,
        room ? `Found, state: ${room.gameState}` : "Not found"
      );
      return;
    }

    const playerIndex = room.players.findIndex((p) => p.id === socket.id);
    if (playerIndex !== room.currentTurn) {
      console.log(
        `Player ${socket.id} tried to roll but it's not their turn. Current turn: ${room.currentTurn}, Player index: ${playerIndex}`
      );
      return;
    }

    // Send acknowledgment back to the client that triggered the event
    socket.emit("roll-dice-received", { received: true });

    // Use client dice value if provided (and valid), otherwise generate a random value
    // Always use the client dice value, validate it's between 1-6
    if (
      clientDiceValue === undefined ||
      clientDiceValue < 1 ||
      clientDiceValue > 6
    ) {
      console.error(
        `Invalid dice value received: ${clientDiceValue}, rejecting roll`
      );
      return;
    }

    // Use the client-provided dice value exclusively
    const diceValue = clientDiceValue;
    console.log(`Using client provided dice value: ${diceValue}`);

    room.dice = diceValue;
    console.log(`Player ${socket.id} rolled a ${diceValue}`);

    // Store this in the room state to track if the player has already rolled in this turn
    room.currentPlayerHasRolled = true;

    // Log socket room information before broadcasting
    const socketsInRoom = io.sockets.adapter.rooms.get(roomCode);
    console.log(
      `Sockets in room ${roomCode}:`,
      socketsInRoom ? Array.from(socketsInRoom) : "None"
    );

    // Make sure the current socket is in the room
    if (!socket.rooms.has(roomCode)) {
      console.log(
        `Socket ${socket.id} is not in room ${roomCode}, joining now`
      );
      socket.join(roomCode);
    }

    // Broadcast dice roll to ALL clients in the room INCLUDING the sender
    console.log(`Broadcasting dice-rolled event to room ${roomCode}:`, {
      playerId: socket.id,
      diceValue,
    });

    // Using io.to() to ensure ALL clients in the room receive the event, including the sender
    io.to(roomCode).emit("dice-rolled", {
      playerId: socket.id,
      diceValue,
    });

    // Check if player has any valid moves
    const currentPlayer = room.players[playerIndex];

    // Use the hasValidMoves helper from ludo-rules
    const canMoveAnyToken = hasValidMoves(currentPlayer, diceValue);

    if (!canMoveAnyToken) {
      console.log(
        `Player ${socket.id} has no valid moves, automatically moving to next turn`
      );

      // Wait a bit to let clients see the dice result before advancing turn
      setTimeout(() => {
        room.currentTurn = (room.currentTurn + 1) % room.players.length;
        room.currentPlayerHasRolled = false;
        room.dice = 0;

        io.to(roomCode).emit("next-turn", {
          currentTurn: room.currentTurn,
          reason: "no-valid-moves",
        });
      }, 2000);
    }
  });

  // Move token
  socket.on("move-token", (roomCode, tokenId) => {
    const room = rooms.get(roomCode);
    if (!room || room.gameState !== "playing") return;

    const playerIndex = room.players.findIndex((p) => p.id === socket.id);
    if (playerIndex !== room.currentTurn) return;

    // Check if player has rolled the dice in their turn
    if (!room.currentPlayerHasRolled) {
      console.log(`Player ${socket.id} tried to move without rolling first`);
      return;
    }

    const player = room.players[playerIndex];
    const token = player.tokens[tokenId];

    if (!token) return;

    // Store the dice value before it gets reset
    const diceValue = room.dice;

    // Log the attempted move for debugging
    console.log(`Player ${socket.id} is attempting to move token ${tokenId}:`, {
      currentPosition: token.position,
      currentSteps: token.steps,
      diceValue: diceValue,
    });

    // Use the canMoveToken helper to validate the move
    if (!canMoveToken(token, diceValue, player)) {
      console.log(
        `Invalid move for token ${tokenId} with dice value ${diceValue}`
      );

      // Notify the client that this is an invalid move
      if (token.position === "home" && diceValue !== 6) {
        socket.emit("invalid-move", {
          message: "You need a 6 to move a token out of home.",
        });
      } else if (token.position === "finished") {
        socket.emit("invalid-move", {
          message: "This token has already reached the finish line.",
        });
      } else if (token.position === "board" && token.steps + diceValue > 56) {
        socket.emit("invalid-move", {
          message: "You need an exact roll to reach the finish line.",
        });
      }
      return;
    }

    // Use the moveToken helper to move the token according to Ludo rules
    const moveResult = moveToken(token, diceValue, player);

    if (!moveResult.validMove) {
      console.log(`Move was invalid according to Ludo rules`);
      return;
    }

    // Update the token with the result from moveToken
    const oldPosition = token.position;
    const oldSteps = token.steps;
    token.position = moveResult.token.position;
    token.steps = moveResult.token.steps;

    const reachedFinish =
      oldPosition !== "finished" && token.position === "finished";

    console.log(
      `Moving token ${tokenId} from ${oldPosition}:${oldSteps} to ${token.position}:${token.steps}`
    );

    // Emit the move
    io.to(roomCode).emit(
      "token-moved",
      createSafeObject({
        playerId: socket.id,
        tokenId,
        newPosition: token.position,
        steps: token.steps,
        reason: reachedFinish ? "reached-finish" : "normal-move",
      })
    );

    // Reset the dice and rolled state
    room.currentPlayerHasRolled = false;

    // Check for captures
    const isCaptured = checkForCaptures(room, player, token.steps);

    // Check if player has won
    if (hasPlayerWon(player)) {
      room.gameState = "finished";
      io.to(roomCode).emit("game-over", {
        winnerId: player.id,
        winner: createSafePlayer(player),
      });
      return;
    }

    // Determine if player gets an extra turn using getsExtraTurn helper
    const getsExtra = getsExtraTurn(diceValue, reachedFinish, isCaptured);

    if (getsExtra) {
      // Only give extra turn if player still has tokens to move
      const hasMovableTokens = player.tokens.some(
        (t) => t.position === "home" || t.position === "board"
      );

      if (hasMovableTokens) {
        // Reset dice to 0 but keep the current turn
        room.dice = 0;

        // Send appropriate reason for extra turn
        let reason = "normal";
        if (diceValue === 6) reason = "rolled-six";
        else if (reachedFinish) reason = "token-finished";
        else if (isCaptured) reason = "captured-token";

        io.to(roomCode).emit("extra-turn", {
          currentTurn: room.currentTurn,
          playerId: socket.id,
          playerName: player.name,
          reason: reason,
        });
        return;
      }
    }

    // Move to next player's turn
    room.currentTurn = (room.currentTurn + 1) % room.players.length;
    room.dice = 0;

    io.to(roomCode).emit("next-turn", {
      currentTurn: room.currentTurn,
      reason: "normal-turn-end",
    });
  });

  // Send message
  socket.on("send-message", (roomCode, emoji) => {
    const room = rooms.get(roomCode);
    if (!room) return;

    const player = room.players.find((p) => p.id === socket.id);
    if (!player) return;

    const message = {
      id: Date.now().toString(),
      playerId: socket.id,
      playerName: player.name,
      playerColor: player.color,
      content: emoji,
      timestamp: new Date().toISOString(),
    };

    room.messages.push(message);
    io.to(roomCode).emit("new-message", message);
  });

  // Toggle player ready state
  socket.on("toggle-ready", (roomCode) => {
    const room = rooms.get(roomCode);
    if (!room || room.gameState !== "waiting") {
      console.log(
        `Room ${roomCode} not found or game not in waiting state. Room:`,
        room ? `Found, state: ${room.gameState}` : "Not found"
      );
      return;
    }

    const playerIndex = room.players.findIndex((p) => p.id === socket.id);
    if (playerIndex === -1) return;

    const player = room.players[playerIndex];
    player.isReady = !player.isReady;

    // // const room = {
    //   code: roomCode,
    //   players: [player],
    //   gameState: "waiting",
    //   currentTurn: 0,
    //   currentPlayerHasRolled: false,
    //   messages: [],
    //   dice: 0,
    // };

    // Don't change game state here - keep it in waiting state

    // room.gameState = "playing";
    // game state should only change when the host explicitly starts the game
    room.players[playerIndex] = player;
    rooms.set(roomCode, room);
    console.log(
      `Room with room code: ${roomCode} updated with new player data:`,
      room
    );

    // Notify all players about the change
    io.to(roomCode).emit(
      "player-ready-changed",
      createSafeObject({
        playerId: socket.id,
        isReady: player.isReady,
      })
    );

    // Update room data for all players
    const roomData = rooms.get(roomCode);

    // Create a safe version of the room data
    const safeRoomData = {
      code: roomData.code,
      players: roomData.players.map((p) => createSafePlayer(p)),
      gameState: roomData.gameState,
      currentTurn: roomData.currentTurn,
      messages: roomData.messages,
      dice: roomData.dice,
      maxPlayers: roomData.maxPlayers,
    };

    io.to(roomCode).emit("room-update", safeRoomData);

    // Check if all players are ready and notify clients
    const allPlayersReady = room.players.every((p) => p.isReady);
    if (allPlayersReady && room.players.length >= 2) {
      io.to(roomCode).emit("all-players-ready", true);
    } else {
      io.to(roomCode).emit("all-players-ready", false);
    }
  });

  // Start the game (host only)
  socket.on("start-game", (roomCode) => {
    const room = rooms.get(roomCode);
    if (!room || room.gameState !== "waiting") return;

    const player = room.players.find((p) => p.id === socket.id);
    if (!player || !player.isHost) return;

    // Check if we have at least 2 players and all players are ready
    if (room.players.length >= 2 && room.players.every((p) => p.isReady)) {
      room.gameState = "playing";
      room.currentTurn = 0;

      const roomData = {
        code: room.code,
        players: room.players.map((p) => createSafePlayer(p)),
        gameState: room.gameState,
        currentTurn: room.currentTurn,
        messages: room.messages,
        dice: room.dice,
      };

      io.to(roomCode).emit("game-started", roomData);
    }
  });

  // Set player count (host only)
  socket.on("set-player-count", (roomCode, playerCount) => {
    const room = rooms.get(roomCode);
    if (!room || room.gameState !== "waiting") return;

    const player = room.players.find((p) => p.id === socket.id);
    if (!player || !player.isHost) return;

    // Only accept 2 or 4 players
    if (playerCount !== 2 && playerCount !== 4) return;

    // Set the max players for the room
    room.maxPlayers = playerCount;

    // If switching to 2 players, we need to update the player colors
    // to ensure they're using red and yellow
    if (playerCount === 2) {
      const availableColors = getPlayerColors(room);

      // Update existing players' colors if needed
      room.players.forEach((p, index) => {
        // Keep color assignments in sync with the two-player colors array
        if (index < availableColors.length) {
          p.color = availableColors[index];
        }
      });
    }

    // Notify all players about the change
    io.to(roomCode).emit("player-count-updated", {
      maxPlayers: room.maxPlayers,
      players: room.players.map((p) => createSafePlayer(p)),
    });
  });

  // Disconnect
  socket.on("disconnect", () => {
    console.log("Client disconnected", socket.id);

    // Find all rooms the player is in
    for (const [roomCode, room] of rooms.entries()) {
      const playerIndex = room.players.findIndex((p) => p.id === socket.id);

      if (playerIndex !== -1) {
        const player = room.players[playerIndex];

        // Don't mark as disconnected immediately, but set a flag indicating pending disconnect
        player.disconnectPending = true;

        // Record the time of disconnection
        player.disconnectTime = Date.now();

        // Store the player's original socket ID if not already saved
        if (!player.originalId) {
          player.originalId = socket.id;
          console.log(
            `Saving original socket ID ${socket.id} for player ${player.name}`
          );
        }

        // If the game is in playing state, pause it
        if (room.gameState === "playing") {
          const previousState = room.gameState;
          room.gameState = "paused";
          room.previousState = previousState; // Store previous state to restore later
          console.log(
            `Game in room ${roomCode} has been paused due to player disconnection`
          );
        }

        // Notify other players that this player has temporarily disconnected
        io.to(roomCode).emit(
          "player-temporary-disconnect",
          createSafeObject({
            playerId: player.id,
            playerName: player.name,
            gameState: room.gameState,
          })
        );

        console.log(
          `Player ${player.name} temporarily disconnected from room ${roomCode}`
        );
        console.log(
          `Player has 2 minutes to reconnect before being marked as disconnected`
        );

        // Store the timeout ID so we can clear it if they reconnect
        player.disconnectTimeoutId = setTimeout(() => {
          console.log(`Disconnect timeout triggered for player ${player.name}`);

          // Make sure the room and player still exist before marking as disconnected
          const currentRoom = rooms.get(roomCode);
          if (!currentRoom) {
            console.log(
              `Room ${roomCode} no longer exists, aborting disconnect timeout`
            );
            return;
          }

          // Find the player again based on original ID since socket.id may have changed
          const currentPlayer = currentRoom.players.find(
            (p) =>
              (p.originalId && p.originalId === player.originalId) ||
              p.id === socket.id
          );

          if (!currentPlayer) {
            console.log(
              `Player with ID ${socket.id} or original ID ${
                player.originalId || "unknown"
              } no longer exists in room`
            );
            return;
          }

          if (!currentPlayer.disconnectPending) {
            console.log(
              `Player ${currentPlayer.name} already reconnected, aborting disconnect timeout`
            );
            return;
          }

          console.log(
            `Player ${currentPlayer.name} did not reconnect within 2 minutes. Marking as disconnected.`
          );

          // Mark the player as fully disconnected
          currentPlayer.isDisconnected = true;
          delete currentPlayer.disconnectPending;
          delete currentPlayer.disconnectTime;
          delete currentPlayer.disconnectTimeoutId;

          // Resume the game if it was paused
          if (currentRoom.gameState === "paused" && currentRoom.previousState) {
            currentRoom.gameState = currentRoom.previousState;
            delete currentRoom.previousState;
            console.log(
              `Game in room ${roomCode} has been resumed after permanent disconnection`
            );
          }

          // Notify other players that this player has been fully disconnected
          io.to(roomCode).emit("player-disconnected", {
            playerId: currentPlayer.id,
            playerName: currentPlayer.name,
            isDisconnected: true,
            gameState: currentRoom.gameState, // Include the current game state
          });

          // Reset all their tokens to home position
          if (currentRoom.gameState === "playing") {
            currentPlayer.tokens.forEach((token) => {
              const oldPosition = token.position;
              const oldSteps = token.steps;

              // Return token to home
              token.position = "home";
              token.steps = 0;

              // Notify all players about each token being moved to home
              if (oldPosition !== "home" || oldSteps !== 0) {
                io.to(roomCode).emit(
                  "token-moved",
                  createSafeObject({
                    playerId: currentPlayer.id,
                    tokenId: token.id,
                    newPosition: "home",
                    steps: 0,
                    reason: "player-disconnected",
                  })
                );
              }
            });
          }

          // Auto-advance the turn if it's the disconnected player's turn
          if (
            currentRoom.gameState === "playing" &&
            currentRoom.currentTurn === playerIndex
          ) {
            console.log(
              `It was ${currentPlayer.name}'s turn, automatically skipping their turn`
            );
            currentRoom.currentTurn =
              (currentRoom.currentTurn + 1) % currentRoom.players.length;
            io.to(roomCode).emit("turn-changed", {
              currentTurn: currentRoom.currentTurn,
              reason: "disconnected-player-skipped",
            });
          }

          // If no active players left, delete the room
          const activePlayers = currentRoom.players.filter(
            (p) => !p.isDisconnected
          );
          const activePlayersCount = activePlayers.length;

          if (activePlayersCount === 0) {
            rooms.delete(roomCode);
            console.log(
              `Room ${roomCode} deleted as all players left or disconnected`
            );
            return;
          }

          // If only one active player remains and game is in playing state, declare them the winner
          if (activePlayersCount === 1 && currentRoom.gameState === "playing") {
            const lastPlayer = activePlayers[0];
            console.log(
              `Only one player (${lastPlayer.name}) remains in room ${roomCode}. Declaring them the winner.`
            );

            // Emit game-over event
            io.to(roomCode).emit("game-over", {
              winnerId: lastPlayer.id,
              winner: createSafePlayer(lastPlayer),
              reason: "last-player-remaining",
            });

            // Update game state
            currentRoom.gameState = "finished";
          }
        }, 120000); // 2 minutes in milliseconds

        console.log(
          `Disconnect timeout set for player ${player.name} in room ${roomCode}`
        );

        // Make someone else the host if the host left
        if (player.isHost && room.players.length > 0) {
          // Find the first active player to make host
          const newHost = room.players.find((p) => !p.isDisconnected);
          if (newHost) {
            player.isHost = false; // Remove host status from disconnected player
            newHost.isHost = true;
            console.log(
              `New host assigned in room ${roomCode}: ${newHost.name}`
            );
          }
        }

        // Adjust the current turn if necessary
        if (room.gameState === "playing") {
          // Count active players before this disconnected player
          const activePreviousPlayers = room.players
            .slice(0, playerIndex)
            .filter((p) => !p.isDisconnected).length;

          // If it was the disconnected player's turn, move to the next active player
          if (playerIndex === room.currentTurn) {
            // Find the next active player
            let nextPlayerIndex = room.currentTurn;
            let loopCount = 0;

            // Prevent infinite loop by counting iterations
            while (loopCount < room.players.length) {
              nextPlayerIndex = (nextPlayerIndex + 1) % room.players.length;
              if (!room.players[nextPlayerIndex].isDisconnected) {
                break; // Found the next active player
              }
              loopCount++;
            }

            room.currentTurn = nextPlayerIndex;
            room.currentPlayerHasRolled = false;
            room.dice = 0;
            console.log(
              `Player disconnected during their turn. Moving to next player at index ${nextPlayerIndex}.`
            );

            // Notify remaining players about the turn change

            io.to(roomCode).emit("next-turn", {
              currentTurn: room.currentTurn,
              reason: "disconnected-player",
            });
          }
          // If the current turn is after the disconnected player, we don't need to adjust
          // because we're keeping the disconnected player in the array
        }

        // Notify other players about the disconnection
        io.to(roomCode).emit(
          "player-disconnected",
          createSafeObject({
            playerId: socket.id,
            playerName: player.name,
            isDisconnected: true,
          })
        );

        console.log(`Player ${player.name} disconnected from room ${roomCode}`);

        // Update room data for all players
        const roomData = {
          code: room.code,
          players: room.players.map((p) => createSafePlayer(p)),
          gameState: room.gameState,
          currentTurn: room.currentTurn,
          messages: room.messages,
          dice: room.dice,
          maxPlayers: room.maxPlayers,
        };

        io.to(roomCode).emit("room-update", roomData);
      }
    }
  });

  // Rejoin room (used to reconnect to a room)
  socket.on("rejoin-room", (data, callback) => {
    // Support both old format (just roomCode) and new format (object with roomCode and playerData)
    const roomCode = typeof data === "string" ? data : data.roomCode;
    const playerData = typeof data === "object" ? data.playerData : null;

    console.log(
      `Player ${socket.id} is attempting to rejoin room ${roomCode}${
        playerData ? ` with data: ${JSON.stringify(playerData)}` : ""
      }`
    );
    const room = rooms.get(roomCode);

    if (!room) {
      console.log(`Room ${roomCode} not found for rejoin`);
      if (callback) callback(false);
      return;
    }

    // Try to find the player in the room that might be disconnected
    // Look by original player ID, name, and also check for players pending disconnect
    const existingPlayer = room.players.find((p) => {
      // Check if the player with the same name or original ID is trying to reconnect
      const matchesById = p.id === socket.id;
      const matchesByName =
        playerData && playerData.name && p.name === playerData.name;
      const isPendingDisconnect =
        p.disconnectPending === true && !p.isDisconnected;
      const matchesByOriginalId =
        playerData &&
        playerData.originalId &&
        p.originalId === playerData.originalId;

      // Log each condition for debugging
      if (
        matchesById ||
        matchesByName ||
        isPendingDisconnect ||
        matchesByOriginalId
      ) {
        console.log(`Player match found:
          - By ID: ${matchesById} (${p.id} === ${socket.id})
          - By Name: ${matchesByName} (${p.name} === ${playerData?.name})
          - Pending Disconnect: ${isPendingDisconnect}
          - By Original ID: ${matchesByOriginalId} (${p.originalId} === ${playerData?.originalId})
        `);
      }

      // Return true if any condition matches
      return (
        matchesById ||
        matchesByName ||
        isPendingDisconnect ||
        matchesByOriginalId
      );
    });

    // If player exists in the room
    if (existingPlayer) {
      console.log(`Found existing player ${existingPlayer.name} in room`);

      // Store the original ID to handle future reconnections
      if (!existingPlayer.originalId) {
        existingPlayer.originalId = existingPlayer.id;
        console.log(
          `First-time storage of original ID: ${existingPlayer.originalId} for player ${existingPlayer.name}`
        );
      } else {
        console.log(
          `Using existing original ID: ${existingPlayer.originalId} for player ${existingPlayer.name}`
        );
      }

      // Log player ID before update
      console.log(
        `Updating player ID from ${existingPlayer.id} to ${socket.id}`
      );

      // Update the player's socket ID to the new socket ID
      existingPlayer.id = socket.id;

      // Clear any disconnect timeout
      if (existingPlayer.disconnectTimeoutId) {
        console.log(
          `Clearing disconnect timeout for player ${existingPlayer.name}`
        );
        clearTimeout(existingPlayer.disconnectTimeoutId);
        delete existingPlayer.disconnectTimeoutId;
      }

      // Reset the disconnect pending flag
      if (existingPlayer.disconnectPending) {
        console.log(
          `Player ${existingPlayer.name} has reconnected within the time limit`
        );
        delete existingPlayer.disconnectPending;
        delete existingPlayer.disconnectTime;
      }

      // Make sure the player is not marked as disconnected
      existingPlayer.isDisconnected = false;

      // Update player data if provided (like color, name) for better reconnection
      if (playerData) {
        if (playerData.color && !existingPlayer.color) {
          console.log(
            `Updating reconnected player's color to ${playerData.color}`
          );
          existingPlayer.color = playerData.color;
        }

        if (playerData.name && existingPlayer.name !== playerData.name) {
          console.log(
            `Updating reconnected player's name from ${existingPlayer.name} to ${playerData.name}`
          );
          existingPlayer.name = playerData.name;
        }
      }

      // Rejoin the socket room
      socket.join(roomCode);
      console.log(`Player ${socket.id} rejoined room ${roomCode}`);

      // Resume the game if it was paused due to this player's disconnection
      if (room.gameState === "paused" && room.previousState) {
        room.gameState = room.previousState;
        delete room.previousState;
        console.log(`Game in room ${roomCode} has been resumed`);
      }

      // Notify all players that this player has reconnected
      io.to(roomCode).emit("player-reconnected", {
        playerId: socket.id,
        playerName: existingPlayer.name,
        gameState: room.gameState,
      });

      console.log(
        `Notified other players that ${existingPlayer.name} has reconnected`
      );

      // Send the current game state to the rejoined player
      const roomData = {
        code: room.code,
        players: room.players.map((p) => createSafePlayer(p)),
        gameState: room.gameState,
        currentTurn: room.currentTurn,
        messages: room.messages,
        dice: room.dice,
        maxPlayers: room.maxPlayers,
      };

      socket.emit("room-update", roomData);

      // Notify other players about the reconnection
      socket.to(roomCode).emit(
        "player-reconnected",
        createSafeObject({
          playerId: existingPlayer.id,
          playerName: existingPlayer.name,
          gameState: room.gameState,
        })
      );

      console.log("Sending room data back to rejoined player");
      if (callback) callback(true, roomData);
    } else {
      console.log(
        `No existing player found in room ${roomCode} for rejoin attempt from socket ${socket.id}`
      );

      // Log all players in the room for debugging
      console.log(
        "Current players in room:",
        room.players.map(
          (p) =>
            `${p.name} (ID: ${p.id}, Original ID: ${
              p.originalId || "none"
            }, Disconnected: ${p.isDisconnected || false}, Pending: ${
              p.disconnectPending || false
            })`
        )
      );

      if (callback) callback(false);
    }
  });

  // Handle player leaving the game manually
  socket.on("player-leave", (roomCode) => {
    console.log(`Player ${socket.id} is leaving room ${roomCode}`);

    const room = rooms.get(roomCode);
    if (!room) {
      console.error(`Room ${roomCode} not found for player-leave event`);
      return;
    }

    // Find the player in the room
    const playerIndex = room.players.findIndex((p) => p.id === socket.id);
    if (playerIndex === -1) {
      console.error(`Player ${socket.id} not found in room ${roomCode}`);
      return;
    }

    const player = room.players[playerIndex];

    // Mark the player as disconnected
    player.isDisconnected = true;

    // If we're in playing state, handle the game logic
    if (room.gameState === "playing") {
      // Reset their tokens to home
      player.tokens.forEach((token) => {
        const oldPosition = token.position;
        const oldSteps = token.steps;

        // Return token to home
        token.position = "home";
        token.steps = 0;

        // Notify all players about each token being moved to home
        if (oldPosition !== "home" || oldSteps !== 0) {
          io.to(roomCode).emit(
            "token-moved",
            createSafeObject({
              playerId: player.id,
              tokenId: token.id,
              newPosition: "home",
              steps: 0,
              reason: "player-left",
            })
          );
        }
      });

      // Check if only one active player remains
      const activePlayers = room.players.filter((p) => !p.isDisconnected);
      const activePlayersCount = activePlayers.length;

      if (activePlayersCount === 1) {
        const lastPlayer = activePlayers[0];
        console.log(
          `Only one player (${lastPlayer.name}) remains in room ${roomCode}. Declaring them the winner.`
        );

        // Emit game-over event
        io.to(roomCode).emit("game-over", {
          winnerId: lastPlayer.id,
          winner: lastPlayer,
          reason: "last-player-remaining",
        });

        // Update game state
        room.gameState = "finished";
      }

      // If it was the leaving player's turn, move to the next active player
      if (playerIndex === room.currentTurn) {
        // Find the next active player
        let nextPlayerIndex = room.currentTurn;
        let loopCount = 0;

        // Prevent infinite loop by counting iterations
        while (loopCount < room.players.length) {
          nextPlayerIndex = (nextPlayerIndex + 1) % room.players.length;
          if (!room.players[nextPlayerIndex].isDisconnected) {
            break; // Found the next active player
          }
          loopCount++;
        }

        room.currentTurn = nextPlayerIndex;
        room.currentPlayerHasRolled = false;
        room.dice = 0;
        console.log(
          `Player left during their turn. Moving to next player at index ${nextPlayerIndex}.`
        );

        // Notify remaining players about the turn change
        io.to(roomCode).emit("next-turn", {
          currentTurn: room.currentTurn,
          reason: "player-left",
        });
      }
    }

    // Make someone else the host if the host left
    if (player.isHost && room.players.length > 0) {
      // Find the first active player to make host
      const newHost = room.players.find((p) => !p.isDisconnected);
      if (newHost) {
        player.isHost = false; // Remove host status from leaving player
        newHost.isHost = true;
        console.log(`New host assigned in room ${roomCode}: ${newHost.name}`);
      }
    }

    // Notify other players about the player leaving
    io.to(roomCode).emit(
      "player-disconnected",
      createSafeObject({
        playerId: socket.id,
        playerName: player.name,
        isDisconnected: true,
        gameState: room.gameState, // Include the current game state
      })
    );

    console.log(`Player ${player.name} left room ${roomCode}`);

    // Update room data for all players
    const roomData = {
      code: room.code,
      players: room.players.map((p) => createSafePlayer(p)),
      gameState: room.gameState,
      currentTurn: room.currentTurn,
      messages: room.messages,
      dice: room.dice,
      maxPlayers: room.maxPlayers,
    };

    io.to(roomCode).emit("room-update", roomData);
  });

  // Reset game after it has finished or when a player leaves
  socket.on("reset-game", (roomCode) => {
    console.log(
      `Player ${socket.id} requested to reset game in room ${roomCode}`
    );

    const room = rooms.get(roomCode);
    if (!room) {
      console.error(`Room ${roomCode} not found for reset-game event`);
      return;
    }

    // Allow reset in any game state when a player is leaving
    // This is a more flexible approach that handles players leaving mid-game

    // Reset the game state
    room.gameState = "waiting";
    room.currentTurn = 0;
    room.dice = 0;

    // Reset all tokens to home position
    room.players.forEach((player) => {
      if (player.tokens) {
        player.tokens = player.tokens.map((token, index) => ({
          id: index,
          position: "home",
          steps: 0,
        }));
      }

      // Reset player ready status
      player.isReady = false;
    });

    // Broadcast the reset game event to all players in the room
    io.to(roomCode).emit("game-reset", {
      code: roomCode,
      players: room.players.map((p) => createSafePlayer(p)),
      gameState: room.gameState,
      currentTurn: room.currentTurn,
      dice: room.dice,
      maxPlayers: room.maxPlayers,
    });

    console.log(`Game reset in room ${roomCode}`);
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Socket.IO server running on port ${PORT}`);
});
