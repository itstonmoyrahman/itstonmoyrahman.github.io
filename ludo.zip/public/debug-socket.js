// Temporary diagnostic client code - remove this file after debugging is complete
// This file helps us debug the socket events by logging them directly in the browser console

// Self-executing function to avoid polluting global namespace
(function () {
  // Wait for the socket to be available in window
  const checkInterval = setInterval(() => {
    // Try to find the socket instance
    if (window.io) {
      console.log("Socket.IO detected, attaching debug listeners");

      // Create a direct connection to the server for debugging
      const debugSocket = window.io("http://localhost:3001", {
        transports: ["websocket", "polling"],
      });

      debugSocket.on("connect", () => {
        console.log("Debug socket connected with ID:", debugSocket.id);

        // Listen for player-joined events
        debugSocket.on("player-joined", (player) => {
          console.log("DEBUG: player-joined event received:", player);
        });

        // Listen for player-ready-changed events
        debugSocket.on("player-ready-changed", (data) => {
          console.log("DEBUG: player-ready-changed event received:", data);
        });

        // Listen for room-update events
        debugSocket.on("room-update", (roomData) => {
          console.log("DEBUG: room-update event received:", roomData);
        });
      });

      clearInterval(checkInterval);
    }
  }, 1000);
})();
