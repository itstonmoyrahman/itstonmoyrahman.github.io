"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useCreateRoom, useJoinRoom } from "@/lib/socket/hooks";
import { useGameStore } from "@/lib/game/store";
import { Dice1 as Dice, Users, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import Head from "next/head";
import { getGameSession, clearGameSession } from "@/lib/game/sessionStorage";
import { useSocket } from "@/lib/socket/client";

export default function Home() {
  const [playerName, setPlayerName] = useState("");
  const [roomCode, setRoomCode] = useState("");
  const [isCreating, setIsCreating] = useState(false);
  const [isJoining, setIsJoining] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [activeSession, setActiveSession] = useState<any>(null);
  const [isRejoining, setIsRejoining] = useState(false);

  const router = useRouter();
  const { toast } = useToast();
  const { rejoinRoom } = useSocket();

  const { setPlayerName: storeSetPlayerName } = useGameStore();

  const handleCreateSuccess = (roomCode: string) => {
    storeSetPlayerName(playerName);
    router.push(`/room/${roomCode}`);
  };

  const { createRoom, ready: createReady } = useCreateRoom(handleCreateSuccess);

  const handleJoinSuccess = (roomData: any) => {
    storeSetPlayerName(playerName);
    router.push(`/room/${roomData.code}`);
  };

  const handleJoinError = (message: string) => {
    toast({
      title: "Error joining room",
      description: message,
      variant: "destructive",
    });
    setIsJoining(false);
  };

  const { joinRoom, ready: joinReady } = useJoinRoom(
    handleJoinSuccess,
    handleJoinError
  );

  const handleCreateRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerName.trim()) {
      toast({
        title: "Enter your name",
        description: "Please enter your name to create a room",
        variant: "destructive",
      });
      return;
    }

    setIsCreating(true);
    createRoom(playerName);
  };

  const handleJoinRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerName.trim()) {
      toast({
        title: "Enter your name",
        description: "Please enter your name to join a room",
        variant: "destructive",
      });
      return;
    }

    if (!roomCode.trim() || roomCode.length !== 6) {
      toast({
        title: "Invalid room code",
        description: "Please enter a valid 6-digit room code",
        variant: "destructive",
      });
      return;
    }

    setIsJoining(true);
    joinRoom(roomCode, playerName);
  };

  const handleRejoinGame = async () => {
    if (!activeSession) return;

    setIsRejoining(true);
    try {
      // Include all player identification for reconnection
      const playerData = {
        name: activeSession.playerName,
        color: activeSession.playerColor,
        originalId: activeSession.originalId || activeSession.playerId,
      };

      console.log("Attempting to rejoin with player data:", playerData);
      const success = await rejoinRoom(activeSession.roomCode, playerData);

      if (success) {
        storeSetPlayerName(activeSession.playerName);
        router.push(`/room/${activeSession.roomCode}`);
      } else {
        toast({
          title: "Failed to rejoin",
          description: "Game session is no longer available",
          variant: "destructive",
        });
        setActiveSession(null);
        clearGameSession(); // Clear the invalid session
        setIsRejoining(false);
      }
    } catch (error) {
      console.error("Error rejoining game:", error);
      toast({
        title: "Connection error",
        description: "Failed to reconnect to the game server",
        variant: "destructive",
      });
      setIsRejoining(false);
    }
  };

  // Check for active game session on load
  useEffect(() => {
    if (typeof window !== "undefined") {
      const session = getGameSession();
      if (session) {
        setActiveSession(session);
        // Pre-fill the name field with the session name
        setPlayerName(session.playerName);
      }
    }
    setIsLoaded(true);
  }, []);

  return (
    <>
      <Head>
        <title>Ludo Game</title>
        <meta
          name="description"
          content="Play the classic board game with friends online"
        />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <div className="bg-ludo-tiled-pattern bg-cover bg-center min-h-screen">
        <div className="min-h-screen bg-game-gradient flex flex-col items-center justify-center p-4 text-white">
          <div className="w-full max-w-md">
            <div className="text-center mb-8">
              <div className="flex justify-center mb-4">
                <div
                  className="p-4 rounded-full shadow-lg"
                  style={{ background: "var(--purple-gradient)" }}
                >
                  <Dice className="w-10 h-10 text-white" />
                </div>
              </div>
              <h1 className="text-4xl font-extrabold tracking-tight mb-2 text-shadow">
                Ludo Game
              </h1>
              <p className="text-white/80">
                Play the classic board game with friends online
              </p>
            </div>

            {activeSession && (
              <Card className="border border-white/10 bg-container backdrop-blur-lg shadow-lg mb-4">
                <CardHeader className="pb-2">
                  <CardTitle className="text-shadow text-green-200">
                    Active Game Found
                  </CardTitle>
                  <CardDescription className="text-white/80">
                    You have an active game session
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-2">
                  <div className="space-y-2">
                    <div className="rounded-md bg-white/10 p-3 border border-white/10">
                      <p className="text-sm text-white/70 mb-1">Room Code</p>
                      <p className="text-xl font-mono font-bold text-white/70">
                        {activeSession.roomCode}
                      </p>
                    </div>
                    <div className="rounded-md bg-white/10 p-3 border border-white/10">
                      <p className="text-sm text-white/70 mb-1">Player Name</p>
                      <p className="text-xl font-bold text-white/70">
                        {activeSession.playerName}
                      </p>
                    </div>
                    {activeSession.playerColor && (
                      <div className="rounded-md bg-white/10 p-3 border border-white/10">
                        <p className="text-sm text-white/70 mb-1">
                          Player Color
                        </p>
                        <div className="flex items-center">
                          <div
                            className="w-5 h-5 rounded-full mr-2"
                            style={{
                              backgroundColor: activeSession.playerColor,
                            }}
                          ></div>
                          <p className="text-xl font-bold capitalize text-white/70">
                            {activeSession.playerColor}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button
                    onClick={handleRejoinGame}
                    className="w-full rounded-full py-5 font-bold shadow-lg text-white text-lg"
                    style={{ background: "var(--green-gradient)" }}
                    disabled={isRejoining}
                  >
                    {isRejoining ? "Rejoining..." : "Rejoin Game"}{" "}
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </CardFooter>
              </Card>
            )}

            <Card className="border border-white/10 bg-container backdrop-blur-lg shadow-lg">
              <CardHeader>
                <CardTitle className="text-shadow text-purple-200">
                  Play Now
                </CardTitle>
                <CardDescription className="text-white/80">
                  Create or join a game room to play with friends
                </CardDescription>
              </CardHeader>

              <Tabs defaultValue="create">
                <TabsList className="grid grid-cols-2 mx-6 border border-white/10 bg-white/10">
                  <TabsTrigger
                    value="create"
                    className="text-white data-[state=active]:bg-white/20 data-[state=active]:text-white"
                  >
                    Create Room
                  </TabsTrigger>
                  <TabsTrigger
                    value="join"
                    className="text-white data-[state=active]:bg-white/20 data-[state=active]:text-white"
                  >
                    Join Room
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="create">
                  <form onSubmit={handleCreateRoom}>
                    <CardContent className="space-y-4 pt-4">
                      <div className="space-y-2">
                        <Label htmlFor="create-name" className="text-white">
                          Your Name
                        </Label>
                        <Input
                          id="create-name"
                          placeholder="Enter your name"
                          value={playerName}
                          onChange={(e) => setPlayerName(e.target.value)}
                          required
                          className="bg-white/10 border-white/10 text-white placeholder:text-white/50 focus-visible:ring-white/30"
                        />
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button
                        type="submit"
                        className="w-full rounded-full py-5 font-bold shadow-lg text-white text-lg"
                        style={{ background: "var(--purple-gradient)" }}
                        disabled={isCreating || !createReady}
                      >
                        {isCreating ? "Creating..." : "Create Room"}
                      </Button>
                    </CardFooter>
                  </form>
                </TabsContent>

                <TabsContent value="join">
                  <form onSubmit={handleJoinRoom}>
                    <CardContent className="space-y-4 pt-4">
                      <div className="space-y-2">
                        <Label htmlFor="join-name" className="text-white">
                          Your Name
                        </Label>
                        <Input
                          id="join-name"
                          placeholder="Enter your name"
                          value={playerName}
                          onChange={(e) => setPlayerName(e.target.value)}
                          required
                          className="bg-white/10 border-white/10 text-white placeholder:text-white/50 focus-visible:ring-white/30"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="room-code" className="text-white">
                          Room Code
                        </Label>
                        <Input
                          id="room-code"
                          placeholder="Enter 6-digit code"
                          value={roomCode}
                          onChange={(e) =>
                            setRoomCode(
                              e.target.value.replace(/\D/g, "").slice(0, 6)
                            )
                          }
                          maxLength={6}
                          pattern="[0-9]{6}"
                          required
                          className="bg-white/10 border-white/10 text-white placeholder:text-white/50 focus-visible:ring-white/30"
                        />
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button
                        type="submit"
                        className="w-full rounded-full py-5 font-bold shadow-lg text-white text-lg"
                        style={{ background: "var(--purple-gradient)" }}
                        disabled={isJoining || !joinReady}
                      >
                        {isJoining ? "Joining..." : "Join Room"}
                      </Button>
                    </CardFooter>
                  </form>
                </TabsContent>
              </Tabs>
            </Card>

            <div className="text-center mt-6">
              <div className="flex items-center justify-center gap-2 text-sm text-white/70 bg-container backdrop-blur-sm rounded-full px-4 py-2 border border-white/10 shadow-lg">
                <Users className="w-4 h-4" />
                <span>Play with 2-4 players</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
