"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { useGameStore } from "@/lib/game/store";
import { useSocket } from "@/lib/socket/client";
import { useGameEvents } from "@/lib/game/useGameEvents";
import {
  saveGameSession,
  updateSessionActivity,
  clearGameSession,
  getGameSession,
} from "@/lib/game/sessionStorage";

import { Player, Message, TokenPosition, GameState } from "@/lib/game/types";
import { useTokenSync } from "@/lib/game/useTokenSync";
import { useSyncPlayerData } from "@/lib/game/useSyncPlayerData";
import TokenSynchronizer from "@/components/TokenSynchronizer";
import LudoBoard from "@/components/LudoBoard";
import PlayerInfoModal from "@/components/PlayerInfoModal";
import DiceComponent from "@/components/Dice";
import soundManager from "@/lib/sound/soundManager";
import { VictoryModal } from "@/components/VictoryModal";
import GamePausedOverlay from "@/components/GamePausedOverlay";
import { SoundControl } from "@/components/SoundControl";
import "@/lib/dice-types"; // Import for TypeScript global declarations
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { ArrowLeft, InfoIcon } from "lucide-react";
import PlayerCard from "@/components/PlayerCard";

export default function RoomPage() {
  const router = useRouter();
  const params = useParams();
  const roomCode = (params?.code as string) || "";

  const { socket, connected } = useSocket();
  const [isLoading, setIsLoading] = useState(true);
  // Add these state variables inside your component
  const [isVictoryModalOpen, setIsVictoryModalOpen] = useState(false);
  const [winner, setWinner] = useState<Player | null>(null);
  const [winReason, setWinReason] = useState<string | undefined>(undefined);

  // Use the token sync hook to ensure all players have proper token data
  useTokenSync();
  const {
    setRoomData,
    players,
    gameState,
    currentTurn,
    currentPlayer,
    playerId,
    playerName,
    setPlayerId,
    addPlayer,
    removePlayer,
    updateGameState,
    setCurrentTurn,
    setDice,
    lastRoll,
    setLastRoll,
    isRolling,
    setIsRolling,
    hasDiceBeenRolled,
    setHasDiceBeenRolled,
    addMessage,
    selectedTokenId,
    setSelectedTokenId,
    messages,
    updatePlayerReady,
  } = useGameStore();
  // Get current player's color
  const currentPlayerColor = players.find((p) => p.id === playerId)?.color as
    | "red"
    | "green"
    | "blue"
    | "yellow"
    | undefined;

  // Is it the current player's turn?
  const isPlayerTurn = currentPlayer?.id === playerId;

  // Handle player joined
  const handlePlayerJoined = (player: Player) => {
    console.log("🚀 Player joined event received:", player);
    console.log(
      "Current players before adding:",
      players.map((p) => `${p.name} (${p.id})`)
    );

    // Ensure tokens are properly initialized
    if (
      !player.tokens ||
      !Array.isArray(player.tokens) ||
      player.tokens.length !== 4
    ) {
      player.tokens = [
        { id: 0, position: "home" as TokenPosition, steps: 0 },
        { id: 1, position: "home" as TokenPosition, steps: 0 },
        { id: 2, position: "home" as TokenPosition, steps: 0 },
        { id: 3, position: "home" as TokenPosition, steps: 0 },
      ];
    }

    // Check if player already exists to avoid duplicates
    const existingPlayerIndex = players.findIndex((p) => p.id === player.id);
    if (existingPlayerIndex !== -1) {
      console.log(
        `Player ${player.name} already exists at index ${existingPlayerIndex}, not adding again`
      );
      return;
    }

    console.log(`Adding new player: ${player.name} (${player.id})`);
    addPlayer(player);
    toast(`${player.name} joined the game`);

    // Log players after adding to verify state update
    setTimeout(() => {
      console.log(
        "Current players after adding:",
        useGameStore.getState().players.map((p) => `${p.name} (${p.id})`)
      );
    }, 0);
  };
  // Handle game started
  const handleGameStarted = (roomData: any) => {
    console.log("Game started/updated with room data:", roomData);

    // Removed the early return for player count < 2
    // to properly update UI even with a single player

    // Ensure all players have properly initialized tokens
    if (roomData && roomData.players) {
      // Validate and fix player tokens if needed
      const validatedPlayers = roomData.players.map((player: Player) => {
        // If tokens are missing or invalid, create default tokens
        if (
          !player.tokens ||
          !Array.isArray(player.tokens) ||
          player.tokens.length !== 4
        ) {
          console.log(`Fixing missing tokens for player ${player.name}`);
          return {
            ...player,
            tokens: [
              { id: 0, position: "home" as TokenPosition, steps: 0 },
              { id: 1, position: "home" as TokenPosition, steps: 0 },
              { id: 2, position: "home" as TokenPosition, steps: 0 },
              { id: 3, position: "home" as TokenPosition, steps: 0 },
            ],
          };
        }
        return player;
      });

      // Update room data with validated players
      const updatedRoomData = {
        ...roomData,
        players: validatedPlayers,
      };
      console.log("Setting room data with validated players:", updatedRoomData);
      setRoomData(updatedRoomData);
    } else {
      console.log("Setting room data without validation:", roomData);
      setRoomData(roomData);
    }

    // Only update game state to "playing" and show toast if the game is actually starting
    if (roomData.gameState === "playing") {
      updateGameState("playing");
      setIsLoading(false);
      toast("Game started!");
    }
  };

  // Handle dice rolled
  const handleDiceRolled = (data: { playerId: string; diceValue: number }) => {
    console.log("Dice rolled event received from server", data);

    // Create a unique roll ID to track this specific roll event
    const rollId = Date.now();
    // @ts-ignore - Adding custom property to window for tracking
    window.lastDiceRollId = rollId;

    // Validate dice value - must be between 1 and 6
    const diceValue =
      data.diceValue >= 1 && data.diceValue <= 6
        ? data.diceValue
        : Math.floor(Math.random() * 6) + 1;

    console.log(
      `Processed dice value: ${diceValue} (original: ${data.diceValue})`
    );

    // Clear any existing timeout
    // @ts-ignore - Adding custom property to window for tracking
    if (window.diceRollSafetyTimeoutId) {
      console.log("Clearing existing safety timeout");
      // @ts-ignore
      clearTimeout(window.diceRollSafetyTimeoutId);
      // @ts-ignore
      window.diceRollSafetyTimeoutId = null;
    }

    // IMPORTANT: Set the server dice value immediately, even before animation
    // This ensures the dice component always has access to the correct value
    setDice(diceValue);
    setLastRoll(diceValue); // Set lastRoll as well to maintain consistency
    console.log("Server dice value set immediately:", diceValue);

    // Start rolling animation
    setIsRolling(true);

    // Use a timeout to stop the animation and confirm the final value
    const animationTimeout = setTimeout(() => {
      // Only process this timeout if it's from the most recent roll
      // @ts-ignore
      if (window.lastDiceRollId !== rollId) {
        console.log("Ignoring outdated dice roll animation completion");
        return;
      }

      // Stop animation
      setIsRolling(false);

      // Force state consistency by setting both dice values again
      setDice(diceValue);
      setLastRoll(diceValue);

      if (data.playerId === playerId) {
        setHasDiceBeenRolled(true);
      }

      console.log("Final dice value confirmed:", diceValue);

      // Safety check to verify dice values are consistent after animation
      // @ts-ignore
      window.diceRollSafetyTimeoutId = setTimeout(() => {
        const currentState = useGameStore.getState();
        if (
          currentState.dice !== diceValue ||
          currentState.lastRoll !== diceValue
        ) {
          console.warn("Dice value inconsistency detected, forcing update");
          setDice(diceValue);
          setLastRoll(diceValue);
        }
      }, 100);
    }, 1200); // Match animation duration

    // Optional: Handle special notifications or other UI updates
    const player = players.find((p) => p.id === data.playerId);
    if (player) {
      toast(`${player.name} rolled a ${diceValue}`);
    }
  };

  // Handle token moved
  const handleTokenMoved = (data: {
    playerId: string;
    tokenId: number;
    newPosition: string;
    steps: number;
    reason?: string;
  }) => {
    // Find the player and token before update to get the old steps value
    const player = players.find((p) => p.id === data.playerId);
    const token = player?.tokens.find((t) => t.id === data.tokenId);
    const oldSteps = token?.steps || 0;
    const isOpponentMove = data.playerId !== playerId;

    // Update player's token state
    const updatedPlayers = players.map((player) => {
      if (player.id === data.playerId) {
        const updatedTokens = player.tokens.map((token) => {
          if (token.id === data.tokenId) {
            return {
              ...token,
              position: data.newPosition as TokenPosition,
              steps: data.steps,
            };
          }
          return token;
        });

        return {
          ...player,
          tokens: updatedTokens,
        };
      }
      return player;
    });

    // Make sure we preserve the current messages when updating room data
    setRoomData({
      code: roomCode,
      players: updatedPlayers,
      gameState,
      currentTurn,
      messages: messages, // Keep existing messages
      dice: 0,
      maxPlayers: useGameStore.getState().maxPlayers,
    });
    setSelectedTokenId(null);

    // Reset hasDiceBeenRolled only for the current player when they move a token
    // and it's not due to a disconnection
    if (data.playerId === playerId && data.reason !== "player-disconnected") {
      setHasDiceBeenRolled(false);
    }

    // Add a special message for tokens sent home due to player disconnection
    if (data.reason === "player-disconnected") {
      const player = updatedPlayers.find((p) => p.id === data.playerId);
      if (player) {
        toast(`${player.name}'s token was sent back home`, {
          duration: 2000,
        });
      }
    } // Animate opponent token movements if position is "board" and steps changed    // This ensures we only animate valid board movements (not home->start or going to home)
    if (
      isOpponentMove &&
      data.newPosition === "board" &&
      token?.position === "board" &&
      oldSteps !== data.steps
    ) {      // Play appropriate sound for opponent moves too
      // Server reason values:
      // - "captured" - when token is captured and sent back home
      // - "reached-finish" - when token reaches the finish
      // - "normal-move" - for regular token movement
      // - "player-disconnected" - when token sent home due to disconnection
      // - "player-left" - when token sent home due to player leaving
      if (data.reason === "captured") {
        soundManager?.play("cut", 0.7);
      } else if (data.reason === "reached-finish") {
        // Special sound for reaching finish could be added here
        soundManager?.play("move", 0.7);
      }
      // Normal move sounds are now handled by the animation steps

      // Get the LudoBoard ref to call its animation method
      const ludoBoardElement = document.querySelector(
        '[data-ludo-board="true"]'
      );
      if (ludoBoardElement) {
        // Create and dispatch a custom event to trigger animation in the Ludo board
        const animateEvent = new CustomEvent("animate-token-movement", {
          detail: {
            playerId: data.playerId,
            tokenId: data.tokenId,
            fromSteps: oldSteps,
            toSteps: data.steps,
          },
        });
        ludoBoardElement.dispatchEvent(animateEvent);
      }
    }

    // Log the token counts for debugging
    console.log(
      "Updated player tokens:",
      updatedPlayers.map((p) => ({
        id: p.id,
        name: p.name,
        isDisconnected: p.isDisconnected,
        tokensHome: p.tokens.filter((t) => t.position === "home").length,
        tokensBoard: p.tokens.filter((t) => t.position === "board").length,
        tokensFinished: p.tokens.filter((t) => t.position === "finished")
          .length,
      }))
    );
  }; // Handle next turn
  const handleNextTurn = (data: { currentTurn: number; reason?: string }) => {
    setCurrentTurn(data.currentTurn);

    // Always reset hasDiceBeenRolled to ensure tokens don't remain active between turns
    setHasDiceBeenRolled(false);

    const nextPlayer = players[data.currentTurn];
    if (nextPlayer) {
      // Show different messages based on the reason for the turn change
      if (data.reason === "no-valid-moves") {
        toast(`${nextPlayer.name}'s turn (previous player had no valid moves)`);
      } else {
        toast(`${nextPlayer.name}'s turn`);
      }
    }

    // Reset the last roll when the turn changes
    setLastRoll(0);
  };
  // Handle extra turn (when a player rolls a 6)
  const handleExtraTurn = (data: {
    currentTurn: number;
    playerId: string;
    playerName: string;
  }) => {
    // The current player gets another turn after rolling a 6
    toast(`${data.playerName} rolled a 6 and gets another turn!`);

    // Reset the last roll to allow rolling again
    setLastRoll(0);
    setHasDiceBeenRolled(false); // Reset the flag for extra turn
  }; // Handle game over
  const handleGameOver = useCallback(
    (data: { winnerId: string; winner: Player; reason?: string }) => {
      console.log(
        "Game over with winner:",
        data.winner.name,
        "Reason:",
        data.reason
      );
      setWinner(data.winner);
      setWinReason(data.reason);
      setIsVictoryModalOpen(true);

      // Update room data
      setRoomData({
        code: roomCode,
        players,
        gameState: "finished",
        currentTurn,
        messages,
        dice: 0,
        maxPlayers: useGameStore.getState().maxPlayers,
      });
    },
    [roomCode, players, currentTurn, messages, setRoomData]
  ); // Handle player disconnected
  const handlePlayerDisconnected = (data: {
    playerId: string;
    playerName: string;
    isDisconnected: boolean;
    gameState?: string;
  }) => {
    // Instead of removing the player, update their status to disconnected
    // Find the player and mark them as disconnected
    const updatedPlayers = players.map((player) => {
      if (player.id === data.playerId) {
        return {
          ...player,
          isDisconnected: true,
          disconnectPending: false, // Remove the pending status
        };
      }
      return player;
    });

    // Use the game state from the server if provided, otherwise keep current state
    const updatedGameState = data.gameState || gameState;

    // Update the game store with the updated players and game state
    setRoomData({
      code: roomCode,
      players: updatedPlayers,
      gameState: updatedGameState as GameState,
      currentTurn,
      messages,
      dice: 0,
      maxPlayers: useGameStore.getState().maxPlayers,
    });

    toast(`${data.playerName} disconnected from the game`, {
      duration: 3000,
      style: { backgroundColor: "#f87171", color: "white" },
    });

    // Check if we're in playing state and there's only one active player left
    if (gameState === "playing" || updatedGameState === "playing") {
      // Count active (non-disconnected) players
      const activePlayers = updatedPlayers.filter(
        (player) => !player.isDisconnected
      );

      // Check if there are any players in the "temporarily disconnected" state
      const temporarilyDisconnectedPlayers = updatedPlayers.filter(
        (player) => player.disconnectPending === true
      );

      // Only declare a winner if there are no temporarily disconnected players
      // and only one active player remains
      if (
        activePlayers.length === 1 &&
        temporarilyDisconnectedPlayers.length === 0
      ) {
        const lastPlayer = activePlayers[0];
        console.log(
          `Only one player remains: ${lastPlayer.name}. Declaring them as the winner.`
        );

        // Call handleGameOver with the last remaining player as winner
        handleGameOver({
          winnerId: lastPlayer.id,
          winner: lastPlayer,
          reason: "last-player-remaining",
        });

        toast(`${lastPlayer.name} wins as the last player remaining!`, {
          duration: 5000,
        });
      } else if (
        activePlayers.length === 1 &&
        temporarilyDisconnectedPlayers.length > 0
      ) {
        console.log(
          `One active player and ${temporarilyDisconnectedPlayers.length} temporarily disconnected players. Waiting for reconnection...`
        );
      }
    }
  };

  // Handle new message
  const handleNewMessage = (message: Message) => {
    addMessage(message);
    // Update session activity timestamp when interacting with the game
    updateSessionActivity();
  }; // Add handler for player reconnection
  const handlePlayerReconnected = (data: {
    playerId: string;
    playerName: string;
    gameState?: string;
  }) => {
    console.log(`Player ${data.playerName} reconnected to the game`);

    // Update player status to remove any disconnection flags
    const updatedPlayers = players.map((player) => {
      if (player.id === data.playerId) {
        // Remove disconnection properties
        const updatedPlayer = { ...player };
        delete updatedPlayer.disconnectPending;
        updatedPlayer.isDisconnected = false;
        return updatedPlayer;
      }
      return player;
    });

    // If the game was paused, it should now be resumed (playing)
    // If we received a gameState from the server, use that instead
    const updatedGameState =
      data.gameState || (gameState === "paused" ? "playing" : gameState);

    // Update the game store with the updated players and game state
    setRoomData({
      code: roomCode,
      players: updatedPlayers,
      gameState: updatedGameState as GameState,
      currentTurn,
      messages,
      dice: 0,
      maxPlayers: useGameStore.getState().maxPlayers,
    });

    toast(`${data.playerName} reconnected to the game`, {
      duration: 5000,
      style: { backgroundColor: "#10b981", color: "white" },
    });
  }; // Handle player temporarily disconnected
  const handlePlayerTemporaryDisconnect = (data: {
    playerId: string;
    playerName: string;
    gameState?: string;
  }) => {
    // Mark player as temporarily disconnected in UI
    const updatedPlayers = players.map((player) => {
      if (player.id === data.playerId) {
        return {
          ...player,
          disconnectPending: true,
        };
      }
      return player;
    });

    // Use the game state from the server if provided, otherwise keep current state
    const updatedGameState = data.gameState || gameState;

    // Update the game store with the updated players and game state
    setRoomData({
      code: roomCode,
      players: updatedPlayers,
      gameState: updatedGameState as GameState,
      currentTurn,
      messages,
      dice: 0,
      maxPlayers: useGameStore.getState().maxPlayers,
    });

    // Show toast with information about the reconnection window
    toast(
      `${data.playerName} temporarily disconnected. They have 2 minutes to rejoin.`,
      {
        duration: 5000,
        style: { backgroundColor: "#f59e0b", color: "white" },
      }
    );

    // Log the event for debugging
    console.log(
      `Player ${data.playerName} temporarily disconnected. Waiting 2 minutes for reconnection.`
    );
  };

  // Handle player ready changed
  const handlePlayerReadyChanged = (data: {
    playerId: string;
    isReady: boolean;
  }) => {
    // Update player status
    const updatedPlayers = players.map((player) => {
      if (player.id === data.playerId) {
        return { ...player, isReady: data.isReady };
      }
      return player;
    });

    // Update the game store with the updated players
    setRoomData({
      code: roomCode,
      players: updatedPlayers,
      gameState,
      currentTurn,
      messages,
      dice: 0,
      maxPlayers: useGameStore.getState().maxPlayers,
    });
  };

  // Handle invalid move
  const handleInvalidMove = (data: { message: string }) => {
    toast(data.message, {
      duration: 3000,
      style: { backgroundColor: "#f87171", color: "white" },
    });
  };

  // Handle player count updated
  const handlePlayerCountUpdated = (data: {
    maxPlayers: number;
    players: Player[];
  }) => {
    // Update max players
    const { setMaxPlayers } = useGameStore.getState();
    setMaxPlayers(data.maxPlayers);

    // Update room data with the new player list
    setRoomData({
      code: roomCode,
      players: data.players,
      gameState,
      currentTurn,
      messages,
      dice: 0,
      maxPlayers: data.maxPlayers,
    });
  };

  // Handle game reset
  const handleGameReset = (roomData: any) => {
    // Reset game state
    setRoomData(roomData);
    updateGameState(roomData.gameState);
    setCurrentTurn(roomData.currentTurn);
    setDice(0);
    setLastRoll(0);
    setHasDiceBeenRolled(false);
    setWinner(null);
    setWinReason(undefined);

    toast("Game has been reset", {
      duration: 3000,
      style: { backgroundColor: "#4ade80", color: "white" },
    });
  };

  // Register game events
  const {
    rollDice,
    moveToken,
    sendMessage,
    toggleReady,
    startGame,
    setPlayerCount,
    resetGame,
    emitPlayerLeave,
  } = useGameEvents(
    handlePlayerJoined,
    handleGameStarted,
    handleDiceRolled,
    handleTokenMoved,
    handleNextTurn,
    handleExtraTurn,
    handleGameOver,
    handlePlayerDisconnected,
    handleNewMessage,
    handlePlayerReadyChanged,
    handleInvalidMove,
    handlePlayerCountUpdated,
    handleGameReset,
    handlePlayerReconnected,
    handlePlayerTemporaryDisconnect
  );

  // Handle leave game
  const handleLeaveGame = () => {
    // Clear the session when leaving the game
    clearGameSession();

    if (
      gameState === "playing" &&
      players.filter((p) => !p.isDisconnected).length > 1
    ) {
      // If in playing state with multiple active players, mark this player as leaving
      const updatedPlayers = players.map((player) => {
        if (player.id === playerId) {
          return {
            ...player,
            isDisconnected: true,
          };
        }
        return player;
      });

      // Notify the server that this player is leaving
      emitPlayerLeave(roomCode);

      // Don't reset the game, just notify server player is leaving
    } else {
      // Only notify the server that player is leaving
      emitPlayerLeave(roomCode);
    }

    // Navigate back to home
    router.push("/");
  };

  // Handle roll dice
  const handleRollDice = () => {
    console.log("handleRollDice called", {
      isPlayerTurn,
      gameState,
      isRolling,
      lastRoll,
    }); // Multiple safety checks
    if (!isPlayerTurn) {
      console.log("Not player's turn - cannot roll");
      toast("It's not your turn!");
      return;
    }

    if (gameState !== "playing") {
      console.log(
        `Game not in playing state (current state: ${gameState}) - cannot roll`
      );
      if (gameState === "paused") {
        toast("Game is paused while waiting for a player to reconnect");
      }
      return;
    }

    if (isRolling) {
      console.log("Dice already rolling - cannot roll again");
      return;
    }

    if (lastRoll > 0) {
      console.log("Already rolled - must move a token first");
      toast("Move a token first!");
      return;
    }

    // IMPORTANT CHANGE: Generate dice value locally first
    // This ensures the animation shows the correct value immediately
    const clientDiceValue = Math.floor(Math.random() * 6) + 1;
    console.log("Client generated dice value:", clientDiceValue);

    // Create a unique roll ID to track this roll
    const rollId = Date.now();
    // @ts-ignore - Adding custom property to window for tracking
    window.lastDiceRollId = rollId;

    // Set the dice values immediately with our client-generated value
    setDice(clientDiceValue);
    setLastRoll(clientDiceValue);

    // Set UI state to show rolling animation
    setIsRolling(true);

    try {
      // Set a safety timeout to recover if server doesn't respond
      // @ts-ignore
      window.diceRollSafetyTimeoutId = setTimeout(() => {
        // Use the current state from the store to ensure we have the latest values
        const { isRolling: currentIsRolling } = useGameStore.getState();

        // Only proceed if we're still in the rolling state (no server response yet)
        if (currentIsRolling) {
          console.log("Safety timeout triggered - using local dice value");
          console.log("Using local dice value:", clientDiceValue);

          // Then stop rolling
          setIsRolling(false);
          setHasDiceBeenRolled(true);

          // Add an additional check after a short delay to ensure values are consistent
          setTimeout(() => {
            // Verify values match what we expect
            if (
              useGameStore.getState().lastRoll !== clientDiceValue ||
              useGameStore.getState().dice !== clientDiceValue
            ) {
              console.log("Local values don't match, forcing update");
              setDice(clientDiceValue);
              setLastRoll(clientDiceValue);
            }
          }, 100);

          toast("Connection issue - using local dice value", {
            duration: 3000,
          });

          // Check if player can make valid moves with this value
          const currentPlayer = players.find((p) => p.id === playerId);
          if (currentPlayer) {
            const canMakeValidMove =
              clientDiceValue === 6 ||
              currentPlayer.tokens.some((token) => token.position === "board");

            if (!canMakeValidMove) {
              toast("No valid moves available - turn will be skipped", {
                duration: 3000,
              });

              // Auto-advance turn locally since server might be unresponsive
              setTimeout(() => {
                // Find the next player's index
                const nextTurnIndex = (currentTurn + 1) % players.length;
                setCurrentTurn(nextTurnIndex);
                setLastRoll(0);
                setHasDiceBeenRolled(false);

                const nextPlayer = players[nextTurnIndex];
                if (nextPlayer) {
                  toast(`${nextPlayer.name}'s turn`, {
                    duration: 3000,
                  });
                }
              }, 1500);
            }
          }
        }
      }, 5000); // Give server 5 seconds to respond before using local value permanently

      // Now emit the roll event to the server WITH the client-generated value
      // Modified to include our client-generated value (requires updating useGameEvents and server)
      rollDice(roomCode, clientDiceValue);
      console.log(
        "Roll dice event with client value emitted to server:",
        clientDiceValue
      );

      // Use a timeout to stop the animation and finalize the roll
      setTimeout(() => {
        // Only process this timeout if it's from the most recent roll
        // @ts-ignore
        if (window.lastDiceRollId !== rollId) {
          console.log("Ignoring outdated dice roll animation completion");
          return;
        }

        // Stop animation
        setIsRolling(false);

        // Final confirmation of dice value after animation
        console.log("Animation complete, final dice value:", clientDiceValue);

        // If this player's turn, set the dice rolled flag
        setHasDiceBeenRolled(true);
      }, 1200); // Match animation duration
    } catch (err) {
      console.error("Error emitting roll dice event:", err);

      // Clear the timeout and reset state in case of error
      // @ts-ignore
      if (window.diceRollSafetyTimeoutId) {
        // @ts-ignore
        clearTimeout(window.diceRollSafetyTimeoutId);
        // @ts-ignore
        window.diceRollSafetyTimeoutId = null;
      }
      setIsRolling(false);
    }
  };

  // Handle token click
  const handleTokenClick = (tokenId: number) => {
    console.log("Token click handler called", {
      isPlayerTurn,
      lastRoll,
      gameState,
      tokenId,
    });

    if (!isPlayerTurn) {
      toast("It's not your turn!");
      return;
    }
    if (gameState !== "playing") {
      return;
    }

    // Make sure the dice has been rolled first
    if (!hasDiceBeenRolled) {
      toast("Roll the dice first!");
      return;
    }

    // Check if we have a valid dice roll (1-6)
    if (lastRoll >= 1 && lastRoll <= 6) {
      const currentPlayer = players.find((p) => p.id === playerId);
      if (!currentPlayer) return;

      const token = currentPlayer.tokens[tokenId];

      // Validate the move according to Ludo rules
      if (token.position === "home" && lastRoll !== 6) {
        toast("You need to roll a 6 to move a token out of home!");
        return;
      }

      if (token.position === "finished") {
        toast("This token has already reached the finish!");
        return;
      }
      console.log(`Moving token ${tokenId} with roll value ${lastRoll}`);
      setSelectedTokenId(tokenId);
      moveToken(roomCode, tokenId);
      setHasDiceBeenRolled(false); // Reset the flag after a move has been made

      // Let the server handle resetting the lastRoll
    } else {
      console.log("Cannot move token - invalid roll value:", lastRoll);
      toast("Roll the dice first!");
    }
  };

  // Handle toggle ready
  const handleToggleReady = () => {
    if (roomCode) {
      toggleReady(roomCode);
    }
  };

  // Handle start game
  const handleStartGame = () => {
    if (roomCode) {
      startGame(roomCode);
    }
  };

  // Handle emoji click
  const handleEmojiClick = (emoji: string) => {
    sendMessage(roomCode, emoji);
  }; // Handle set player count
  const handleSetPlayerCount = (count: number) => {
    if (roomCode) {
      setPlayerCount(roomCode, count);
    }
  }; // Setup socket connection and initialize player data on room join
  useEffect(() => {
    // Only proceed if we have both a player name and a connected socket
    if (connected && socket && playerName) {
      console.log("Socket connected, setting player ID:", socket.id);

      if (socket.id) {
        setPlayerId(socket.id);

        // Get the current players from the store
        const currentPlayers = useGameStore.getState().players;
        console.log(
          "Current players in store:",
          currentPlayers.map((p) => p.name)
        );

        // Check if the current player (self) is already in the players list
        const playerExists = currentPlayers.some((p) => p.id === socket.id);

        if (!playerExists) {
          console.log(
            `Adding self (${playerName}) to players list with ID ${socket.id}`
          ); // Create a temporary player object for this client
          // This will be overwritten once we get the actual room data from the server
          const selfPlayer: Player = {
            id: socket.id,
            name: playerName,
            color:
              currentPlayers.length === 0
                ? "red"
                : currentPlayers.length === 1
                ? "green"
                : currentPlayers.length === 2
                ? "blue"
                : ("yellow" as "red" | "green" | "blue" | "yellow"),
            isHost: currentPlayers.length === 0, // First player is host
            isReady: false,
            tokens: [
              { id: 0, position: "home", steps: 0 },
              { id: 1, position: "home", steps: 0 },
              { id: 2, position: "home", steps: 0 },
              { id: 3, position: "home", steps: 0 },
            ],
          };

          // Add self to players temporarily
          // This ensures the player appears in the UI immediately
          addPlayer(selfPlayer);
        }
      }
      setIsLoading(false);
    }
  }, [connected, socket, playerName, setPlayerId, addPlayer]);
  // Initialize the global timeout variable
  useEffect(() => {
    // Initialize the global timeout ID on component mount
    window.diceRollSafetyTimeoutId = null;

    // Cleanup on unmount
    return () => {
      if (window.diceRollSafetyTimeoutId) {
        clearTimeout(window.diceRollSafetyTimeoutId);
        window.diceRollSafetyTimeoutId = null;
      }
    };
  }, []);
  // Check for existing session and try to rejoin when directly accessing the room URL
  useEffect(() => {
    // Only proceed when socket is connected but we don't have player name yet
    if (connected && socket && !playerName && !isLoading) {
      console.log("Checking for existing session on direct room access");
      const existingSession = getGameSession();

      // If we have a session for this room, attempt to rejoin
      if (existingSession && existingSession.roomCode === roomCode) {
        console.log("Found matching session for room:", roomCode);
        console.log("Session data:", existingSession);

        // Set loading to prevent redirect while we attempt to rejoin
        setIsLoading(true);

        // Create player data object for rejoin
        const playerData = {
          name: existingSession.playerName,
          color: existingSession.playerColor,
          originalId: existingSession.originalId || existingSession.playerId,
        };

        console.log("Attempting to rejoin with player data:", playerData);

        // Attempt to rejoin the room
        socket.emit(
          "rejoin-room",
          { roomCode, playerData },
          (success: boolean, roomData: any) => {
            if (success) {
              console.log("Successfully rejoined room on direct access");

              // Set player name in store so we stay in this room
              useGameStore.getState().setPlayerName(existingSession.playerName);

              // Set isLoading to false after successful rejoin
              setIsLoading(false);
            } else {
              console.error("Failed to rejoin room on direct access");
              clearGameSession(); // Clear invalid session
              router.push("/"); // Redirect to home page
            }
          }
        );
      } else {
        // No matching session found, redirect to main page
        console.log("No matching session found for room:", roomCode);
        router.push("/");
      }
    }
  }, [connected, socket, playerName, roomCode, isLoading, router]);

  // Redirect if no player name
  useEffect(() => {
    if (!isLoading && !playerName) {
      router.push("/");
    }
  }, [isLoading, playerName, router]);
  // Helper function to map players to their board positions after rotation
  const getRotatedPlayerPositions = () => {
    if (!currentPlayerColor || players.length === 0) {
      return {
        topLeft: null,
        topRight: null,
        bottomLeft: null,
        bottomRight: null,
      };
    }

    // The board rotation is: Blue=0°, Yellow=90°, Green=180°, Red=270°
    // This maps which color goes in which position after rotation
    const positionMapping = {
      blue: {
        topLeft: "red", // Red is at top-left when blue is at bottom-left
        topRight: "green", // Green is at top-right when blue is at bottom-left
        bottomLeft: "blue", // Blue is at bottom-left
        bottomRight: "yellow", // Yellow is at bottom-right
      },
      yellow: {
        topLeft: "blue", // Blue is at top-left when yellow is at bottom-left
        topRight: "red", // Red is at top-right when yellow is at bottom-left
        bottomLeft: "yellow", // Yellow is at bottom-left
        bottomRight: "green", // Green is at bottom-right
      },
      green: {
        topLeft: "yellow", // Yellow is at top-left when green is at bottom-left
        topRight: "blue", // Blue is at top-right when green is at bottom-left
        bottomLeft: "green", // Green is at bottom-left
        bottomRight: "red", // Red is at bottom-right
      },
      red: {
        topLeft: "green", // Green is at top-left when red is at bottom-left
        topRight: "yellow", // Yellow is at top-right when red is at bottom-left
        bottomLeft: "red", // Red is at bottom-left
        bottomRight: "blue", // Blue is at bottom-right
      },
    };

    // Get the correct mapping based on current player's color
    const mapping =
      positionMapping[currentPlayerColor as keyof typeof positionMapping] ||
      positionMapping.blue; // default to blue mapping if color not found

    // Find players for each position or return null if no player has that color
    const positions = {
      topLeft: players.find((p) => p.color === mapping.topLeft) || null,
      topRight: players.find((p) => p.color === mapping.topRight) || null,
      bottomLeft: players.find((p) => p.color === mapping.bottomLeft) || null,
      bottomRight: players.find((p) => p.color === mapping.bottomRight) || null,
    };

    return positions;
  };

  // Use effect to print players when they change
  useEffect(() => {
    console.log("Current players state:", players);

    // Check if players have proper token data
    if (players && players.length > 0) {
      const playersMissingTokens = players.filter(
        (player) =>
          !player.tokens ||
          !Array.isArray(player.tokens) ||
          player.tokens.length !== 4
      );

      if (playersMissingTokens.length > 0) {
        console.log(
          "Found players missing tokens:",
          playersMissingTokens.map((p) => p.name)
        );

        // Fix the players data by adding default tokens
        const fixedPlayers = players.map((player) => {
          if (
            !player.tokens ||
            !Array.isArray(player.tokens) ||
            player.tokens.length !== 4
          ) {
            return {
              ...player,
              tokens: [
                { id: 0, position: "home" as TokenPosition, steps: 0 },
                { id: 1, position: "home" as TokenPosition, steps: 0 },
                { id: 2, position: "home" as TokenPosition, steps: 0 },
                { id: 3, position: "home" as TokenPosition, steps: 0 },
              ],
            };
          }
          return player;
        });

        // Update room data with the fixed players
        setRoomData({
          code: roomCode,
          players: fixedPlayers,
          gameState,
          currentTurn,
          messages,
          dice: 0,
        });
      }
    }
  }, [players, roomCode, gameState, currentTurn, messages, setRoomData]);

  // Use our custom hook to fix player data issues
  useSyncPlayerData(roomCode, players, (fixedPlayers) => {
    console.log("Setting fixed players data:", fixedPlayers);
    setRoomData({
      code: roomCode,
      players: fixedPlayers,
      gameState,
      currentTurn,
      messages,
      dice: 0,
    });
  }); // When socket connects, save session data including player color
  useEffect(() => {
    if (connected && socket && playerName) {
      // Only save session data once we have a valid player with color
      const playerData = players.find((p) => p.id === socket.id);
      if (playerData) {
        console.log(
          `Saving game session with player color: ${
            playerData.color || "no color"
          }`
        );

        // Get existing session to preserve original ID if it exists
        const existingSession = getGameSession();

        // Use the first value that exists in this priority:
        // 1. Existing originalId from session
        // 2. Current socket.id if no originalId exists yet
        const originalId = existingSession?.originalId || socket.id;

        console.log(`Saving game session with originalId: ${originalId}`);
        console.log(`Current socket.id: ${socket.id}`);

        if (existingSession?.originalId) {
          console.log(
            `Using existing originalId from session: ${existingSession.originalId}`
          );
        } else {
          console.log(
            `No existing originalId found, using current socket.id: ${socket.id}`
          );
        }

        // Save session data with player color and original ID
        saveGameSession(
          roomCode,
          playerName,
          socket.id as string,
          playerData.color as string,
          originalId as string
        );

        // Update the session activity to ensure it stays current
        updateSessionActivity();
      }
    }
  }, [connected, socket, playerName, players, roomCode]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-game-gradient">
        <div className="text-center text-white">
          <h1 className="text-2xl font-bold mb-4 text-shadow">
            Connecting to game...
          </h1>
        </div>
      </div>
    );
  }
  return (
    <div className="bg-ludo-tiled-pattern bg-cover bg-center min-h-screen">
      <div className="min-h-screen bg-game-gradient p-1 sm:p-2 text-white">
        {" "}
        {/* PlayerInfoModal - only shown during "waiting" game state */}
        <PlayerInfoModal
          players={players}
          currentTurn={currentTurn}
          playerId={playerId}
          gameState={gameState}
          onToggleReady={handleToggleReady}
          onStartGame={handleStartGame}
          onSetPlayerCount={handleSetPlayerCount}
          roomCode={roomCode}
          maxPlayers={useGameStore.getState().maxPlayers}
        />{" "}
        <TokenSynchronizer /> {/* Game paused overlay */}
        <GamePausedOverlay
          isVisible={gameState === "paused"}
          disconnectedPlayerName={
            players.find((p) => p.disconnectPending)?.name || "A player"
          }
        />
        {/* Game controls UI */}
        <div className="max-w-[420px] mx-auto">
          {/* Status Bar - Fixed at top */}
          <div className="fixed top-0 left-0 right-0 w-full z-10 bg-black/30 backdrop-blur-md px-4 py-2 flex items-center justify-between border-b border-white/10">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLeaveGame}
              className="flex items-center gap-1 hover:bg-white/10 hover:text-white active:scale-95 transition-all text-white rounded-lg p-2 min-h-[44px] min-w-[44px]"
            >
              <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="sm:inline hidden font-medium">Exit Game</span>
            </Button>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 shadow-md border border-white/20">
              <InfoIcon className="w-4 h-4 text-white/70" />
              <span className="text-white/90 text-sm sm:text-base">
                Room:{" "}
                <span className="font-mono font-bold text-white">
                  {roomCode}
                </span>{" "}
              </span>
            </div>

            {/* Sound control */}
            <div className="flex items-center">
              <SoundControl />
            </div>

            {/* Game paused indicator */}
            {gameState === "paused" && (
              <div className="absolute left-1/2 -translate-x-1/2 top-full bg-amber-500 text-white px-3 py-1 rounded-b-lg text-sm font-bold animate-pulse">
                Game Paused - Waiting for player reconnection
              </div>
            )}
          </div>{" "}
          {/* Game Content - Main Area */}{" "}
          <div className="pt-16 pb-20 md:pb-16 relative">
            <div className="grid grid-cols-1 gap-4 mt-2">
              {" "}
              {/* Player cards - shows all players dynamically */}{" "}
              <div className="w-full space-y-2">
                {/* Top row - players at the top of the board based on rotation */}{" "}
                <div className="flex justify-between gap-2">
                  {/* Top Left Position */}
                  <div className="w-[48%]">
                    {getRotatedPlayerPositions().topLeft && (
                      <PlayerCard
                        key={getRotatedPlayerPositions().topLeft?.id}
                        name={getRotatedPlayerPositions().topLeft?.name || ""}
                        color={
                          getRotatedPlayerPositions().topLeft?.color as
                            | "red"
                            | "green"
                            | "blue"
                            | "yellow"
                        }
                        isCurrentTurn={
                          players.findIndex(
                            (p) =>
                              p.id === getRotatedPlayerPositions().topLeft?.id
                          ) === currentTurn
                        }
                        isHost={
                          getRotatedPlayerPositions().topLeft?.isHost || false
                        }
                        isReady={
                          getRotatedPlayerPositions().topLeft?.isReady || false
                        }
                        isDisconnected={
                          getRotatedPlayerPositions().topLeft?.isDisconnected ||
                          false
                        }
                        disconnectPending={
                          getRotatedPlayerPositions().topLeft
                            ?.disconnectPending || false
                        }
                        isCurrentUser={
                          getRotatedPlayerPositions().topLeft?.id === playerId
                        }
                      />
                    )}
                  </div>

                  {/* Top Right Position */}
                  <div className="w-[48%]">
                    {getRotatedPlayerPositions().topRight && (
                      <PlayerCard
                        key={getRotatedPlayerPositions().topRight?.id}
                        name={getRotatedPlayerPositions().topRight?.name || ""}
                        color={
                          getRotatedPlayerPositions().topRight?.color as
                            | "red"
                            | "green"
                            | "blue"
                            | "yellow"
                        }
                        isCurrentTurn={
                          players.findIndex(
                            (p) =>
                              p.id === getRotatedPlayerPositions().topRight?.id
                          ) === currentTurn
                        }
                        isHost={
                          getRotatedPlayerPositions().topRight?.isHost || false
                        }
                        isReady={
                          getRotatedPlayerPositions().topRight?.isReady || false
                        }
                        isDisconnected={
                          getRotatedPlayerPositions().topRight
                            ?.isDisconnected || false
                        }
                        disconnectPending={
                          getRotatedPlayerPositions().topRight
                            ?.disconnectPending || false
                        }
                        isCurrentUser={
                          getRotatedPlayerPositions().topRight?.id === playerId
                        }
                      />
                    )}
                  </div>
                </div>
              </div>
              {/* Game board */}{" "}
              <div className="flex flex-col items-center justify-center">
                <div className="bg-container rounded-xl shadow-2xl p-2 sm:p-3 mx-auto">
                  <LudoBoard
                    players={players}
                    currentPlayerColor={currentPlayerColor}
                    selectedTokenId={selectedTokenId}
                    isPlayerTurn={isPlayerTurn}
                    gameState={gameState}
                    onTokenClick={handleTokenClick}
                    lastRoll={lastRoll}
                    hasDiceBeenRolled={hasDiceBeenRolled}
                  />
                </div>
              </div>
              {/* Top row - players at the top of the board based on rotation */}{" "}
              <div className="w-full space-y-2">
                {" "}
                <div className="flex justify-between gap-2">
                  {/* Bottom Left Position */}
                  <div className="w-[48%]">
                    {getRotatedPlayerPositions().bottomLeft && (
                      <PlayerCard
                        key={getRotatedPlayerPositions().bottomLeft?.id}
                        name={
                          getRotatedPlayerPositions().bottomLeft?.name || ""
                        }
                        color={
                          getRotatedPlayerPositions().bottomLeft?.color as
                            | "red"
                            | "green"
                            | "blue"
                            | "yellow"
                        }
                        isCurrentTurn={
                          players.findIndex(
                            (p) =>
                              p.id ===
                              getRotatedPlayerPositions().bottomLeft?.id
                          ) === currentTurn
                        }
                        isHost={
                          getRotatedPlayerPositions().bottomLeft?.isHost ||
                          false
                        }
                        isReady={
                          getRotatedPlayerPositions().bottomLeft?.isReady ||
                          false
                        }
                        isDisconnected={
                          getRotatedPlayerPositions().bottomLeft
                            ?.isDisconnected || false
                        }
                        disconnectPending={
                          getRotatedPlayerPositions().bottomLeft
                            ?.disconnectPending || false
                        }
                        isCurrentUser={
                          getRotatedPlayerPositions().bottomLeft?.id ===
                          playerId
                        }
                      />
                    )}
                  </div>

                  {/* Bottom Right Position */}
                  <div className="w-[48%]">
                    {getRotatedPlayerPositions().bottomRight && (
                      <PlayerCard
                        key={getRotatedPlayerPositions().bottomRight?.id}
                        name={
                          getRotatedPlayerPositions().bottomRight?.name || ""
                        }
                        color={
                          getRotatedPlayerPositions().bottomRight?.color as
                            | "red"
                            | "green"
                            | "blue"
                            | "yellow"
                        }
                        isCurrentTurn={
                          players.findIndex(
                            (p) =>
                              p.id ===
                              getRotatedPlayerPositions().bottomRight?.id
                          ) === currentTurn
                        }
                        isHost={
                          getRotatedPlayerPositions().bottomRight?.isHost ||
                          false
                        }
                        isReady={
                          getRotatedPlayerPositions().bottomRight?.isReady ||
                          false
                        }
                        isDisconnected={
                          getRotatedPlayerPositions().bottomRight
                            ?.isDisconnected || false
                        }
                        disconnectPending={
                          getRotatedPlayerPositions().bottomRight
                            ?.disconnectPending || false
                        }
                        isCurrentUser={
                          getRotatedPlayerPositions().bottomRight?.id ===
                          playerId
                        }
                      />
                    )}
                  </div>
                </div>
              </div>
              {/* Player info panels */}
              <div className="flex flex-col space-y-3">
                {/* Emoji button row */}

                <div className="flex flex-wrap gap-3 justify-center">
                  {[
                    "🎲", // Dice
                    "🎮", // Game
                    "🏆", // Winner
                    "😂", // Funny fail or banter
                    "😅", // Close call
                    "🥳", // Celebration
                    "🔥", // Epic move
                  ].map((emoji) => (
                    <button
                      key={emoji}
                      className="text-2xl hover:scale-125 transition-transform focus:outline-none p-1 bg-white/10 rounded-full w-10 h-10 flex items-center justify-center"
                      onClick={() => handleEmojiClick(emoji)}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>

                {/* Dice area */}
                <div className="flex justify-center mb-2">
                  {gameState === "waiting" ? (
                    <div className="text-white font-bold text-shadow">
                      Waiting for host to start the game
                    </div>
                  ) : (
                    <div className="transform transition-transform scale-75 w-full flex justify-center">
                      <DiceComponent
                        value={lastRoll}
                        isRolling={isRolling}
                        isPlayerTurn={isPlayerTurn}
                        gameState={gameState}
                        onRoll={handleRollDice}
                      />
                      {/* Debug info */}
                      {/* <div className="hidden">{`lastRoll: ${lastRoll}, isRolling: ${isRolling}`}</div> */}
                    </div>
                  )}
                </div>
              </div>
            </div>
            {/* Emoji message display */}{" "}
            <div
              className="fixed bottom-20 right-8 z-50"
              id="emoji-message-container"
            >
              {messages && messages.length > 0 && (
                <div
                  className="bg-container rounded-full p-3 shadow-lg flex items-center gap-2 animate-fadeInOut"
                  key={messages[messages.length - 1].id}
                >
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-primary-foreground font-bold text-shadow`}
                    style={{
                      background:
                        messages[messages.length - 1].playerColor === "red"
                          ? "var(--red-gradient)"
                          : messages[messages.length - 1].playerColor ===
                            "green"
                          ? "var(--green-gradient)"
                          : messages[messages.length - 1].playerColor === "blue"
                          ? "var(--blue-gradient)"
                          : "var(--yellow-gradient)",
                    }}
                  >
                    {messages[messages.length - 1].playerName?.charAt(0) || "?"}
                  </div>
                  <span className="text-2xl">
                    {messages[messages.length - 1].content}
                  </span>
                </div>
              )}
            </div>
          </div>
          {/* Add CSS for the fadeInOut animation */}
          <style jsx>{`
            @keyframes fadeInOut {
              0% {
                opacity: 0;
                transform: translateY(20px);
              }
              10% {
                opacity: 1;
                transform: translateY(0);
              }
              90% {
                opacity: 1;
                transform: translateY(0);
              }
              100% {
                opacity: 0;
                transform: translateY(20px);
              }
            }
            .animate-fadeInOut {
              animation: fadeInOut 2s forwards;
            }
          `}</style>
        </div>{" "}
        {isVictoryModalOpen && winner && (
          <VictoryModal
            isOpen={isVictoryModalOpen}
            onClose={() => setIsVictoryModalOpen(false)}
            winner={winner}
            winReason={winReason}
            onPlayAgain={() => {
              // Reset the game when Play Again is clicked
              resetGame(roomCode);
              setIsVictoryModalOpen(false);
            }}
          />
        )}
      </div>
    </div>
  );
}
