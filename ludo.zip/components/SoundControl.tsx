"use client";

import { useEffect, useState } from "react";
import { useSound } from "@/lib/sound/useSound";
import { Button } from "@/components/ui/button";
import { Volume2, VolumeX, Volume1 } from "lucide-react";
import { Slider } from "@/components/ui/slider";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

export function SoundControl() {
  const { enabled, toggle, volume, setVolume } = useSound();
  const [mounted, setMounted] = useState(false);

  // Wait for component to be mounted to avoid hydration mismatch
  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return null;
  }

  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0]);
  };

  // Choose icon based on volume level
  const VolumeIcon = () => {
    if (!enabled) return <VolumeX className="h-5 w-5" />;
    if (volume < 0.4) return <Volume1 className="h-5 w-5" />;
    return <Volume2 className="h-5 w-5" />;
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          size="icon"
          variant="ghost"
          className="h-9 w-9 rounded-full"
          aria-label="Sound settings"
        >
          <VolumeIcon />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-52" side="top">
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h4 className="font-medium">Sound</h4>
            <Button
              size="sm"
              variant={enabled ? "default" : "outline"}
              onClick={toggle}
            >
              {enabled ? "On" : "Off"}
            </Button>
          </div>
          <div className="space-y-2">
            <h4 className="font-medium">Volume</h4>
            <Slider
              disabled={!enabled}
              defaultValue={[volume]}
              max={1}
              step={0.01}
              onValueChange={handleVolumeChange}
            />
          </div>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Low</span>
            <span>High</span>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
