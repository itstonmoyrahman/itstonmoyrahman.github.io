import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useEffect, useState, memo } from "react";

interface TokenPinProps {
  color: "red" | "green" | "blue" | "yellow";
  isActive: boolean;
  isSelected: boolean;
  tokenRotation: number;
  isMoving?: boolean; // New prop to indicate token is currently moving
  isDisconnected?: boolean; // New prop to indicate if player is disconnected
  className?: string;
}

// Using memo to prevent unnecessary re-renders of tokens that haven't changed state
export const TokenPin = memo(function TokenPin({
  color,
  isActive,
  isSelected,
  tokenRotation,
  isMoving = false, // Default to false
  isDisconnected = false, // Default to false
  className,
}: TokenPinProps) {
  const [isRotating, setIsRotating] = useState(false);
  useEffect(() => {
    // Only rotate when token is active, regardless of selection state
    setIsRotating(isActive);

    // Add a small delay to start rotation for a smoother effect
    let timeoutId: NodeJS.Timeout;
    if (isActive) {
      timeoutId = setTimeout(() => {
        setIsRotating(true);
      }, 150);
    }

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [isActive]);

  const colorMap = {
    red: "#ef4444",
    green: "#43a047",
    blue: "#1e88e5",
    yellow: "#fdd835",
  };

  function shadeColor(color: string, percent: number) {
    const f = parseInt(color.slice(1), 16);
    const t = percent < 0 ? 0 : 255;
    const p = Math.abs(percent) / 100;
    const R = f >> 16;
    const G = (f >> 8) & 0x00ff;
    const B = f & 0x0000ff;
    return (
      "#" +
      (
        0x1000000 +
        (Math.round((t - R) * p) + R) * 0x10000 +
        (Math.round((t - G) * p) + G) * 0x100 +
        (Math.round((t - B) * p) + B)
      )
        .toString(16)
        .slice(1)
    );
  }
  return (
    <div
      className={cn(
        "relative flex items-center justify-center w-[24px] h-[24px] md:w-[42px] md:h-[42px]",
        className
      )}
      style={{
        // Apply rotation transform to the board based on current player's color
        transform: `rotate(${-tokenRotation}deg)`,
        transition: "transform 0.5s ease-in-out",
      }}
    >
      {/* Rotating base disc with improved visibility */}
      <motion.div
        className={cn(
          "absolute rounded-full z-0 border-2 w-5 h-5 md:w-6 md:h-6",
          isActive ? "border-dashed animate-pulse" : ""
        )}
        animate={{
          rotate: isRotating ? [0, 360] : 0, // Add rotation animation when active
          scale: isSelected ? [1, 1.1, 1] : 1, // Add pulsing when selected
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "linear",
          scale: {
            repeat: isSelected ? Infinity : 0,
            duration: 0.8,
            repeatType: "reverse",
          },
        }}
        style={{
          borderRadius: "50%",
          borderColor: isDisconnected
            ? "#9e9e9e" // Gray border for disconnected
            : isActive
            ? shadeColor(colorMap[color], -10) // Brighter border when active
            : shadeColor(colorMap[color], -40), // Darker when inactive
          backgroundColor: isDisconnected
            ? "#9e9e9e40" // Gray with opacity for disconnected
            : isActive
            ? `${colorMap[color]}40` // More opacity for active tokens
            : `${colorMap[color]}20`, // Less opacity when not active
          boxShadow:
            isActive && !isDisconnected
              ? "0 4px 8px -1px rgba(0, 0, 0, 0.2), 0 2px 6px -1px rgba(0, 0, 0, 0.1)"
              : "none",
          opacity: isDisconnected ? 0.6 : 1,
        }}
      />
      {/* Pin SVG with jumping animation when moving */}{" "}
      <motion.div
        className="absolute inset-0 flex items-center justify-center w-full h-full z-10 -top-1/4"
        animate={{
          y:
            isActive || isMoving
              ? ["0px", "-5px", "0px"] // Larger bounce for active/moving tokens
              : "0px", // No animation for inactive tokens
        }}
        transition={{
          duration: isMoving ? 0.3 : 1.2, // Faster for movement animation
          repeat: Infinity, // Always loop, but maybe conditionally
          repeatType: "reverse",
          ease: "easeInOut",
        }}
      >
        {/* Inline SVGs for each color with thicker white strokes */}
        {color === "red" && (
          <svg viewBox="0 0 64 64" className="w-[85%] h-[85%]">
            <g>
              <path
                fill="#ef4444"
                stroke="#ffffff"
                strokeWidth={3.5}
                d="M32,0C18.745,0,8,10.745,8,24c0,5.678,2.502,10.671,5.271,15l17.097,24.156C30.743,63.686,31.352,64,32,64 s1.257-0.314,1.632-0.844L50.729,39C53.375,35.438,56,29.678,56,24C56,10.745,45.255,0,32,0z M32,38c-7.732,0-14-6.268-14-14 s6.268-14,14-14s14,6.268,14,14S39.732,38,32,38z"
              />
              <path
                fill="#ef4444"
                stroke="#ffffff"
                strokeWidth={3.5}
                d="M32,12c-6.627,0-12,5.373-12,12s5.373,12,12,12s12-5.373,12-12S38.627,12,32,12z M32,34 c-5.523,0-10-4.478-10-10s4.477-10,10-10s10,4.478,10,10S37.523,34,32,34z"
              />
            </g>
          </svg>
        )}

        {color === "green" && (
          <svg viewBox="0 0 64 64" className="w-[85%] h-[85%]">
            <g>
              <path
                fill="#43a047"
                stroke="#ffffff"
                strokeWidth={3.5}
                d="M32,0C18.745,0,8,10.745,8,24c0,5.678,2.502,10.671,5.271,15l17.097,24.156C30.743,63.686,31.352,64,32,64 s1.257-0.314,1.632-0.844L50.729,39C53.375,35.438,56,29.678,56,24C56,10.745,45.255,0,32,0z M32,38c-7.732,0-14-6.268-14-14 s6.268-14,14-14s14,6.268,14,14S39.732,38,32,38z"
              />
              <path
                fill="#43a047"
                stroke="#ffffff"
                strokeWidth={3.5}
                d="M32,12c-6.627,0-12,5.373-12,12s5.373,12,12,12s12-5.373,12-12S38.627,12,32,12z M32,34 c-5.523,0-10-4.478-10-10s4.477-10,10-10s10,4.478,10,10S37.523,34,32,34z"
              />
            </g>
          </svg>
        )}

        {color === "blue" && (
          <svg viewBox="0 0 64 64" className="w-[85%] h-[85%]">
            <g>
              <path
                fill="#1e88e5"
                stroke="#ffffff"
                strokeWidth={1}
                d="M32,0C18.745,0,8,10.745,8,24c0,5.678,2.502,10.671,5.271,15l17.097,24.156C30.743,63.686,31.352,64,32,64 s1.257-0.314,1.632-0.844L50.729,39C53.375,35.438,56,29.678,56,24C56,10.745,45.255,0,32,0z M32,38c-7.732,0-14-6.268-14-14 s6.268-14,14-14s14,6.268,14,14S39.732,38,32,38z"
              />
              <path
                fill="#1e88e5"
                stroke="#ffffff"
                strokeWidth={1}
                d="M32,12c-6.627,0-12,5.373-12,12s5.373,12,12,12s12-5.373,12-12S38.627,12,32,12z M32,34 c-5.523,0-10-4.478-10-10s4.477-10,10-10s10,4.478,10,10S37.523,34,32,34z"
              />
            </g>
          </svg>
        )}

        {color === "yellow" && (
          <svg viewBox="0 0 64 64" className="w-[85%] h-[85%]">
            <g>
              <path
                fill="#fdd835"
                stroke="#ffffff"
                strokeWidth={1}
                d="M32,0C18.745,0,8,10.745,8,24c0,5.678,2.502,10.671,5.271,15l17.097,24.156C30.743,63.686,31.352,64,32,64 s1.257-0.314,1.632-0.844L50.729,39C53.375,35.438,56,29.678,56,24C56,10.745,45.255,0,32,0z M32,38c-7.732,0-14-6.268-14-14 s6.268-14,14-14s14,6.268,14,14S39.732,38,32,38z"
              />
              <path
                fill="#fdd835"
                stroke="#ffffff"
                strokeWidth={1}
                d="M32,12c-6.627,0-12,5.373-12,12s5.373,12,12,12s12-5.373,12-12S38.627,12,32,12z M32,34 c-5.523,0-10-4.478-10-10s4.477-10,10-10s10,4.478,10,10S37.523,34,32,34z"
              />
            </g>
          </svg>
        )}
      </motion.div>
    </div>
  );
});
