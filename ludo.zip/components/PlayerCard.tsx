// PlayerCard.tsx
import React from "react";
import clsx from "clsx";
import { CheckCircle, Clock, Crown, WifiOff } from "lucide-react";

type PlayerCardProps = {
  name: string;
  color: "red" | "green" | "yellow" | "blue";
  isCurrentTurn?: boolean;
  isHost?: boolean;
  isReady?: boolean;
  isDisconnected?: boolean;
  disconnectPending?: boolean; // New prop to show temporary disconnect
  isCurrentUser?: boolean; // New prop to identify if this is the current user
};

const PlayerCard: React.FC<PlayerCardProps> = ({
  name,
  color,
  isCurrentTurn = false,
  isHost = false,
  isReady = false,
  isDisconnected = false,
  disconnectPending = false,
  isCurrentUser = false, // Default to false
}) => {
  const colors: Record<PlayerCardProps["color"], string> = {
    red: "bg-gradient-to-br from-[#f85032] to-[#e73827] text-white",
    green: "bg-gradient-to-br from-[#56ab2f] to-[#a8e063] text-[#1b3d1b]",
    yellow: "bg-gradient-to-br from-[#fbd72b] to-[#f9484a] text-[#333]",
    blue: "bg-gradient-to-br from-[#4facfe] to-[#00f2fe] text-[#002f4b]",
  };
  return (
    <div
      className={clsx(
        "w-full flex items-center px-3 py-2 rounded-xl font-bold text-sm gap-2 shadow-white/20 shadow-md relative transition-all",
        colors[color],
        isCurrentTurn &&
          !isDisconnected &&
          "ring-2 ring-white/80 animate-pulse",
        isDisconnected && "opacity-60 grayscale",
        disconnectPending && "opacity-80", // Slightly dimmed for temp disconnect
        isCurrentUser && "ring-2 ring-white" // Add a ring for current user
      )}
    >
      <div className="relative">
        <div className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center font-bold shadow-md">
          {name.charAt(0).toUpperCase()}
        </div>
        {isHost && (
          <div className="absolute -top-1 -right-1 bg-amber-400 rounded-full p-0.5">
            <Crown className="w-3 h-3 text-white" />
          </div>
        )}{" "}
        {isDisconnected && (
          <div className="absolute -bottom-1 -right-1 bg-red-500 rounded-full p-0.5">
            <WifiOff className="w-3 h-3 text-white" />
          </div>
        )}
        {disconnectPending && !isDisconnected && (
          <div className="absolute -bottom-1 -right-1 bg-amber-500 rounded-full p-0.5 animate-pulse">
            <Clock className="w-3 h-3 text-white" />
          </div>
        )}
      </div>{" "}
      <div className="flex-1 ml-2 truncate overflow-hidden">
        <div className="truncate max-w-full">
          {name}
          {isCurrentUser && (
            <span className="ml-1 text-xs font-bold">(You)</span>
          )}
          {isDisconnected && (
            <span className="ml-1 text-xs">(Disconnected)</span>
          )}
          {disconnectPending && !isDisconnected && (
            <span className="ml-1 text-xs font-semibold animate-pulse">
              (Reconnecting...)
            </span>
          )}
        </div>
        {isReady && !isDisconnected && !disconnectPending && (
          <div className="text-xs flex items-center font-normal opacity-80">
            <CheckCircle className="w-3 h-3 mr-1" />
            Ready
          </div>
        )}
        {isDisconnected && (
          <div className="text-xs flex items-center font-normal opacity-80">
            <WifiOff className="w-3 h-3 mr-1" />
            Offline
          </div>
        )}
        {disconnectPending && !isDisconnected && (
          <div className="text-xs flex items-center font-normal opacity-90">
            <Clock className="w-3 h-3 mr-1 animate-pulse" />
            <span className="animate-pulse">2 min to rejoin</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default PlayerCard;
