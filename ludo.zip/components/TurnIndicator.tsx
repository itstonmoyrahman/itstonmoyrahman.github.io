"use client";

import { AlertCircle, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface TurnIndicatorProps {
  isPlayerTurn: boolean;
  playerName: string;
  gameState: string;
}

export default function TurnIndicator({
  isPlayerTurn,
  playerName,
  gameState,
}: TurnIndicatorProps) {
  if (gameState !== "playing") return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={cn(
        "flex items-center gap-2 p-3 rounded-lg shadow-lg border border-white/20 bg-container",
        isPlayerTurn ? "ring-2 ring-white/30 animate-pulse" : ""
      )}
    >
      {" "}
      <div
        className={cn(
          "w-10 h-10 rounded-full flex items-center justify-center shadow-inner",
          isPlayerTurn
            ? "bg-gradient-to-br from-indigo-500/70 to-purple-600/70"
            : "bg-white/10"
        )}
      >
        {isPlayerTurn ? (
          <motion.div
            animate={{
              scale: [1, 1.2, 1],
              rotate: [0, 0, 0, 0, 0, 0, 10, -10, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              repeatDelay: 0.5,
            }}
            className="w-6 h-6 text-white"
          >
            <AlertCircle className="w-full h-full" />
          </motion.div>
        ) : (
          <motion.div
            animate={{ rotate: 360 }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "linear",
            }}
            className="w-6 h-6 text-white/70"
          >
            <Clock className="w-full h-full" />
          </motion.div>
        )}
      </div>
      <div className="flex-1">
        <div
          className={cn(
            "text-sm font-bold mb-0.5 uppercase",
            isPlayerTurn ? "text-white text-shadow" : "text-white/70"
          )}
        >
          {isPlayerTurn ? "YOUR TURN" : "WAITING"}
        </div>
        <div
          className={cn(
            "text-base font-bold",
            isPlayerTurn ? "text-white" : "text-white/80"
          )}
        >
          {isPlayerTurn ? "Make your move!" : `${playerName}'s turn`}
        </div>
      </div>
      {isPlayerTurn && (
        <motion.div
          className="w-2 h-2 rounded-full bg-blue-500 mr-1"
          animate={{ scale: [1, 1.5, 1] }}
          transition={{
            duration: 1,
            repeat: Infinity,
          }}
        />
      )}
    </motion.div>
  );
}
