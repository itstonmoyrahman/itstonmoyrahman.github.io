"use client";

import { Player } from "@/lib/game/types";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Trophy, Award, Users } from "lucide-react";
import confetti from "canvas-confetti";
import { useEffect } from "react";

interface VictoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  winner: Player;
  winReason?: string;
  onPlayAgain: () => void;
}

export function VictoryModal({
  isOpen,
  onClose,
  winner,
  winReason,
  onPlayAgain,
}: VictoryModalProps) {
  useEffect(() => {
    if (isOpen) {
      // Show victory confetti
      const end = Date.now() + 3 * 1000; // 3 seconds of confetti

      // Launch initial burst
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
      });

      // Create confetti interval with explicit type
      const interval: NodeJS.Timeout = setInterval(() => {
        if (Date.now() > end) {
          clearInterval(interval);
          return;
        }

        confetti({
          particleCount: 50,
          angle: Math.random() * 60 + 60, // random angle between 60 and 120
          spread: 70,
          origin: { x: Math.random(), y: Math.random() * 0.4 + 0.3 },
          colors: ["#FFD700", "#FFA500", "#ff5500", winner.color],
        });
      }, 250);

      // Cleanup function to clear interval when component unmounts or modal closes
      return () => clearInterval(interval);
    }
  }, [isOpen, winner.color]);

  // Get player color based class
  const getColorClass = () => {
    switch (winner.color) {
      case "red":
        return "from-red-500 to-red-600";
      case "green":
        return "from-green-500 to-green-600";
      case "blue":
        return "from-blue-500 to-blue-600";
      case "yellow":
        return "from-yellow-500 to-yellow-600";
      default:
        return "from-purple-500 to-purple-600";
    }
  };

  // Get win message based on reason
  const getWinMessage = () => {
    if (winReason === "last-player-remaining") {
      return "All other players left the game!";
    } else {
      return "All tokens have reached home!";
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900/90 backdrop-blur-md border-white/20 text-white max-w-md p-0 overflow-hidden">
        {/* Header with confetti background */}
        <motion.div
          className="bg-gradient-to-br from-indigo-900/80 to-purple-900/80 p-6 text-center relative overflow-hidden"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,215,0,0.2),transparent_70%)]" />

          <motion.div
            initial={{ scale: 0.5, opacity: 0, rotate: -10 }}
            animate={{ scale: 1, opacity: 1, rotate: 0 }}
            transition={{ delay: 0.2, duration: 0.5, type: "spring" }}
            className="flex justify-center mb-2"
          >
            <Trophy className="w-16 h-16 text-yellow-400 drop-shadow-[0_0_8px_rgba(234,179,8,0.8)]" />
          </motion.div>

          <motion.h2
            className="text-2xl font-bold mb-1"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.4 }}
          >
            Victory!
          </motion.h2>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className="text-sm text-white/80"
          >
            {getWinMessage()}
          </motion.div>
        </motion.div>

        {/* Winner info */}
        <div className="p-6">
          <motion.div
            className="flex items-center gap-4 mb-6"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4, duration: 0.4 }}
          >
            <div
              className={`w-16 h-16 rounded-full flex items-center justify-center bg-gradient-to-br ${getColorClass()} shadow-lg`}
            >
              <Award className="w-10 h-10 text-white" />
            </div>

            <div>
              <div className="text-white/60 text-sm">Winner</div>
              <div className="text-xl font-bold">{winner.name}</div>
              <div className="text-sm capitalize text-white/80">
                {winner.color} player
              </div>
            </div>
          </motion.div>

          {/* Play again button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.4 }}
            className="flex justify-center"
          >
            <Button
              onClick={onPlayAgain}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-8 py-5 rounded-full font-bold shadow-lg transition-all"
            >
              Play Again
            </Button>
          </motion.div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
