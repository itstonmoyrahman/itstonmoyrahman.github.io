"use client";

import { useState, useEffect, useRef } from "react";
import { Player, GameState } from "@/lib/game/types";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { redPath, greenPath, bluePath, yellowPath } from "@/lib/game/paths";
import { TokenPin } from "./TokenPin";
import soundManager from "@/lib/sound/soundManager";

// Define the board layout constants
const boardSize = 15;

// Define home positions for each color
const homePositions = {
  red: [
    { row: 1, col: 1 },
    { row: 1, col: 3 },
    { row: 3, col: 1 },
    { row: 3, col: 3 },
  ],
  green: [
    { row: 1, col: 11 },
    { row: 1, col: 13 },
    { row: 3, col: 11 },
    { row: 3, col: 13 },
  ],
  blue: [
    { row: 11, col: 1 },
    { row: 11, col: 3 },
    { row: 13, col: 1 },
    { row: 13, col: 3 },
  ],
  yellow: [
    { row: 11, col: 11 },
    { row: 11, col: 13 },
    { row: 13, col: 11 },
    { row: 13, col: 13 },
  ],
};

// Define path for each color
const getPath = (color: "red" | "green" | "blue" | "yellow") => {
  // Return the complete pre-defined 57-step path for each color
  switch (color) {
    case "red":
      return redPath;
    case "green":
      return greenPath;
    case "blue":
      return bluePath;
    case "yellow":
      return yellowPath;
  }
};

interface LudoBoardProps {
  players: Player[];
  currentPlayerColor?: string;
  selectedTokenId: number | null;
  isPlayerTurn: boolean;
  gameState: GameState;
  onTokenClick: (tokenId: number) => void;
  lastRoll: number; // Add dice roll value to determine valid moves
  hasDiceBeenRolled: boolean; // Add flag to track if dice has been rolled
}

export default function LudoBoard({
  players,
  currentPlayerColor,
  selectedTokenId,
  isPlayerTurn,
  onTokenClick,
  lastRoll,
  hasDiceBeenRolled,
}: LudoBoardProps) {
  const [boardLayout, setBoardLayout] = useState<JSX.Element[][]>([]);

  // Each player should see their color at bottom left
  const getBoardRotation = (): number => {
    if (!currentPlayerColor) return 0;

    switch (currentPlayerColor) {
      case "blue":
        return 0; // Blue is already at bottom left in default orientation
      case "yellow":
        return 90; // Rotate 90° clockwise to put yellow at bottom left
      case "green":
        return 180; // Rotate 180° to put red at bottom left
      case "red":
        return 270; // Rotate 270° clockwise to put green at bottom left
      default:
        return 0;
    }
  };

  const boardRotation = getBoardRotation();

  const [movingTokens, setMovingTokens] = useState<
    { playerId: string; tokenId: number; steps: number }[]
  >([]);

  // Reference to the board container
  const boardRef = useRef<HTMLDivElement>(null);

  // Add event listener for opponent token animations
  useEffect(() => {
    const handleTokenAnimation = (event: any) => {
      const { playerId, tokenId, fromSteps, toSteps } = event.detail;
      animateTokenMovement(playerId, tokenId, fromSteps, toSteps);
    };

    const boardElement = boardRef.current;
    if (boardElement) {
      boardElement.addEventListener(
        "animate-token-movement",
        handleTokenAnimation
      );
    }

    return () => {
      if (boardElement) {
        boardElement.removeEventListener(
          "animate-token-movement",
          handleTokenAnimation
        );
      }
    };
  }, []);

  // Modify the animateTokenMovement function to add a gap between steps
  const animateTokenMovement = (
    playerId: string,
    tokenId: number,
    fromSteps: number,
    toSteps: number
  ) => {
    console.log(
      `Animating token movement for ${playerId}, token ${tokenId} from ${fromSteps} to ${toSteps}`
    );
    // Clear any existing animation for this token
    setMovingTokens((prev) =>
      prev.filter((t) => !(t.playerId === playerId && t.tokenId === tokenId))
    );

    // Calculate number of steps to animate
    const stepCount = toSteps - fromSteps;

    // Don't animate if no steps or negative steps
    if (stepCount <= 0) return;

    // Mark this token as moving starting at fromSteps
    setMovingTokens((prev) => [
      ...prev,
      { playerId, tokenId, steps: fromSteps },
    ]);

    let currentStep = fromSteps;
    let stepDelay = 400; // 400ms for each step
    let pauseDelay = 50; // 100ms pause between steps

    const processNextStep = () => {
      currentStep++;

      // Play a jump sound for each step
      soundManager?.play("move", 0.3);

      // Update position
      setMovingTokens((prev) => {
        const otherTokens = prev.filter(
          (t) => !(t.playerId === playerId && t.tokenId === tokenId)
        );
        return [...otherTokens, { playerId, tokenId, steps: currentStep }];
      });

      if (currentStep >= toSteps) {
        // We've reached the destination
        // Keep the token in the moving state briefly to show the final position
        setTimeout(() => {
          setMovingTokens((prev) =>
            prev.filter(
              (t) => !(t.playerId === playerId && t.tokenId === tokenId)
            )
          );
        }, 300);
        return;
      }

      // Schedule the next step with a pause in between
      setTimeout(processNextStep, stepDelay + pauseDelay);
    };

    // Start the first step after a small initial delay
    setTimeout(processNextStep, 50);
  };
  // Function to handle token click with animation
  const handleTokenClick = (tokenId: number) => {
    if (!isPlayerTurn || !currentPlayerColor || !hasDiceBeenRolled) return;

    const player = players.find((p) => p.color === currentPlayerColor);
    if (!player) return;

    const token = player.tokens.find((t) => t.id === tokenId);
    if (!token) return;

    // Log the token click for debugging
    console.log(
      `Token clicked: ${currentPlayerColor} token ${tokenId}, position: ${token.position}, board rotation: ${boardRotation}°`
    );

    // For tokens at home, they'll move to start position
    if (token.position === "home" && lastRoll === 6) {
      // No need to animate home to start - it's instant
      onTokenClick(tokenId);
      return;
    }

    // For tokens on board, animate their movement
    if (token.position === "board" && typeof token.steps === "number") {
      const newSteps = token.steps + lastRoll;

      // Check if the move is valid
      if (
        canMoveToken(
          token,
          lastRoll,
          player.color as "red" | "green" | "blue" | "yellow"
        )
      ) {
        // Start animation
        animateTokenMovement(player.id, tokenId, token.steps, newSteps);

        // Call the actual move handler after a small delay
        setTimeout(() => {
          onTokenClick(tokenId);
        }, 200);
      }
    }
  };

  // Generate the board layout
  useEffect(() => {
    const board: JSX.Element[][] = [];

    // Create empty board
    for (let row = 0; row < boardSize; row++) {
      board[row] = [];
      for (let col = 0; col < boardSize; col++) {
        // Determine cell type and color - very minimal styling to let the background image show through
        let cellClassName = "border border-border/10"; // Super transparent borders

        // Center cell
        if (row === 7 && col === 7) {
          cellClassName += " border-2 border-black/10"; // Slightly visible center
        }

        board[row][col] = (
          <div
            key={`${row}-${col}`}
            className={cn(
              "w-[24px] h-[24px] md:w-[42px] md:h-[42px]",
              cellClassName
            )}
          />
        );
      }
    }

    setBoardLayout(board);
  }, []);

  return (
    <div className="relative w-full h-full bg-white/10 backdrop-blur-sm rounded-lg overflow-hidden shadow-lg border border-white/10">
      <div
        ref={boardRef}
        data-ludo-board="true"
        className="relative grid w-[360px] h-[360px] md:w-[400px] md:h-[400px] mx-auto"
        style={{
          gridTemplateColumns: `repeat(${boardSize}, 1fr)`,
          gridTemplateRows: `repeat(${boardSize}, 1fr)`,
          backgroundImage: "url(/board.png)",
          backgroundSize: "contain",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          // Apply rotation transform to the board based on current player's color
          transform: `rotate(${boardRotation}deg)`,
          transition: "transform 0.5s ease-in-out",
        }}
      >
        {/* Render player tokens */}
        {players.map((player) => {
          // Skip player if color is undefined
          if (!player.color) return null;

          return player.tokens?.map((token) => {
            // Skip if token is undefined
            if (!token) return null;

            // Determine token position
            let position;

            // Check if this token is currently being animated
            const movingToken = movingTokens.find(
              (t) => t.playerId === player.id && t.tokenId === token.id
            );

            if (movingToken && token.position === "board") {
              // If token is moving, use the animation step position
              const path = getPath(
                player.color as "red" | "green" | "blue" | "yellow"
              );
              if (path && movingToken.steps < path.length) {
                position = path[movingToken.steps];
              }
            } else if (token.position === "home") {
              // Get home position based on color and token id
              position =
                homePositions[player.color as keyof typeof homePositions][
                  token.id
                ];
            } else if (token.position === "board") {
              // If the token is on the board, use its steps to determine position
              const path = getPath(
                player.color as "red" | "green" | "blue" | "yellow"
              );
              if (path && token.steps !== undefined && path[token.steps]) {
                position = path[token.steps];
              }
            } else if (token.position === "finished") {
              // Token has reached finish - use the predefined finish positions based on color
              const finishRow = 7;
              const finishCol =
                player.color === "red"
                  ? 2 + token.id
                  : player.color === "green"
                  ? 6 + token.id
                  : player.color === "blue"
                  ? 2 + token.id
                  : 6 + token.id; // Yellow
              position = { row: finishRow, col: finishCol };
            }

            // Skip rendering if position is unknown
            if (!position) return null;

            const isSelected = selectedTokenId === token.id;
            const isCurrentPlayerToken = player.color === currentPlayerColor;
            const isValidMove =
              isPlayerTurn &&
              isCurrentPlayerToken &&
              hasDiceBeenRolled &&
              !player.isDisconnected &&
              canMoveToken(
                token,
                lastRoll,
                player.color as "red" | "green" | "blue" | "yellow"
              );

            // Check if token is currently moving
            const isMoving = !!movingToken;

            return (
              <motion.div
                key={`token-${player.color}-${token.id}`}
                initial={{ scale: 0.8 }}
                animate={{
                  scale: 1,
                  left: `${(position.col / boardSize) * 100}%`,
                  top: `${(position.row / boardSize) * 100}%`,
                }}
                transition={{
                  type: "tween", // Change from "spring" to "tween"
                  duration: 0.2, // Duration for scale animation
                  ease: "easeOut", // Easing function for smoother movement
                  // Position animations with precise timing
                  left: {
                    type: "tween",
                    duration: 0.3,
                    ease: "linear",
                  },
                  top: {
                    type: "tween",
                    duration: 0.3,
                    ease: "linear",
                  },
                }}
                style={{
                  position: "absolute",
                  width: `${100 / boardSize}%`,
                  height: `${100 / boardSize}%`,
                  zIndex: isSelected ? 30 : 20,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  transformOrigin: "center center",
                }}
                className="transform-gpu"
                onClick={() => handleTokenClick(token.id)}
              >
                <TokenPin
                  color={player.color as "red" | "green" | "blue" | "yellow"}
                  tokenRotation={boardRotation}
                  isSelected={isSelected}
                  isActive={isValidMove}
                  isMoving={isMoving}
                  isDisconnected={player.isDisconnected}
                />
              </motion.div>
            );
          });
        })}
      </div>
    </div>
  );
}

// Helper function to determine if a token can be moved with the current roll
function canMoveToken(
  token: { position: string; steps?: number; id: number },
  roll: number,
  color: "red" | "green" | "blue" | "yellow"
) {
  // Can't move if no roll
  if (roll === 0) return false;

  // If token is at home, need a 6 to move out
  if (token.position === "home") {
    return roll === 6;
  }

  // Can't move tokens that are already finished
  if (token.position === "finished") {
    return false;
  }

  // For tokens on the board, check if the move would be valid
  if (token.position === "board" && token.steps !== undefined) {
    // Check if rolling would move the token past the finish line
    const path = getPath(color);
    return token.steps + roll < path.length;
  }

  return false;
}
