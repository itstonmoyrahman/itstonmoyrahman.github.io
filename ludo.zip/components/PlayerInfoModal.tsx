import { Player, GameState } from "@/lib/game/types";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { CheckCircle, Circle, Crown, Users, WifiOff, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

interface PlayerInfoModalProps {
  players: Player[];
  currentTurn: number;
  playerId: string;
  gameState: GameState;
  onToggleReady?: () => void;
  onStartGame?: () => void;
  onSetPlayerCount?: (count: number) => void;
  roomCode: string;
  maxPlayers?: number;
}

export default function PlayerInfoModal({
  players,
  currentTurn,
  playerId,
  gameState,
  onToggleReady,
  onStartGame,
  onSetPlayerCount,
  roomCode,
  maxPlayers = 4,
}: PlayerInfoModalProps) {
  // Get the current player's color
  const currentPlayerColor =
    players.find((p) => p.id === playerId)?.color || "";

  // Only show the modal when game state is waiting
  if (gameState !== "waiting") {
    return null;
  }

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        />

        {/* Modal content */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          transition={{ type: "spring", damping: 15 }}
          className="relative bg-gray-900/80 backdrop-blur-md rounded-2xl overflow-hidden shadow-2xl max-w-md w-full border border-white/20"
        >
          {/* Header */}
          <div className="bg-black/40 backdrop-blur-sm px-4 py-4 flex items-center justify-between border-b border-white/10">
            <div className="flex items-center gap-2 text-white">
              <Users className="w-5 h-5" />
              <h3 className="font-bold text-xl text-shadow">Ludo Game Lobby</h3>
            </div>{" "}
            <div className="flex items-center gap-3">
              {" "}
              <div className="bg-white/20 text-white text-sm font-medium px-2.5 py-1.5 rounded-full border border-white/20 shadow-inner">
                {players.length}/{maxPlayers}
              </div>
              <motion.button
                className="bg-indigo-600/60 text-white text-sm font-bold px-2.5 py-1.5 rounded-full border border-indigo-500/30 shadow-inner flex items-center hover:bg-indigo-500/60 active:scale-95 transition-all cursor-pointer relative group"
                onClick={() => {
                  navigator.clipboard
                    .writeText(roomCode)
                    .then(() => {
                      toast("Room code copied to clipboard!");
                    })
                    .catch((err) => {
                      console.error("Failed to copy: ", err);
                    });
                }}
                whileTap={{ scale: 0.95 }}
                title="Click to copy room code"
              >
                <span className="mr-1">Room:</span>
                <span className="font-mono flex items-center">
                  {roomCode}
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-3 w-3 ml-1 opacity-70 group-hover:opacity-100"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2"
                    />
                  </svg>
                </span>
              </motion.button>
            </div>
          </div>

          {/* Players list */}
          <div className="p-4 space-y-3 bg-gradient-to-b from-white/10 to-white/5">
            <h4 className="text-white font-semibold mb-2 text-lg">Players</h4>
            {players && players.length > 0 ? (
              <>
                {players.map((player, index) => {
                  if (!player) return null;

                  const isCurrentPlayer = player.id === playerId;

                  // Count tokens
                  const tokens = player.tokens || [];
                  const tokenCounts = {
                    home: tokens.filter((t) => t && t.position === "home")
                      .length,
                    board: tokens.filter((t) => t && t.position === "board")
                      .length,
                    finished: tokens.filter(
                      (t) => t && t.position === "finished"
                    ).length,
                  };
                  return (
                    <motion.div
                      key={player.id}
                      className={cn(
                        "flex items-center p-3 rounded-xl shadow-md border transition-all relative bg-container",
                        isCurrentPlayer ? "border-white/50" : "border-white/10",
                        isCurrentPlayer && "ring-2 ring-offset-1 ring-blue-400",
                        player.isDisconnected && "opacity-60 grayscale"
                      )}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                      {/* Player Avatar with Color */}
                      <div
                        className="h-10 w-10 rounded-full flex items-center justify-center text-white font-bold shadow-lg mr-3 text-shadow"
                        style={{
                          background:
                            player.color === "red"
                              ? "var(--red-gradient)"
                              : player.color === "green"
                              ? "var(--green-gradient)"
                              : player.color === "blue"
                              ? "var(--blue-gradient)"
                              : "var(--yellow-gradient)",
                          border: "2px solid rgba(255, 255, 255, 0.3)",
                        }}
                      >
                        {player.name?.[0]?.toUpperCase() || "?"}
                        {player.isHost && (
                          <div className="absolute -top-1 -right-1 bg-amber-400 rounded-full p-0.5 shadow-md">
                            <Crown className="w-3 h-3 text-white" />
                          </div>
                        )}
                        {player.isDisconnected && (
                          <div className="absolute -bottom-1 -right-1 bg-red-500 rounded-full p-0.5 shadow-md">
                            <WifiOff className="w-3 h-3 text-white" />
                          </div>
                        )}
                      </div>

                      {/* Player info */}
                      <div className="flex-grow">
                        <div className="flex items-center justify-between">
                          <div className="font-bold text-white text-shadow">
                            {player.name}
                            {isCurrentPlayer && (
                              <span className="ml-4 text-xs font-semibold bg-blue-500/30 text-white px-1.5 py-0.5 rounded-full border border-blue-400/30">
                                You
                              </span>
                            )}
                            {player.isDisconnected && (
                              <span className="ml-2 text-xs font-semibold bg-red-500/30 text-white px-1.5 py-0.5 rounded-full border border-red-400/30">
                                Disconnected
                              </span>
                            )}
                          </div>
                          <span
                            className={cn(
                              "ml-2 text-xs px-1.5 py-0.5 rounded-full flex items-center font-medium border",
                              player.isDisconnected
                                ? "bg-red-500/30 text-white border-red-400/30"
                                : player.isReady
                                ? "bg-green-500/30 text-white border-green-400/30"
                                : "bg-amber-500/30 text-white border-amber-400/30"
                            )}
                          >
                            {player.isDisconnected ? (
                              <WifiOff className="inline h-3 w-3 mr-1" />
                            ) : player.isReady ? (
                              <CheckCircle className="inline h-3 w-3 mr-1" />
                            ) : (
                              <Circle className="inline h-3 w-3 mr-1" />
                            )}
                            {player.isDisconnected
                              ? "Offline"
                              : player.isReady
                              ? "Ready"
                              : "Waiting"}
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </>
            ) : (
              <div className="text-center text-sm text-white py-6 italic bg-white/10 rounded-xl shadow-inner border border-white/10 backdrop-blur-sm">
                <div className="animate-pulse mb-2">👋</div>
                Waiting for players to join...
              </div>
            )}{" "}
            {players && players.length > 0 && players.length < maxPlayers && (
              <div className="text-center text-sm text-white py-3 bg-white/10 rounded-lg mt-3 backdrop-blur-sm border border-white/10 font-medium">
                <span className="text-amber-300">👑</span> Invite more players
                with room code!
              </div>
            )}
            {/* Player count selector (host only) */}
            {playerId &&
              players.find((p) => p.id === playerId)?.isHost &&
              onSetPlayerCount && (
                <div className="mt-3 bg-white/10 rounded-lg p-3 border border-white/10">
                  <div className="text-white font-medium text-sm mb-2">
                    Game settings:
                  </div>
                  <div className="flex flex-col space-y-2">
                    <div className="text-xs text-white/80 mb-1">
                      Number of players:
                    </div>
                    <div className="flex justify-between gap-2">
                      {" "}
                      <Button
                        onClick={() => onSetPlayerCount(2)}
                        disabled={players.length > 2}
                        title={
                          players.length > 2
                            ? "Cannot set to 2 players when there are already more than 2 players in the room"
                            : "Set game to 2 players"
                        }
                        className={cn(
                          "flex-1 text-white py-1 h-auto rounded-md font-medium",
                          maxPlayers === 2
                            ? "bg-indigo-500 hover:bg-indigo-600"
                            : "bg-gray-600/50 hover:bg-gray-500/50",
                          players.length > 2 && "opacity-50 cursor-not-allowed"
                        )}
                      >
                        2 Players
                        {maxPlayers === 2 && (
                          <span className="ml-1 text-xs">(Red vs Yellow)</span>
                        )}
                        {players.length > 2 && (
                          <span className="ml-1 text-xs text-red-300">
                            (Too many players)
                          </span>
                        )}
                      </Button>{" "}
                      <Button
                        onClick={() => onSetPlayerCount(4)}
                        title="Set game to 4 players"
                        className={cn(
                          "flex-1 text-white py-1 h-auto rounded-md font-medium",
                          maxPlayers === 4
                            ? "bg-indigo-500 hover:bg-indigo-600"
                            : "bg-gray-600/50 hover:bg-gray-500/50"
                        )}
                      >
                        4 Players
                        {maxPlayers === 4 && (
                          <span className="ml-1 text-xs">(All colors)</span>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              )}
          </div>

          {/* Game controls - Ready button & Start game */}
          <div className="p-4 space-y-4 pt-4 border-t border-white/20 bg-gradient-to-b from-gray-900/50 to-black/50">
            {/* Ready button for current player */}
            {playerId &&
              onToggleReady &&
              !players.find((p) => p.id === playerId)?.isDisconnected && (
                <Button
                  onClick={onToggleReady}
                  variant="default"
                  className={cn(
                    "w-full rounded-full py-5 font-bold shadow-lg transition-all text-white text-lg",
                    players.find((p) => p.id === playerId)?.isReady
                      ? "bg-white/20 border border-white/30"
                      : "border border-white/10"
                  )}
                  style={{
                    background: players.find((p) => p.id === playerId)?.isReady
                      ? "rgba(255, 255, 255, 0.15)"
                      : currentPlayerColor === "red"
                      ? "var(--red-gradient)"
                      : currentPlayerColor === "green"
                      ? "var(--green-gradient)"
                      : currentPlayerColor === "blue"
                      ? "var(--blue-gradient)"
                      : "var(--yellow-gradient)",
                  }}
                >
                  {players.find((p) => p.id === playerId)?.isReady
                    ? "Cancel Ready"
                    : "I'm Ready!"}
                </Button>
              )}

            {/* Start game button for host */}
            {playerId &&
              players.find((p) => p.id === playerId)?.isHost &&
              players.filter((p) => !p.isDisconnected).length >= 2 &&
              onStartGame && (
                <Button
                  onClick={onStartGame}
                  className={cn(
                    "w-full rounded-full py-5 font-bold shadow-lg text-white text-lg border",
                    players
                      .filter((p) => !p.isDisconnected)
                      .every((p) => p.isReady)
                      ? "animate-pulse border-indigo-400/30"
                      : "opacity-50 border-white/10"
                  )}
                  style={{
                    background: players
                      .filter((p) => !p.isDisconnected)
                      .every((p) => p.isReady)
                      ? "linear-gradient(to right, #4F46E5, #8B5CF6)"
                      : "rgba(255, 255, 255, 0.1)",
                  }}
                  disabled={
                    !players
                      .filter((p) => !p.isDisconnected)
                      .every((p) => p.isReady)
                  }
                >
                  {players
                    .filter((p) => !p.isDisconnected)
                    .every((p) => p.isReady)
                    ? "Start Game!"
                    : "Waiting for players..."}
                </Button>
              )}

            {/* Message for host */}
            {playerId &&
              players.find((p) => p.id === playerId)?.isHost &&
              (players.filter((p) => !p.isDisconnected).length < 2 ? (
                <div className="text-center text-xs bg-amber-500/20 text-white rounded-lg py-2 border border-amber-400/20">
                  <span className="font-bold">👋</span> Need at least 2 active
                  players to start the game
                </div>
              ) : (
                !players
                  .filter((p) => !p.isDisconnected)
                  .every((p) => p.isReady) && (
                  <div className="text-center text-xs bg-indigo-500/20 text-white rounded-lg py-2 border border-indigo-400/20">
                    <span className="font-bold">⏳</span> All active players
                    must be ready to start
                  </div>
                )
              ))}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
