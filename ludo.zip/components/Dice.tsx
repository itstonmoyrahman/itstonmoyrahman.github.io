"use client";

import { useState, useEffect, useRef } from "react";
import { cn } from "@/lib/utils";
import { GameState } from "@/lib/game/types";
import { motion } from "framer-motion";
import Dice from "react-dice-roll";
import type { ComponentRef } from "react";

interface DiceProps {
  value: number; // Value from server
  isRolling: boolean; // True while any player is rolling
  isPlayerTurn: boolean;
  gameState: GameState;
  onRoll: () => void; // Triggered on dice click
}

// Type-safe ref
type DiceRefType = ComponentRef<typeof Dice>;

export default function DiceComponent({
  value,
  isRolling,
  isPlayerTurn,
  gameState,
  onRoll,
}: DiceProps) {
  const diceRef = useRef<DiceRefType>(null);
  const [justRolled, setJustRolled] = useState(false);
  const [finalValue, setFinalValue] = useState(1);
  const previousValueRef = useRef<number>(1);
  const [showAnimation, setShowAnimation] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastRollTimestampRef = useRef<number>(0);

  // Synchronize dice value with server value once rolling is complete
  useEffect(() => {
    // Update final value when dice value changes and is valid
    if (value >= 1 && value <= 6) {
      // Store previous value for comparison
      previousValueRef.current = finalValue;

      // Get current timestamp to track roll sequence
      const now = Date.now();

      // Only process updates that are not too close to each other (prevents multiple events conflict)
      if (now - lastRollTimestampRef.current > 500 || !isRolling) {
        lastRollTimestampRef.current = now;

        // Check if during animation, only update if value changed significantly
        if (isRolling || showAnimation) {
          console.log(
            `During animation, checking value update: ${finalValue} → ${value}`
          );
          // During animation, only update for significant changes
          if (Math.abs(finalValue - value) >= 1) {
            console.log(
              `Significant value change during animation: ${finalValue} → ${value}`
            );
            setFinalValue(value);
          }
        } else {
          // Always update to match server value when not in animation
          console.log(`Updating dice value: ${finalValue} → ${value}`);
          setFinalValue(value);
        }
      } else {
        console.log(
          `Ignoring rapid dice update (${
            Date.now() - lastRollTimestampRef.current
          }ms): ${value}`
        );
      }

      // Debug log to help track inconsistencies
      if (finalValue !== value && !isRolling && !showAnimation) {
        console.warn(
          "Dice display mismatch detected. Forcing update to server value:",
          value
        );
      }
    }
  }, [value, isRolling, showAnimation, finalValue]);

  // Handle animation state when rolling starts/stops
  useEffect(() => {
    if (isRolling) {
      // Start animation when rolling starts
      setShowAnimation(true);
      console.log("Starting dice roll animation");

      // Clear any previous timeout
      if (timeoutRef.current) clearTimeout(timeoutRef.current);

      // Set a timeout to match the animation duration
      timeoutRef.current = setTimeout(() => {
        console.log(`Animation complete, showing value: ${value}`);

        // Stop animation and show the final value
        setShowAnimation(false);

        // Force update to the server value after animation completes
        if (value >= 1 && value <= 6) {
          setFinalValue(value);
          console.log(`Animation ended, finalValue set to: ${value}`);

          // Highlight the roll result
          setJustRolled(true);
          setTimeout(() => setJustRolled(false), 1000);
        } else {
          console.warn("Invalid dice value after animation:", value);
        }
      }, 1000); // Match with rollingTime in Dice props
    } else if (!isRolling && value > 0) {
      // When not rolling but has a valid value, ensure it's synchronized
      if (finalValue !== value) {
        console.log("Synchronizing dice value while not rolling:", value);
        setFinalValue(value);
      }
    }

    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [isRolling, value]);

  // Trigger manual animation when needed
  useEffect(() => {
    if (showAnimation && diceRef.current?.rollDice) {
      try {
        // Always use the value passed from the parent component
        // This will be either a locally generated value or a server value
        const diceValue =
          value >= 1 && value <= 6
            ? (value as 1 | 2 | 3 | 4 | 5 | 6)
            : ((Math.floor(Math.random() * 6) + 1) as 1 | 2 | 3 | 4 | 5 | 6);

        diceRef.current.rollDice(diceValue);
        console.log("Dice animation triggered with value:", diceValue);

        // Ensure finalValue is updated to match what's being displayed
        setFinalValue(diceValue);
      } catch (error) {
        console.error("Error triggering dice animation:", error);
      }
    }
  }, [showAnimation, value]);

  return (
    <div className="flex flex-col items-center">
      {/* Enhanced debug info */}

      <motion.div
        className="relative"
        animate={
          justRolled
            ? {
                scale: [1, 1.15, 1],
                y: [0, -5, 0],
              }
            : {}
        }
        transition={{ duration: 0.5 }}
      >
        {/* Dice glow effect */}
        <div
          className={cn(
            "absolute inset-0 rounded-2xl blur-md -z-10 transition-opacity",
            justRolled ? "opacity-100 bg-white/70" : "opacity-0",
            isPlayerTurn && gameState === "playing" && !isRolling && !value
              ? "bg-white/50 opacity-70 animate-pulse"
              : "opacity-0"
          )}
        ></div>

        {/* Dice clickable area */}
        <div
          className={cn(
            "transition-all",
            isPlayerTurn && gameState === "playing" && !isRolling && !value
              ? "cursor-pointer hover:scale-105"
              : "",
            !isPlayerTurn || gameState !== "playing" ? "opacity-30" : ""
          )}
          onClick={() => {
            if (
              isPlayerTurn &&
              gameState === "playing" &&
              !isRolling &&
              !value
            ) {
              onRoll(); // Ask server to roll
            }
          }}
        >
          <Dice
            ref={diceRef}
            size={100}
            faces={[
              "/dice/face-1.svg",
              "/dice/face-2.svg",
              "/dice/face-3.svg",
              "/dice/face-4.svg",
              "/dice/face-5.svg",
              "/dice/face-6.svg",
            ]}
            rollingTime={1000}
            disabled={!isPlayerTurn || gameState !== "playing"}
            cheatValue={
              // Use server value as the cheat value whenever possible
              value >= 1 && value <= 6 && !isRolling
                ? (value as 1 | 2 | 3 | 4 | 5 | 6)
                : finalValue >= 1 && finalValue <= 6
                ? (finalValue as 1 | 2 | 3 | 4 | 5 | 6)
                : (1 as 1 | 2 | 3 | 4 | 5 | 6) // Fallback to 1 if invalid
            }
            defaultValue={1}
            onRoll={(rolledValue) => {
              console.log(
                `Dice animation rolling - random value: ${rolledValue}`
              );

              // After animation completes, always prefer the server value
              if (!isRolling && value >= 1 && value <= 6) {
                // Force update to server value after roll animation
                setTimeout(() => {
                  setFinalValue(value);
                }, 50);
              }
            }}
          />
        </div>
      </motion.div>
    </div>
  );
}
