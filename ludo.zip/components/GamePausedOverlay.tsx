import React, { useState, useEffect } from "react";
import { Progress } from "./ui/progress";
import { Clock } from "lucide-react";
import { cn } from "@/lib/utils";

interface GamePausedOverlayProps {
  isVisible: boolean;
  disconnectedPlayerName?: string;
}

const GamePausedOverlay: React.FC<GamePausedOverlayProps> = ({
  isVisible,
  disconnectedPlayerName = "A player",
}) => {
  const [timeLeft, setTimeLeft] = useState(120); // 2 minutes in seconds
  const [progress, setProgress] = useState(100);

  useEffect(() => {
    // Reset timer when the overlay becomes visible
    if (isVisible) {
      setTimeLeft(120);
      setProgress(100);
    } else {
      return; // Don't start timer if overlay is not visible
    }

    // Start countdown timer
    const timer = setInterval(() => {
      setTimeLeft((prevTime) => {
        const newTime = Math.max(0, prevTime - 1);
        // If timer reaches zero, clear the interval
        if (newTime === 0) {
          clearInterval(timer);
        }
        return newTime;
      });
    }, 1000);

    // Clean up timer on unmount or when visibility changes
    return () => clearInterval(timer);
  }, [isVisible]);

  // Update progress whenever timeLeft changes
  useEffect(() => {
    if (isVisible) {
      const totalSeconds = 120; // 2 minutes in seconds
      const percentage = Math.max(
        0,
        Math.min(100, (timeLeft / totalSeconds) * 100)
      );
      setProgress(percentage);
    }
  }, [timeLeft, isVisible]);

  if (!isVisible) return null;

  // Format time as MM:SS
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;

  // Determine color based on remaining time
  const colorClass =
    progress > 66
      ? "bg-green-500"
      : progress > 33
      ? "bg-amber-500"
      : "bg-red-500";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm">
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 p-6 rounded-xl border border-white/20 shadow-xl text-center max-w-md w-full">
        <div className="text-3xl font-bold mb-4 text-white">Game Paused</div>
        <div className="flex items-center justify-center mb-6">
          <div className="text-xl">
            <span className="text-amber-400 font-bold">
              {disconnectedPlayerName}
            </span>{" "}
            has disconnected
          </div>
        </div>

        <div className="flex items-center justify-center gap-3 mb-4">
          <Clock className="w-6 h-6 text-amber-400 animate-pulse" />
          <div
            className={cn(
              "text-xl font-mono px-4 py-1 rounded-md",
              timeLeft <= 30
                ? "bg-red-500/20 text-red-300"
                : "bg-amber-500/20 text-amber-200"
            )}
          >
            {formattedTime}
          </div>
        </div>

        <div className="mb-6 px-2">
          <div className="text-sm text-white/70 mb-2 text-left">
            Reconnection time remaining:
          </div>
          <div className="relative h-3 w-full overflow-hidden rounded-full bg-gray-700">
            <div
              className={cn(
                "h-full transition-all duration-1000 ease-linear",
                colorClass
              )}
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>

        <div className="text-md text-white/90 p-3 bg-white/5 rounded-lg border border-white/10">
          The game will automatically resume when{" "}
          <span className="text-amber-400 font-medium">
            {disconnectedPlayerName}
          </span>{" "}
          reconnects or after the 2-minute timeout expires.
        </div>
      </div>
    </div>
  );
};

export default GamePausedOverlay;
