"use client";

import { useEffect } from "react";
import { useGameStore } from "@/lib/game/store";
import { useSocket } from "@/lib/socket/client";

/**
 * A more robust token synchronization component that ensures all players
 * have proper token data displayed no matter when they join the game
 */
export default function TokenSynchronizer() {
  const { socket, connected } = useSocket();
  const { players, setRoomData, roomCode, gameState, currentTurn, messages } =
    useGameStore();

  // Request the latest room state periodically to ensure token states are updated
  useEffect(() => {
    if (!connected || !socket || !roomCode) return;

    // Request the latest room state immediately when component mounts
    const requestRoomState = () => {
      console.log("Requesting latest room state for token sync");
      socket.emit("request-room-state", roomCode);
    };

    // Initial request when connected
    requestRoomState();

    // Set up an interval to periodically request the latest room state
    const interval = setInterval(requestRoomState, 5000); // Request every 5 seconds

    // Clean up on unmount
    return () => clearInterval(interval);
  }, [connected, socket, roomCode]);

  // Listen for room state updates
  useEffect(() => {
    if (!socket) return;

    const handleRoomState = (data: any) => {
      console.log("Received room state update for token sync:", data);

      // Only update if we have valid data
      if (data && data.players && Array.isArray(data.players)) {
        // Ensure all players have valid tokens
        const validatedPlayers = data.players.map((player: any) => {
          if (
            !player.tokens ||
            !Array.isArray(player.tokens) ||
            player.tokens.length !== 4
          ) {
            console.log(`Fixing tokens for player ${player.name}`);
            return {
              ...player,
              tokens: [
                { id: 0, position: "home", steps: 0 },
                { id: 1, position: "home", steps: 0 },
                { id: 2, position: "home", steps: 0 },
                { id: 3, position: "home", steps: 0 },
              ],
            };
          }
          return player;
        });

        setRoomData({
          ...data,
          players: validatedPlayers,
          messages: messages, // Preserve existing messages
        });
      }
    };

    // Register the event handler
    socket.on("room-state", handleRoomState);

    return () => {
      socket.off("room-state", handleRoomState);
    };
  }, [socket, setRoomData, messages]);

  // Render nothing - this is just for the effects
  return null;
}
