"use client";

import { useEffect, memo } from "react";
import { useSocket } from "@/lib/socket/client";

// Memoize the component to prevent unnecessary re-renders
export const SocketInitializer = memo(function SocketInitializer() {
  const { socket, connected } = useSocket();

  useEffect(() => {
    // Log connection status changes
    console.log(
      `Socket connection status: ${connected ? "Connected" : "Disconnected"}`
    );

    // Clean up on unmount
    return () => {
      console.log("SocketInitializer unmounted");
    };
  }, [connected]);

  return null; // This component doesn't render anything
});
