import { Server as NetServer } from "http";
import { NextApiRequest, NextApiResponse } from "next";
import { Server as ServerIO } from "socket.io";

export const config = {
  api: {
    bodyParser: false,
  },
};

// This is our API route that sets up the Socket.IO connection
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse & { socket: { server: NetServer & { io?: ServerIO } } }
) {
  // Only handle GET requests for the socket connection establishment
  if (req.method !== "GET") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    // Import the socket initializer
    const socketModule = await import("@/lib/socket/server");

    // Call the initialize function
    socketModule.initializeSocket(req, res);

    // Return a 200 OK response
    res.status(200).end();
  } catch (error) {
    console.error("Socket initialization error:", error);
    res.status(500).json({ error: "Failed to initialize socket" });
  }
}
